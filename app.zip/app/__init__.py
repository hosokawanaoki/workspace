"""
Application initialization module
"""
