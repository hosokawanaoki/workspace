"""APIアプリケーションの設定を定義するモジュール"""

import logging
import os

from django.apps import AppConfig

logger = logging.getLogger(__name__)


class ApiConfig(AppConfig):
    """APIアプリケーションの設定クラス"""

    default_auto_field = "django.db.models.BigAutoField"
    name = "api"

    def ready(self) -> None:
        """アプリケーション起動時の初期化処理"""
        import sys

        # Django管理コマンド実行時はスケジューラーを起動しない
        EXCLUDED_COMMANDS = [
            "test",
            "migrate",
            "makemigrations",
            "shell",
            "dbshell",
            "check",
            "compilemessages",
            "createcachetable",
            "showmigrations",
        ]
        # runserverコマンドの場合、メインプロセスでのみスケジューラーを起動
        if not any(cmd in sys.argv for cmd in EXCLUDED_COMMANDS) and (
            # メインプロセスの場合のみ実行（自動リロードプロセスでは実行しない）
            "runserver" not in sys.argv
            or (
                # または--noreloadオプションが指定されている場合
                "--noreload" in sys.argv
                or os.environ.get("RUN_MAIN") == "true"
            )
        ):
            try:
                from api.services.scheduler.runners.book_scheduler_runner import (
                    start_book_scheduler,
                )

                # スケジューラーの初期化と起動
                start_book_scheduler()
            except Exception as e:
                logger.error(f"Failed to initialize scheduler: {str(e)}")
                logger.exception("Detailed error traceback:")
