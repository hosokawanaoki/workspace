from api.views.book.cancel_translation import CancelTranslationView
from api.views.book.detail import BookDetailView
from api.views.book.list import BookListView
from api.views.book.repair import TranslateRepairView
from api.views.book.tag_error import TagErrorView
from api.views.book.translate import TranslateView
from api.views.book.translation_batch import TranslationBatchView
from api.views.book.translation_history import TranslationHistoryView
from api.views.book.version_content import VersionContentView
from api.views.book.versions import BookVersionsView
from api.views.gutenberg.gutenberg import GutenbergView
from api.views.translation_setting_views import (
    LLMModelListView,
    TranslationSettingDetailView,
    TranslationSettingListView,
)
from django.urls import path

urlpatterns = [
    # LLMモデル一覧の取得
    path("llm-models", LLMModelListView.as_view(), name="llm_models"),
    # 翻訳設定の管理
    path(
        "translation-settings",
        TranslationSettingListView.as_view(),
        name="translation_settings",
    ),
    path(
        "translation-settings/<int:pk>",
        TranslationSettingDetailView.as_view(),
        name="translation_setting_detail",
    ),
    # 書籍一覧の取得・作成
    path("books", BookListView.as_view(), name="get_create_books"),
    # 書籍詳細の取得・更新
    path("books/<str:book_id>", BookDetailView.as_view(), name="book_detail"),
    # 書籍の翻訳履歴取得
    path(
        "books/<str:book_id>/history",
        TranslationHistoryView.as_view(),
        name="translation_history",
    ),
    # タグエラーの取得・修正
    path(
        "books/<str:book_id>/tag-errors",
        TagErrorView.as_view(),
        name="tag_errors",
    ),
    # 書籍の翻訳バージョン一覧取得・新規作成・削除
    path(
        "books/<str:book_id>/versions",
        BookVersionsView.as_view(),
        name="book_versions",
    ),
    path(
        "books/<str:book_id>/versions/<int:version_id>",
        BookVersionsView.as_view(),
        name="version_detail",
    ),
    # 書籍の特定バージョンの翻訳内容取得
    path(
        "books/<str:book_id>/versions/<int:version_id>/content",
        VersionContentView.as_view(),
        name="version_content",
    ),
    # 翻訳の実行
    path("translate", TranslateView.as_view(), name="execute_translation"),
    # 翻訳バッチの管理（作成・更新・削除）
    path(
        "translate/batch",
        TranslationBatchView.as_view(),
        name="manage_translation_batch",
    ),
    # 翻訳キャンセル
    path(
        "translate/cancel/<str:book_id>",
        CancelTranslationView.as_view(),
        name="cancel_translation",
    ),
    # Project Gutenbergからの書籍情報取得
    path("gutenberg", GutenbergView.as_view(), name="fetch_gutenberg_books"),
    # 翻訳修復
    path(
        "translate/repair/<str:id>",
        TranslateRepairView.as_view(),
        name="repair_translation",
    ),
]
