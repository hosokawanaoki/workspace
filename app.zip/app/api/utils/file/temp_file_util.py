import logging
import os
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Generator, Optional, Union

logger = logging.getLogger(__name__)


class TempFileUtil:
    """一時ファイル操作を提供するクラス"""

    @staticmethod
    def check_path_exists(path: Union[str, Path]) -> bool:
        """一時ファイルの存在を確認する

        Args:
            path: チェックするパス

        Returns:
            bool: 一時ファイルが存在する場合はTrue
        """
        p = Path(path)
        exists = p.exists() and p.is_file()
        status = "存在します" if exists else "存在しません"
        logger.debug(f"一時ファイル {p} は{status}")
        return exists

    @staticmethod
    @contextmanager
    def create_temp_file(
        suffix: Optional[str] = None,
        prefix: Optional[str] = None,
        dir: Optional[str] = None,
    ) -> Generator[str, None, None]:
        """一時ファイルを作成し、使用後に自動的に削除する

        Args:
            suffix: 一時ファイルの接尾辞（例: '.txt'）
            prefix: 一時ファイルの接頭辞
            dir: 一時ファイルを作成するディレクトリ

        Yields:
            str: 作成された一時ファイルのパス

        Example:
            >>> with create_temp_file(suffix='.txt') as temp_path:
            ...     # 一時ファイルを使用する処理
            ...     pass
            # ブロックを抜けると自動的に一時ファイルが削除される
        """
        temp_dir = dir or tempfile.gettempdir()
        temp_file = tempfile.NamedTemporaryFile(
            delete=False,
            suffix=suffix,
            prefix=prefix,
            dir=temp_dir,
        )
        try:
            temp_file.close()
            logger.debug(f"一時ファイルを作成: {temp_file.name}")
            yield temp_file.name
        finally:
            try:
                os.unlink(temp_file.name)
                logger.debug(f"一時ファイルを削除: {temp_file.name}")
            except OSError as e:
                logger.warning(f"一時ファイル {temp_file.name} の削除に失敗: {e}")
