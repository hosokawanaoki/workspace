"""ファイル操作ユーティリティパッケージ

基本的なファイル操作機能を提供します。
各機能は専用のユーティリティクラスとして実装され、
すべてのメソッドは静的メソッドとして提供されます。

Example:
    基本的なファイル操作:
    >>> from api.utils.file import FileUtil, FileWriterUtil, DirectoryUtil
    >>> FileUtil.read_file("input.txt")
    >>> FileWriterUtil.save_json_file("data.json", {"key": "value"})
    >>> DirectoryUtil.ensure_directory("path/to/dir")

    HTML操作:
    >>> from api.utils.file import HTMLFileUtil
    >>> HTMLFileUtil.read_file("page.html")

    一時ファイル操作:
    >>> from api.utils.file import TempFileUtil
    >>> with TempFileUtil.create_temp_file() as temp_path:
    ...     # 一時ファイルを使用
    ...     pass

    Excel操作:
    >>> from api.utils.file import read_excel_to_df, write_df_to_excel
    >>> df = read_excel_to_df("data.xlsx")
    >>> write_df_to_excel(df, "output.xlsx")

    EPUB操作:
    >>> from api.utils.file import EPUBHandler, EPUBMetadata
    >>> metadata = EPUBMetadata(title="サンプル", author="著者名")
    >>> EPUBHandler.convert_to_epub("input.html", "output.epub", metadata=metadata)
"""

from .directory_util import DirectoryUtil
from .epub_util import EPUBHandler, EPUBMetadata, EPUBConfig
from .excel_util import ExcelStyler, read_excel_to_df, write_df_to_excel, read_excel_row_by_key
from .file_util import FileUtil
from .file_writer_util import FileWriterUtil
from .html_file_util import HTMLFileUtil
from .temp_file_util import TempFileUtil

__all__ = [
    # 基本ファイル操作
    "DirectoryUtil",
    "FileUtil",
    "FileWriterUtil",
    # HTML操作
    "HTMLFileUtil",
    # 一時ファイル操作
    "TempFileUtil",
    # Excel操作
    "ExcelStyler",
    "read_excel_to_df",
    "write_df_to_excel",
    "read_excel_row_by_key",
    # EPUB操作
    "EPUBHandler",
    "EPUBMetadata",
    "EPUBConfig",
]
