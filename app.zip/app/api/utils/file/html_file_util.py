import logging
from pathlib import Path
from typing import Optional, Union

from api.constants.constants import SYSTEM
from api.utils.file.file_util import FileUtil
from api.utils.file.file_writer_util import FileWriterUtil
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)


class HTMLFileUtil:
    """HTML操作を提供するクラス"""

    @staticmethod
    def check_path_exists(path: Union[str, Path]) -> bool:
        """HTMLファイルの存在を確認する

        Args:
            path: チェックするパス

        Returns:
            bool: HTMLファイルが存在する場合はTrue
        """
        return FileUtil.exists(path)

    @staticmethod
    def read_file(file_path: Union[str, Path], encoding: Optional[str] = None) -> str:
        """HTMLファイルを読み込む

        Args:
            file_path: 読み込むファイルのパス
            encoding: エンコーディング（デフォルト: 設定値）

        Returns:
            str: 読み込んだ内容

        Raises:
            FileNotFoundError: ファイルが存在しない場合
            OSError: ファイルの読み込みに失敗した場合
        """
        return FileUtil.read_file(file_path, encoding)

    @staticmethod
    def replace_tag_inside(
        outside_html_path: Union[str, Path],
        inside_html_path: Union[str, Path],
        output_file_path: Union[str, Path],
        outside_placeholder: str,
    ) -> None:
        """外部HTMLのプレースホルダーを内部HTMLで置換する

        Args:
            outside_html_path: 外部HTMLファイル
            inside_html_path: 内部HTMLファイル
            output_file_path: 出力先HTMLファイル
            outside_placeholder: 置換対象の文字列

        Raises:
            FileNotFoundError: 入力ファイルが存在しない場合
            OSError: ファイルの読み書きに失敗した場合
        """
        logger.debug(
            f"HTMLタグを置換: {outside_html_path} + {inside_html_path} → {output_file_path}"
        )

        try:
            HTMLFileUtil._validate_input_files(outside_html_path, inside_html_path)
            combined_html = HTMLFileUtil._combine_html_files(
                outside_html_path, inside_html_path, outside_placeholder
            )
            FileWriterUtil.save_file_with_permission(output_file_path, combined_html)
            logger.info(f"HTML全体の復元が完了: {output_file_path}")

        except (OSError, IOError) as e:
            error_msg = f"HTMLの置換に失敗: {str(e)}"
            logger.exception(error_msg)
            raise OSError(error_msg) from e

    @staticmethod
    def _validate_input_files(
        outside_html_path: Union[str, Path], inside_html_path: Union[str, Path]
    ) -> None:
        """入力ファイルの存在を検証する

        Args:
            outside_html_path: 外部HTMLファイル
            inside_html_path: 内部HTMLファイル

        Raises:
            FileNotFoundError: ファイルが存在しない場合
        """
        if not FileUtil.exists(outside_html_path):
            raise FileNotFoundError(
                f"外部HTMLファイルが見つかりません: {outside_html_path}"
            )
        if not FileUtil.exists(inside_html_path):
            raise FileNotFoundError(
                f"内部HTMLファイルが見つかりません: {inside_html_path}"
            )

    @staticmethod
    def parse_html(
        file_path: Union[str, Path], parser: str = "html.parser"
    ) -> BeautifulSoup:
        """HTMLファイルを読み込んでBeautifulSoupオブジェクトを返す

        Args:
            file_path: 読み込むファイルのパス
            parser: 使用するパーサー（デフォルト: html.parser）

        Returns:
            BeautifulSoup: パース済みのHTMLオブジェクト

        Raises:
            FileNotFoundError: ファイルが存在しない場合
            OSError: ファイルの読み込みに失敗した場合
        """
        html_content = HTMLFileUtil.read_file(file_path)
        return BeautifulSoup(html_content, parser)

    @staticmethod
    def _combine_html_files(
        outside_html_path: Union[str, Path],
        inside_html_path: Union[str, Path],
        outside_placeholder: str,
    ) -> str:
        """HTMLファイルを結合する

        Args:
            outside_html_path: 外部HTMLファイル
            inside_html_path: 内部HTMLファイル
            outside_placeholder: 置換対象の文字列

        Returns:
            str: 結合されたHTML

        Raises:
            OSError: ファイルの読み込みに失敗した場合
        """
        try:
            with open(outside_html_path, "r", encoding=SYSTEM["DEFAULT_ENCODING"]) as f:
                outside_html = f.read()

            with open(inside_html_path, "r", encoding=SYSTEM["DEFAULT_ENCODING"]) as f:
                inside_html = f.read()

            return outside_html.replace(outside_placeholder, inside_html)

        except (OSError, IOError) as e:
            error_msg = f"HTMLファイルの読み込みに失敗: {str(e)}"
            logger.exception(error_msg)
            raise OSError(error_msg) from e
