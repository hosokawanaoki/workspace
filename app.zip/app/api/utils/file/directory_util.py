import logging
import os
import shutil
from pathlib import Path
from typing import Optional, Union

from api.constants.constants import SYSTEM

logger = logging.getLogger(__name__)


class DirectoryUtil:
    """ディレクトリ操作を提供するクラス

    主な機能：
    - ディレクトリの存在確認
    - ディレクトリの作成
    - 権限の設定（単一/再帰的）
    """

    DEFAULT_PERMISSION: int = SYSTEM.get("DEFAULT_PERMISSION", 0o666)
    """ディレクトリ操作を提供するクラス"""

    @staticmethod
    def check_path_exists(path: Union[str, Path]) -> bool:
        """ディレクトリの存在を確認する

        Args:
            path: チェックするパス

        Returns:
            bool: ディレクトリが存在する場合はTrue
        """
        p = Path(path)
        exists = p.exists() and p.is_dir()
        status = "存在します" if exists else "存在しません"
        logger.debug(f"ディレクトリ {p} は{status}")
        return exists

    @staticmethod
    def create_directory_with_permissions(
        directory_path: Union[str, Path],
        permission: Optional[int] = None,
    ) -> None:
        """ディレクトリを作成し、権限を設定する

        Args:
            directory_path: 作成するディレクトリのパス
            permission: 設定する権限（デフォルト: 設定値）
            config: ファイル設定（オプション）

        Raises:
            ValueError: ディレクトリ作成中にエラーが発生した場合
        """
        try:
            path = Path(directory_path)
            path.mkdir(parents=True, exist_ok=True)
            perm = permission or SYSTEM["DEFAULT_PERMISSION"]
            os.chmod(path, perm)
            logger.info(f"ディレクトリ作成完了: '{path}'")
        except Exception as e:
            error_msg = f"ディレクトリ作成中にエラーが発生しました: {str(e)}"
            logger.exception(error_msg)
            raise ValueError(error_msg)

    @staticmethod
    def change_permissions(path: Union[str, Path], mode: Optional[int] = None) -> None:
        """ファイルまたはディレクトリの権限を変更する

        Args:
            path: 対象のパス
            mode: 設定する権限（デフォルト: DEFAULT_PERMISSION）

        Raises:
            OSError: 権限の変更に失敗した場合
        """
        file_path = Path(path)
        if not file_path.exists():
            return

        try:
            perm = mode or DirectoryUtil.DEFAULT_PERMISSION
            file_path.chmod(perm)
            logger.debug(f"権限を変更: {path} → {oct(perm)}")
        except OSError as e:
            error_msg = f"権限の変更に失敗: {path}"
            logger.error(error_msg)
            raise OSError(error_msg) from e

    @staticmethod
    def change_permissions_recursively(
        target_directory: Union[str, Path],
        permission: Optional[int] = None,
    ) -> None:
        """ディレクトリとその中のファイルの権限を再帰的に変更する

        Args:
            target_directory: 権限を変更するディレクトリのパス
            permission: 設定する権限（デフォルト: DEFAULT_PERMISSION）

        Raises:
            OSError: 権限変更中にエラーが発生した場合
        """
        try:
            perm = permission or DirectoryUtil.DEFAULT_PERMISSION
            target_path = Path(target_directory)

            if not target_path.exists():
                return

            # まずディレクトリ自体の権限を変更
            DirectoryUtil.change_permissions(target_path, perm)

            # 再帰的に中身の権限を変更
            for item in target_path.rglob("*"):
                DirectoryUtil.change_permissions(item, perm)

            logger.debug(f"権限を再帰的に変更: {target_path} → {oct(perm)}")
        except OSError as e:
            error_msg = f"再帰的な権限変更に失敗: {target_directory}"
            logger.error(error_msg)
            raise OSError(error_msg) from e

    @staticmethod
    def ensure_directory(directory_path: Union[str, Path]) -> None:
        """ディレクトリの存在を確認し、必要に応じて作成する

        Args:
            directory_path: 作成するディレクトリのパス

        Raises:
            OSError: ディレクトリの作成に失敗した場合
        """
        try:
            path = Path(directory_path)
            path.mkdir(parents=True, exist_ok=True)
            logger.debug(f"ディレクトリを確認/作成: {path}")
        except OSError as e:
            error_msg = f"ディレクトリの作成に失敗: {directory_path}"
            logger.exception(error_msg)
            raise OSError(error_msg) from e

    @staticmethod
    def remove_directory(directory_path: Union[str, Path]) -> None:
        """ディレクトリとその中身を再帰的に削除する

        Args:
            directory_path: 削除するディレクトリのパス

        Raises:
            OSError: ディレクトリの削除に失敗した場合
        """
        try:
            path = Path(directory_path)
            if path.exists() and path.is_dir():
                shutil.rmtree(path)
                logger.debug(f"ディレクトリを削除: {path}")
        except OSError as e:
            error_msg = f"ディレクトリの削除に失敗: {directory_path}"
            logger.exception(error_msg)
            raise OSError(error_msg) from e
