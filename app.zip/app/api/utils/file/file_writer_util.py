import json
import logging
import os
from pathlib import Path
from typing import Dict, List, Optional, Union

from api.constants.constants import SYSTEM
from api.utils.file.directory_util import DirectoryUtil

logger = logging.getLogger(__name__)


class FileWriterUtil:
    """ファイル保存操作を提供するクラス"""

    @staticmethod
    def check_path_exists(path: Union[str, Path]) -> bool:
        """ファイルの存在を確認する

        Args:
            path: チェックするパス

        Returns:
            bool: ファイルが存在する場合はTrue
        """
        p = Path(path)
        exists = p.exists() and p.is_file()
        status = "存在します" if exists else "存在しません"
        logger.debug(f"ファイル {p} は{status}")
        return exists

    @staticmethod
    def save_file_with_permission(
        file_path: Union[str, Path],
        content: str,
        permission: Optional[int] = None,
        encoding: Optional[str] = None,
    ) -> None:
        """ファイルを保存し、権限を設定する

        Args:
            file_path: 保存先ファイルパス
            content: 保存する内容
            permission: 設定する権限（デフォルト: 設定値）
            encoding: エンコーディング（デフォルト: 設定値）
            config: ファイル設定（オプション）

        Raises:
            OSError: ファイルの保存または権限設定に失敗した場合
        """
        path = Path(file_path)
        perm = permission or SYSTEM["DEFAULT_PERMISSION"]
        enc = encoding or SYSTEM["DEFAULT_ENCODING"]

        try:
            DirectoryUtil.ensure_directory(path.parent)

            with open(path, "w", encoding=enc) as f:
                f.write(content)

            os.chmod(path, perm)
            logger.info(f"ファイルを保存: {path}")

        except (OSError, IOError) as e:
            error_msg = f"ファイルの保存または権限設定に失敗: {str(e)}"
            logger.exception(error_msg)
            raise OSError(error_msg) from e

    @staticmethod
    def save_json_file(
        file_path: Union[str, Path],
        data: Union[Dict, List[Dict]],
        permission: Optional[int] = None,
    ) -> None:
        """JSONファイルを保存する

        Args:
            file_path: 保存先のファイルパス
            data: 保存するデータ
            permission: ファイルの権限（デフォルト: 設定値）
            config: ファイル設定（オプション）

        Raises:
            ValueError: JSONファイル保存中にエラーが発生した場合
        """
        try:
            content = json.dumps(data, ensure_ascii=False, indent=2)
            FileWriterUtil.save_file_with_permission(file_path, content, permission)
            logger.info(f"JSONファイル保存完了: '{file_path}'")
        except Exception as e:
            error_msg = f"JSONファイル保存中にエラーが発生しました: {str(e)}"
            logger.exception(error_msg)
            raise ValueError(error_msg)

    @staticmethod
    def save_html_file(
        file_path: Union[str, Path],
        content: str,
        permission: Optional[int] = None,
    ) -> None:
        """HTMLファイルを保存する

        Args:
            file_path: 保存先のファイルパス
            content: 保存する内容
            permission: ファイルの権限（デフォルト: 設定値）
            config: ファイル設定（オプション）

        Raises:
            ValueError: HTMLファイル保存中にエラーが発生した場合
        """
        try:
            FileWriterUtil.save_file_with_permission(file_path, content, permission)
            logger.info(f"HTMLファイル保存完了: '{file_path}'")
        except Exception as e:
            error_msg = f"HTMLファイル保存中にエラーが発生しました: {str(e)}"
            logger.exception(error_msg)
            raise ValueError(error_msg)
