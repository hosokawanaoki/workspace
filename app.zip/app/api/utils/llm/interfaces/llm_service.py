from abc import ABC, abstractmethod

from ..models.llm_response import LLMResponse
from ..models.prompt_type import PromptType


class LLMService(ABC):
    """LLMサービスのインターフェース

    LLMサービスの実装はこのインターフェースに従う必要があります。
    これにより、異なるLLMサービスの実装を容易に切り替えることができ、
    テスト時のモック化も簡単になります。
    """

    @abstractmethod
    def update_config(self, model: str) -> None:
        """設定を更新する

        Args:
            model: モデル名

        Raises:
            LLMValidationError: モデル名が不正な場合
        """
        pass

    @abstractmethod
    def send_message(
        self,
        prompt_type: PromptType,
        variables: list[dict[str, str]] = [],
        model: str | None = None,
    ) -> LLMResponse:
        """指定されたプロンプトタイプに基づいてメッセージを送信し、レスポンスを取得します

        Args:
            prompt_type: プロンプトタイプ
            variables: プロンプトテンプレートの変数値（辞書のリスト）。デフォルトは空リスト
            model: 使用するモデル名（オプション）。指定時はこのモデルが優先される

        Returns:
            LLMResponse: LLMからのレスポンス

        Raises:
            LLMAuthenticationError: 認証エラー（APIキー不正など）
            LLMRateLimitError: レート制限エラー
            LLMAPIError: API呼び出しエラー
            LLMTimeoutError: タイムアウトエラー
            LLMValidationError: 入力バリデーションエラー
        """
        pass
