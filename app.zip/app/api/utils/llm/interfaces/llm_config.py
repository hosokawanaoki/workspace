"""LLMConfig インターフェース"""

from abc import ABC, abstractmethod
from typing import Any, Optional


class LLMConfig(ABC):
    """LLM設定のインターフェース"""

    @abstractmethod
    def get_model_name(self) -> str:
        """実際のモデル名を取得する

        Returns:
            str: 実際のモデル名（例：'claude-3-5-sonnet-20241022'）
        """
        pass

    @abstractmethod
    def get_api_base(self) -> Optional[str]:
        """APIのベースURLを取得する

        Returns:
            Optional[str]: APIのベースURL。設定されていない場合はNone
        """
        pass

    @abstractmethod
    def get_temperature(self) -> Optional[float]:
        """温度パラメータを取得する

        Returns:
            Optional[float]: 温度パラメータ。設定されていない場合はNone
        """
        pass

    @abstractmethod
    def get_memory_window(self) -> Optional[int]:
        """メモリウィンドウサイズを取得する

        Returns:
            Optional[int]: メモリウィンドウサイズ。設定されていない場合はNone
        """
        pass

    @abstractmethod
    def get_prompt_config(self) -> Optional[Any]:
        """プロンプト設定を取得する

        Returns:
            Optional[Any]: プロンプト設定。設定されていない場合はNone
        """
        pass
