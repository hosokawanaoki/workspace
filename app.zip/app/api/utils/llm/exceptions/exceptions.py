class LLMError(Exception):
    """LLM関連の基底例外クラス"""

    pass


class LLMValidationError(LLMError):
    """LLMの設定やクライアント生成時のバリデーションエラー"""

    pass


class LLMAuthenticationError(LLMError):
    """LLMの認証エラー（APIキー不正など）"""

    pass


class LLMRateLimitError(LLMError):
    """LLMのレート制限エラー"""

    pass


class LLMAPIError(LLMError):
    """LLMAPI呼び出しエラー"""

    pass


class LLMTimeoutError(LLMError):
    """LLMのタイムアウトエラー"""

    pass
