import logging
from typing import Any, List, Optional

from api.services.common.logging_utils import measure_performance
from api.utils.llm.core.error_handler import LLMErrorHandler
from api.utils.llm.core.memory_handler import LLMMemoryHandler
from api.utils.llm.implementations.llm_config_impl import LLMConfigImpl as LLMConfig
from api.utils.llm.interfaces.llm_chat_client import LLMChatClient
from api.utils.llm.models.llm_response import LLMResponse
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_core.messages.base import BaseMessage
from pydantic import BaseModel, PrivateAttr

logger = logging.getLogger(__name__)


class ChatCompletionHandler(BaseModel):
    """LLMチャット処理を担当するクラス"""

    # プライベート属性
    _llm_client: LLMChatClient = PrivateAttr()
    _config: LLMConfig = PrivateAttr()
    _error_handler: LLMErrorHandler = PrivateAttr()
    _memory_handler: LLMMemoryHandler = PrivateAttr()

    def __init__(
        self,
        config: LLMConfig,
        llm_client: LLMChatClient,
        window_size: Optional[int] = None,
        **data: Any,
    ):
        """初期化処理

        Args:
            config: LLM設定
            llm_client: LLMクライアントのインターフェース
            window_size: メモリウィンドウサイズ
            **data: その他のパラメータ
        """
        if config is None:
            raise ValueError("config is required")
        if llm_client is None:
            raise ValueError("llm_client is required")

        super().__init__(**data)
        self._config = config
        self._llm_client = llm_client
        self._error_handler = LLMErrorHandler()
        self._memory_handler = LLMMemoryHandler(window_size=window_size)

    def _prepare_messages(
        self,
        content: str,
        context: Optional[str] = None,
        additional_params: Optional[dict] = None,
    ) -> List[BaseMessage]:
        """メッセージを準備

        Args:
            content: 主要なコンテンツ
            context: コンテキスト情報
            additional_params: 追加パラメータ

        Returns:
            List[BaseMessage]: 準備されたメッセージリスト
        """
        messages: List[BaseMessage] = []

        # システムメッセージを追加
        if context:
            messages.append(SystemMessage(content=context))

        # ユーザーメッセージを追加
        messages.append(HumanMessage(content=content))

        # メモリから履歴情報を取得
        memory_vars = self._memory_handler.load_memory_variables({"input": content})
        if memory_vars and "history" in memory_vars:
            for msg in memory_vars["history"]:
                if msg["type"] == "human":
                    messages.append(HumanMessage(content=msg["content"]))
                elif msg["type"] == "ai":
                    messages.append(AIMessage(content=msg["content"]))
                elif msg["type"] == "system":
                    messages.append(SystemMessage(content=msg["content"]))

        return messages

    @measure_performance
    def send_chat_completion(
        self,
        content: str,
        context: Optional[str] = None,
        additional_params: Optional[dict] = None,
        request_id: str = "0",
    ) -> LLMResponse:
        """LLMにチャットリクエストを送信

        Args:
            content: 主要なコンテンツ
            context: コンテキスト情報
            additional_params: 追加パラメータ
            request_id: リクエストID（ログ用）

        Returns:
            LLMResponse: LLMからのレスポンス

        Raises:
            Exception: LLM処理でエラーが発生した場合
        """
        try:
            messages = self._prepare_messages(content, context, additional_params)
            response = self._llm_client.get_chat_response(
                messages=messages,
                config=self._config,
            )

            if response is None:
                logger.error("LLM response is None")
                raise ValueError("Invalid response from LLM: response is None")

            # 成功した応答をメモリに保存
            self._memory_handler.save_context(
                {"input": content},
                {"output": response},
            )

            return response

        except Exception as e:
            error_status = self._error_handler.handle_llm_error(e)
            error_message = self._error_handler.format_error_message(e, request_id)
            raise Exception(f"{error_message} (Status: {error_status})")

    def clear_memory(self) -> None:
        """メモリをクリア"""
        self._memory_handler.clear()
