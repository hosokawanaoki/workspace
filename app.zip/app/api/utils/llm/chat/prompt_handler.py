import logging
from typing import Any, Dict, Optional

from pydantic import BaseModel

from api.utils.llm.models.prompt_type import PromptType

logger = logging.getLogger(__name__)


class PromptHandler(BaseModel):
    """プロンプト管理を担当するクラス"""

    def create_prompt_params(
        self,
        prompt_type: PromptType,
        content: str,
        context: Optional[str] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """プロンプトパラメータを生成

        Args:
            prompt_type: プロンプトタイプ
            content: 主要なコンテンツ
            context: コンテキスト情報
            **kwargs: 追加パラメータ

        Returns:
            Dict[str, Any]: プロンプトパラメータ
        """
        params = {
            "content": content,
            "context": context or "",
        }
        # 追加パラメータがある場合は追加
        params.update(kwargs)
        return params

    def format_response(self, response_content: str) -> str:
        """レスポンスを整形

        Args:
            response_content: LLMからのレスポンス

        Returns:
            str: 整形されたレスポンス
        """
        if not response_content:
            return ""

        return response_content.strip()
