from enum import Enum


class PromptType(Enum):
    """プロンプトの種類を定義する列挙型

    各LLMの用途に応じたプロンプトタイプを定義します。
    プロンプトに必要な変数は呼び出し側で管理します。
    """

    TRANSLATION = "translation"
    TAG_RECOVERY = "tag_recovery"
    GET_BOOK = "get_book"
    CORRECTION = "correction"
