from dataclasses import dataclass, field
from typing import Dict

from .prompt_type import PromptType


@dataclass
class PromptTemplate:
    """プロンプトテンプレートを定義するデータクラス

    特定のプロンプトタイプに対するテンプレートと変数を管理します。

    Attributes:
        prompt_type: プロンプトの種類
        template: プロンプトのテンプレート文字列
        variables: テンプレートで使用する変数のデフォルト値
        format_type: プロンプトのフォーマット形式（'chat'または'completion'）
    """

    prompt_type: PromptType
    template: str
    system: str
    variables: Dict[str, str] = field(default_factory=lambda: {})
    format_type: str = "chat"


@dataclass
class LLMPromptConfig:
    """LLMのプロンプト設定を管理するデータクラス

    各プロンプトタイプに対応するテンプレートを管理します。

    Attributes:
        templates: プロンプトタイプごとのテンプレート
        default_format_type: デフォルトのフォーマット形式
    """

    templates: Dict[PromptType, PromptTemplate]
    default_format_type: str = "chat"
