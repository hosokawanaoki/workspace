"""LLMConfig実装"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional

from api.utils.llm.consts import LLM
from api.utils.llm.interfaces.llm_config import LLMConfig
from api.utils.llm.models.prompt_type import PromptType
from omegaconf import DictKeyType, OmegaConf

from ..models.prompt_template import LLMPromptConfig, PromptTemplate


@dataclass
class LLMConfigImpl(LLMConfig):
    """LLMの設定パラメータ"""

    # クラス変数としてyaml設定を保持
    model_list: Dict[DictKeyType, Any] = field(default_factory=dict)

    model: Optional[str] = LLM["DEFAULT_MODEL"]
    prompt_config: Optional[LLMPromptConfig] = None
    temperature: Optional[float] = None
    timeout: Optional[int] = None
    retry_count: Optional[int] = None
    max_length: Optional[int] = None
    memory_window: Optional[int] = None

    def __post_init__(self):
        """初期化後の処理"""
        self._load_config()

    def _load_config(self) -> None:
        """yamlファイルから設定を読み込む"""
        config_path = Path("/app/app/api/constants/llm_prompt_templates.yaml")
        conf = OmegaConf.load(config_path)
        self.model_list = OmegaConf.to_container(conf, resolve=True)

    def get_model_list(self) -> Dict[str, Any]:
        """モデルリストを取得する

        Returns:
            Dict[str, Any]: モデルリストの設定
        """
        return self.model_list

    def get_model_name(self) -> str:
        """実際のモデル名を取得する"""
        if not self.model:
            return ""
        model_config = LLM["MODEL_MAPPINGS"].get(self.model)
        if not model_config:
            return ""
        return model_config["model_name"]

    def get_api_base(self) -> Optional[str]:
        """APIのベースURLを取得する"""
        if not self.model:
            return None
        model_config = LLM["MODEL_MAPPINGS"].get(self.model)
        if not model_config:
            return None
        return model_config.get("api_base")

    def get_temperature(self) -> Optional[float]:
        """温度パラメータを取得する"""
        return self.temperature

    def get_memory_window(self) -> Optional[int]:
        """メモリウィンドウサイズを取得する"""
        return self.memory_window

    def get_prompt_config(self) -> Optional[LLMPromptConfig]:
        """プロンプト設定を取得する"""
        return self.prompt_config

    def get_prompt_template(self, prompt_type: PromptType) -> PromptTemplate:
        """指定されたプロンプトタイプのテンプレートを取得する"""
        if not self.prompt_config or not self.prompt_config.templates:
            raise ValueError("プロンプト設定が存在しません")

        template = self.prompt_config.templates.get(prompt_type)
        if not template:
            raise ValueError(
                f"プロンプトタイプ {prompt_type} のテンプレートが見つかりません"
            )

        return template

    def has_prompt_type(self, prompt_type: PromptType) -> bool:
        """指定されたプロンプトタイプのテンプレートが存在するか確認する"""
        return (
            self.prompt_config is not None
            and self.prompt_config.templates is not None
            and prompt_type in self.prompt_config.templates
        )

    def update_from_model_name(self, model: str) -> None:
        """モデル名に基づいて設定を更新する"""
        if not model:
            raise ValueError("モデルが指定されていません")

        # モデル名をconstsから解決
        model_config = LLM["MODEL_MAPPINGS"].get(model)
        if not model_config:
            raise ValueError(f"モデル {model} の設定が見つかりません")

        actual_model_name = model_config["model_name"]

        # モデル設定からパターン名を取得
        pattern_name = model_config.get("pattern_name")
        if not pattern_name:
            raise ValueError(f"モデル {model} のパターン名が設定されていません")

        # パターン名を使ってmodel_patternsから設定を取得
        model_patterns = self.model_list.get("model_patterns", {})
        pattern_config = model_patterns.get(pattern_name)
        if not pattern_config:
            raise ValueError(f"パターン {pattern_name} の設定が見つかりません")

        # プロンプトテンプレートの設定
        templates = {}
        for (
            prompt_type_str,
            template_config,
        ) in pattern_config["prompt_config"]["templates"].items():
            prompt_type = PromptType(prompt_type_str)
            template = PromptTemplate(
                prompt_type=prompt_type,
                template=template_config["template"],
                system=template_config.get("system"),
                variables={},
                format_type=template_config.get("format_type", "chat"),
            )
            templates[prompt_type] = template

        # 設定の更新
        self.model = model
        self.prompt_config = LLMPromptConfig(
            templates=templates,
            default_format_type=pattern_config["prompt_config"].get(
                "default_format_type", "chat"
            ),
        )

        # その他のパラメータの更新
        self.temperature = pattern_config.get("temperature")
        self.timeout = pattern_config.get("timeout")
        self.retry_count = pattern_config.get("retry_count")
        self.max_length = pattern_config.get("max_length")
        self.memory_window = pattern_config.get("memory_window")

    @classmethod
    def from_model_name(cls, model: Optional[str] = None) -> "LLMConfigImpl":
        """モデル名から設定を生成する"""
        config = cls()
        if model:
            config.update_from_model_name(model)
        return config
