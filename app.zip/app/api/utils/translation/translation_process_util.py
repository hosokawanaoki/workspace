import logging

from api.models.translation import Translation
from api.services.models.translation_target import TranslationTarget
from api.services.translation.exceptions.translation_error import CancellationException

import datetime

logger = logging.getLogger(__name__)


class TranslationProcessUtil:
    """翻訳プロセスに関連するユーティリティクラス"""

    @staticmethod
    def handle_process_error(
        target: TranslationTarget, process_type: str, error: Exception
    ) -> None:
        """エラーハンドリングとステータス更新

        Args:
            target (TranslationTarget): 翻訳対象
            process_type (str): 処理タイプ（'翻訳'または'校正'）
            error (Exception): 発生したエラー
        """
        # キャンセル例外の場合は特別な処理を行う
        if isinstance(error, CancellationException):
            logger.info(f"{process_type}処理がキャンセルされました: {str(error)}")
            return

        # エラーメッセージをログに記録（完全なメッセージ）
        error_msg = f"{process_type}実行中にエラーが発生: {str(error)}"
        logger.error(error_msg)

        # status_messageには簡潔なメッセージのみを設定
        formatted_elapsed_time = TranslationProcessUtil.format_elapsed_time(target)
        if formatted_elapsed_time:
            target.batch.status_message = f"{process_type}処理エラー ({formatted_elapsed_time})"
        else:
            target.batch.status_message = f"{process_type}処理エラー"
        target.batch.save(update_fields=["status_message"])

    @staticmethod
    def update_translation_status(target: TranslationTarget) -> None:
        """翻訳ステータスの更新

        Args:
            target (TranslationTarget): 翻訳対象
        """
        # 翻訳の統計情報を取得
        tag_error_count, untranslated_count, error_line_count, total_count = (
            Translation.get_translation_stats_by_version(target.translation_version)
        )

        # 未翻訳の有無を確認
        if untranslated_count > 0:
            target.book.set_status("translating")
            formatted_elapsed_time = TranslationProcessUtil.format_elapsed_time(target)
            if formatted_elapsed_time:
                target.batch.status_message = f"{total_count - untranslated_count}/{total_count} 翻訳済み ({formatted_elapsed_time})"
            else:
                target.batch.status_message = (
                    f"{total_count - untranslated_count}/{total_count} 翻訳済み"
                )
            target.batch.set_status("completed")
            target.batch.save(update_fields=["status_message"])
            logger.info("ステータスを'translating'に更新")
            return

        # タグエラーの有無に基づいてステータスを更新
        formatted_elapsed_time = TranslationProcessUtil.format_elapsed_time(target)
        if tag_error_count == 0:
            target.book.set_status("translated")
            if formatted_elapsed_time:
                target.batch.status_message = f"翻訳完了 ({formatted_elapsed_time})"
            else:
                target.batch.status_message = "翻訳完了"
            logger.info("ステータスを'translated'に更新")
        else:
            target.book.set_status("tag-error")
            if formatted_elapsed_time:
                target.batch.status_message = (
                    f"{error_line_count} タグエラー ({formatted_elapsed_time})"
                )
            else:
                target.batch.status_message = f"{error_line_count} タグエラー"
            logger.info("ステータスを'tag-error'に更新")

        target.batch.set_status("completed")
        target.batch.save(update_fields=["status_message"])

    @staticmethod
    def format_elapsed_time(target: TranslationTarget) -> str:
        """経過時間を時分秒でフォーマットする"""
        if target.batch.end_time and target.batch.start_time:
            elapsed_time = (target.batch.end_time - target.batch.start_time).total_seconds()
            hours, remainder = divmod(elapsed_time, 3600)
            minutes, seconds = divmod(remainder, 60)
            return f"{int(hours):02}:{int(minutes):02}:{int(seconds):02}"
        else:
            return ""
