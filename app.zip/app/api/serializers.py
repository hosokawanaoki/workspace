"""
シリアライザーモジュール

APIのレスポンスデータの形式を定義するシリアライザーを提供します。
"""

from typing import Any, Dict, Optional

from api.models.book import Book
from api.models.item import Item
from api.models.translation_batch import TranslationBatch
from api.models.translation_setting import TranslationSetting
from api.models.translation_version import TranslationVersion
from api.services.models.translation_batch_service import TranslationBatchService
from rest_framework import serializers


class TranslationSettingSerializer(serializers.ModelSerializer):
    """
    翻訳設定モデルのシリアライザー

    全てのフィールドをシリアライズします。
    """

    class Meta:
        model = TranslationSetting
        fields = "__all__"


class ItemSerializer(serializers.ModelSerializer):
    """
    アイテムモデルのシリアライザー

    全てのフィールドをシリアライズします。
    """

    class Meta:
        """Metaクラス - シリアライザーの設定を定義"""

        model = Item
        fields = "__all__"


class TranslationBatchSerializer(serializers.ModelSerializer):
    """
    翻訳バッチモデルのシリアライザー

    翻訳バッチの主要フィールドと関連する翻訳設定情報をシリアライズします。
    """

    translation_setting = serializers.SerializerMethodField()

    class Meta:
        model = TranslationBatch
        fields = [
            "batch_time",
            "status",
            "status_message",
            "model",
            "limit",
            "mode",
            "force_stop",
            "translation_setting",
            "start_time",
            "end_time",
            "elapsed_time",
        ]

    elapsed_time = serializers.SerializerMethodField()

    def get_elapsed_time(self, obj: TranslationBatch) -> Optional[float]:
        """経過時間を計算する"""
        if obj.start_time and obj.end_time:
            return (obj.end_time - obj.start_time).total_seconds()
        return None

    def get_translation_setting(self, obj: TranslationBatch) -> Optional[Dict[str, Any]]:
        """翻訳設定情報を取得する"""
        if obj.translation_setting:
            return {
                "id": obj.translation_setting.id,
                "name": obj.translation_setting.name,
            }
        return None


class TranslationVersionSerializer(serializers.ModelSerializer):
    """
    翻訳バージョンモデルのシリアライザー
    """

    class Meta:
        model = TranslationVersion
        fields = [
            "id",
            "version",
            "created_at",
            "updated_at",
            "status",
        ]


class BookSerializer(serializers.ModelSerializer):
    """
    書籍モデルのシリアライザー

    全てのフィールドと関連する翻訳バージョン情報をシリアライズします。
    """

    latest_batch = serializers.SerializerMethodField()
    versions = TranslationVersionSerializer(
        source="translationversion_set", many=True, read_only=True
    )

    class Meta:
        """Metaクラス - シリアライザーの設定を定義"""

        model = Book
        fields = [
            "id",
            "book_id",
            "provider",
            "original_id",
            "title",
            "title_jp",
            "author",
            "language",
            "downloads",
            "url",
            "copyright_status",
            "subject",
            "summary",
            "release_date",
            "status",
            "created_at",
            "updated_at",
            "latest_batch",
            "versions",
        ]

    def get_latest_batch(self, obj: Book) -> Optional[Dict[str, Any]]:
        """最新の翻訳バッチ情報を取得する"""
        latest_batch = TranslationBatchService.get_latest_for_book(obj)
        if latest_batch:
            return TranslationBatchSerializer(latest_batch).data
        return None
