"""
翻訳設定に関するビューを提供するモジュール
"""

from api.models.translation_setting import TranslationSetting
from api.serializers import TranslationSettingSerializer
from api.utils.llm.consts import LLM
from rest_framework import generics, mixins, status
from rest_framework.response import Response
from rest_framework.views import APIView


class LLMModelListView(APIView):
    """
    利用可能なLLMモデルの一覧を返すビュー

    GET: 利用可能なLLMモデルの一覧を返します
    """

    def get(self, request, *args, **kwargs):
        """利用可能なLLMモデルの一覧を返す"""
        models = []
        for key, value in LLM["MODEL_MAPPINGS"].items():
            models.append(
                {
                    "value": key,  # 内部キー
                    "label": value["label"],  # 表示名
                    "model_name": value["model_name"],  # 実際のモデル名
                }
            )
        return Response(models)


class TranslationSettingListView(generics.ListCreateAPIView, mixins.DestroyModelMixin):
    """
    翻訳設定の一覧を取得・作成するビュー

    GET: 翻訳設定の一覧を返します
    POST: 新しい翻訳設定を作成します
    DELETE: 翻訳設定を削除します
    """

    queryset = TranslationSetting.filter()
    serializer_class = TranslationSettingSerializer

    def create(self, request, *args, **kwargs):
        """新しい翻訳設定を作成する"""
        # 翻訳例の数を制限
        if "examples" in request.data and len(request.data["examples"]) > 3:
            return Response(
                {"error": "翻訳例は最大3つまでしか登録できません"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        return super().create(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        """翻訳設定を削除する"""
        instance = self.get_object()
        instance.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

    def update(self, request, *args, **kwargs):
        """翻訳設定を更新する"""
        # 翻訳例の数を制限
        if "examples" in request.data and len(request.data["examples"]) > 3:
            return Response(
                {"error": "翻訳例は最大3つまでしか登録できません"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        return super().update(request, *args, **kwargs)


class TranslationSettingDetailView(generics.RetrieveUpdateAPIView):
    """
    個別の翻訳設定を取得・更新するビュー

    GET: 指定されたIDの翻訳設定を返します
    PUT/PATCH: 指定されたIDの翻訳設定を更新します
    DELETE: 指定されたIDの翻訳設定を論理削除します
    """

    queryset = TranslationSetting.filter()
    serializer_class = TranslationSettingSerializer

    def update(self, request, *args, **kwargs):
        """翻訳設定を更新する"""
        # 翻訳例の数を制限
        if "examples" in request.data and len(request.data["examples"]) > 3:
            return Response(
                {"error": "翻訳例は最大3つまでしか登録できません"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        return super().update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        """翻訳設定を削除する"""
        instance = self.get_object()
        instance.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
