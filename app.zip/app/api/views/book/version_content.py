"""
書籍の特定バージョンの翻訳内容を取得するビュー
"""

from api.models.book import Book
from api.models.translation import Translation
from api.models.translation_version import TranslationVersion
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView


class VersionContentView(APIView):
    """書籍の特定バージョンの翻訳内容を取得するビュー"""

    def get(self, request, book_id, version_id):
        """
        書籍の特定バージョンの翻訳内容を取得する

        Args:
            request: リクエストオブジェクト
            book_id: 書籍ID
            version_id: バージョンID

        Returns:
            Response: レスポンスオブジェクト
        """
        try:
            book = Book.get_book_by_book_id(book_id)
            if not book:
                return Response(
                    {"error": "指定された書籍が見つかりません。"},
                    status=status.HTTP_404_NOT_FOUND,
                )

            version = TranslationVersion.get_version_by_book_and_version(book, version_id)
            translations = Translation.get_translations_by_version(version)
        except TranslationVersion.DoesNotExist:
            return Response(
                {"error": "指定されたバージョンが見つかりません。"},
                status=status.HTTP_404_NOT_FOUND,
            )
        except Exception as e:
            return Response(
                {"error": f"エラーが発生しました: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        # バージョン1の場合は原文との比較
        if version.version == 1:
            translation_pairs = [
                {
                    "previous_text": t.source_text,
                    "current_text": t.tag_recoveried if t.tag_recoveried else t.translated_text,
                }
                for t in translations
            ]
            return Response(
                {
                    "translations": translation_pairs,
                    "version_type": "original",
                    "previous_version": 1,
                    "current_version": version.version,
                }
            )

        # バージョン2以降は前のバージョンとの比較
        try:
            # 前のバージョンを取得
            previous_version = TranslationVersion.get_version_by_book_and_version(
                book, version.version - 1
            )
            previous_translations = Translation.get_translations_by_version(previous_version)

            # 前のバージョンと現在のバージョンの比較
            translation_pairs = []
            for current, previous in zip(translations, previous_translations):
                translation_pairs.append(
                    {
                        "previous_text": (
                            previous.tag_recoveried
                            if previous.tag_recoveried
                            else previous.translated_text
                        ),
                        "current_text": (
                            current.tag_recoveried
                            if current.tag_recoveried
                            else current.translated_text
                        ),
                    }
                )

            return Response(
                {
                    "translations": translation_pairs,
                    "version_type": "comparison",
                    "previous_version": version.version - 1,
                    "current_version": version.version,
                }
            )

        except TranslationVersion.DoesNotExist:
            return Response(
                {"error": "前のバージョンが見つかりません。"},
                status=status.HTTP_404_NOT_FOUND,
            )
        except Exception as e:
            return Response(
                {"error": f"バージョン比較中にエラーが発生しました: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
