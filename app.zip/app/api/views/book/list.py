"""書籍一覧を提供するAPIビューを定義するモジュール"""

import logging
from typing import Any

from api.models.book import Book
from api.serializers import BookSerializer
from django.db.models import QuerySet
from rest_framework.response import Response
from rest_framework.views import APIView

logger = logging.getLogger(__name__)


class BookListView(APIView):
    """書籍一覧を取得するAPIビュー"""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)

    def get(self, request: Any) -> Response:
        """書籍一覧を取得する

        Args:
            request: HTTPリクエスト

        Returns:
            Response: シリアライズされた書籍一覧（最新の翻訳バッチ情報を含む）
        """
        books: QuerySet[Book] = Book.get_all_books_with_batch()
        serializer = BookSerializer(books, many=True)
        return Response(serializer.data)
