"""
LLM（大規模言語モデル）を使用した翻訳機能を提供するAPIビューを定義するモジュール
"""

import logging
from typing import Optional, TypedDict

from api.services.book.implementations.book_batch_service_impl import (
    BookBatchServiceImpl,
)
from rest_framework import status
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.views import APIView


class TranslationRequest(TypedDict):
    """翻訳リクエストの型定義"""

    original_id: str
    translation_setting_id: int
    model: Optional[str]
    limit: Optional[int]
    start: Optional[int]
    version: Optional[int]


logger = logging.getLogger(__name__)


class TranslateView(APIView):
    """翻訳を実行するエンドポイント"""

    def __init__(self, book_batch_service=None, *args, **kwargs):
        """初期化

        Args:
            book_batch_service: 書籍バッチサービス（省略時はデフォルト）
        """
        super().__init__(*args, **kwargs)
        self.book_batch_service = book_batch_service or BookBatchServiceImpl()

    def post(self, request: Request) -> Response:
        """LLMを使用して翻訳バッチを作成するエンドポイント

        Args:
            request: HTTPリクエスト (TranslationRequest型)
                - book_id: 翻訳する書籍のID
                - translation_setting_id: 翻訳設定ID
                - model: 使用するモデル名（オプション）
                - limit: 開発モードのモデル読み込み回数制限（オプション、デフォルト1000）
                - start: 開始するchunk番号（オプション、デフォルト1）

        Returns:
            Response: 処理結果とステータスコード
        """
        data = request.data
        logger.info("Received LLM translation request: %s", data)

        # Required parameters
        original_id = data.get("original_id")
        provider_id = data.get("provider_id")
        translation_setting_id = data.get("translation_setting_id")
        limit = data.get("limit", 1000)
        limit = int(limit)
        version = data.get("version", 1)
        version = int(version)

        if not original_id or not provider_id or translation_setting_id is None:
            return Response(
                {
                    "error": (
                        "original_id、provider_id、translation_setting_idは"
                        "必須パラメータです。"
                    )
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Optional parameters
        model = data.get("model", "claude")
        language = data.get("language", "ja")

        # book_idを組み合わせた形式に変換
        book_id = f"{provider_id}_{model}_{language}_{original_id}"

        try:
            # 翻訳バッチの作成
            self.book_batch_service.create_translation_batch(
                book_id=book_id,
                translation_setting_id=translation_setting_id,
                limit=limit,
                model=model,
                provider=provider_id,
                original_id=original_id,
                language=language,
                version=version,
            )
            return Response(
                {
                    "message": "即時翻訳を開始しました。スケジューラーが1分以内に処理を開始します。"
                },
                status=status.HTTP_200_OK,
            )

        except ValueError as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except (IOError, RuntimeError) as e:
            logger.error("Batch creation error: %s", str(e))
            return Response(
                {"error": f"エラーが発生しました: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
