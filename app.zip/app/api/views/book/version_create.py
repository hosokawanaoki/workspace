"""
書籍の新しいバージョンを作成するAPIビューを定義するモジュール
"""

import logging
from typing import TypedDict

from api.services.book.implementations.book_batch_service_impl import (
    BookBatchServiceImpl,
)
from rest_framework import status
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.views import APIView


class VersionCreateRequest(TypedDict):
    """バージョン作成リクエストの型定義"""

    version_name: str
    correction_instruction: str


logger = logging.getLogger(__name__)


class VersionCreateView(APIView):
    """新しいバージョンを作成するエンドポイント"""

    def __init__(self, book_batch_service=None, *args, **kwargs):
        """初期化

        Args:
            book_batch_service: 書籍バッチサービス（省略時はデフォルト）
        """
        super().__init__(*args, **kwargs)
        self.book_batch_service = book_batch_service or BookBatchServiceImpl()

    def post(self, request: Request, book_id: str) -> Response:
        """新しいバージョンを作成するエンドポイント

        Args:
            request: HTTPリクエスト (VersionCreateRequest型)
                - version_name: 新しいバージョンの名前
                - correction_instruction: 校正指示
            book_id: 書籍ID

        Returns:
            Response: 処理結果とステータスコード
                - version_id: 作成されたバージョンのID
                - batch_id: 作成されたバッチのID
                - status: バッチのステータス ("waiting")
        """
        data = request.data
        logger.info("Received version creation request: %s", data)

        # Required parameters
        version_name = data.get("version_name")
        correction_instruction = data.get("correction_instruction")

        if not version_name or not correction_instruction:
            return Response(
                {"error": "version_nameとcorrection_instructionは必須パラメータです。"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            # 新しいバージョンとバッチの作成
            result = self.book_batch_service.create_correction_batch(
                book_id=book_id,
                version_name=version_name,
                correction_instruction=correction_instruction,
            )

            return Response(
                {
                    "version_id": result["version_id"],
                    "batch_id": result["batch_id"],
                    "status": "waiting",
                    "message": "校正バッチを作成しました。スケジューラーが1分以内に処理を開始します。",
                },
                status=status.HTTP_200_OK,
            )

        except ValueError as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except (IOError, RuntimeError) as e:
            logger.error("Batch creation error: %s", str(e))
            return Response(
                {"error": f"エラーが発生しました: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
