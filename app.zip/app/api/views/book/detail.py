from api.models import Book
from api.serializers import BookSerializer
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView


class BookDetailView(APIView):
    """書籍の詳細取得・更新を行うビュー"""

    def get(self, request, book_id):
        """書籍の詳細情報を取得する

        Args:
            request: リクエスト
            book_id: 書籍ID

        Returns:
            Response: レスポンス
        """
        try:
            book = Book.get_book_by_book_id(book_id)
            if not book:
                return Response(
                    {"error": "指定された書籍が見つかりません"},
                    status=status.HTTP_404_NOT_FOUND,
                )
            serializer = BookSerializer(book)
            return Response(serializer.data)
        except Exception as e:
            return Response(
                {"error": f"エラーが発生しました: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    def put(self, request, book_id):
        """書籍情報を更新する（PUTメソッド）

        Args:
            request: リクエスト
            book_id: 書籍ID

        Returns:
            Response: レスポンス
        """
        try:
            book = Book.get_book_by_book_id(book_id)
            if not book:
                return Response(
                    {"error": "指定された書籍が見つかりません"},
                    status=status.HTTP_404_NOT_FOUND,
                )
            serializer = BookSerializer(book, data=request.data, partial=True)

            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)

            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST,
            )
        except Exception as e:
            return Response(
                {"error": f"エラーが発生しました: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    def post(self, request, book_id):
        """書籍情報を更新する（POSTメソッド）

        Args:
            request: リクエスト
            book_id: 書籍ID

        Returns:
            Response: レスポンス
        """
        try:
            book = Book.get_book_by_book_id(book_id)
            if not book:
                return Response(
                    {"error": "指定された書籍が見つかりません"},
                    status=status.HTTP_404_NOT_FOUND,
                )
            serializer = BookSerializer(book, data=request.data, partial=True)

            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)

            return Response(
                serializer.errors,
                status=status.HTTP_400_BAD_REQUEST,
            )
        except Exception as e:
            return Response(
                {"error": f"エラーが発生しました: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
