from django.db import models

from .base import BaseModel
from .mixins.db_operation_mixin import DBOperationMixin


class TranslationSetting(BaseModel, DBOperationMixin):
    """翻訳設定マスターモデル"""

    name = models.CharField(
        max_length=255, verbose_name="名前", help_text="翻訳パターンの名称"
    )

    constraints = models.TextField(
        verbose_name="制約事項", help_text="翻訳時の制約条件", blank=True, null=True
    )

    examples = models.JSONField(
        verbose_name="翻訳例",
        help_text="翻訳例のリスト（最大3つ）。各要素は{'before': '翻訳前', 'after': '翻訳後'}の形式",
        blank=True,
        null=True,
    )

    class Meta:
        verbose_name = "翻訳設定マスター"
        verbose_name_plural = "翻訳設定マスター"
        ordering = ["id"]

    def __str__(self):
        return f"{self.id}: {self.name}"
