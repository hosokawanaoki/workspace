import logging

from api.models.base import BaseModel
from api.models.mixins.db_operation_mixin import DBOperationMixin
from api.models.mixins.status_operation_mixin import StatusOperationMixin
from django.db import models

logger = logging.getLogger(__name__)


class TranslationBatch(BaseModel, DBOperationMixin, StatusOperationMixin):
    """翻訳バッチ実行を管理するモデル

    Attributes:
        book: 翻訳対象の書籍
        batch_time: バッチ実行時間
        status: バッチの状態
    """

    # 状態の選択肢
    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("processing", "Processing"),
        ("completed", "Completed"),
        ("failed", "Failed"),
        ("stopped", "Stopped"),
    ]

    # 処理モードの選択肢
    MODE_CHOICES = [
        ("translation", "Translation"),
        ("correction", "Correction"),
    ]

    # 処理モード
    mode = models.CharField(
        max_length=20,
        choices=MODE_CHOICES,
        default="translation",
        verbose_name="処理モード",
        help_text="翻訳または校正の処理モード",
    )

    # 校正指示
    correction_instruction = models.TextField(
        null=True,
        blank=True,
        verbose_name="校正指示",
        help_text="校正モード時の指示内容",
    )

    # 翻訳対象の書籍ID
    book = models.ForeignKey("api.Book", on_delete=models.CASCADE)

    # バッチ実行時間（更新時に自動更新）
    batch_time = models.DateTimeField(auto_now=True)

    # バッチの状態
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="pending")

    # 翻訳設定
    translation_setting = models.ForeignKey(
        "TranslationSetting",
        on_delete=models.SET_NULL,
        null=True,
        verbose_name="翻訳設定",
        help_text="使用する翻訳設定",
    )

    # 使用するLLMモデル
    model: str = models.CharField(max_length=50, null=True, default="claude")

    # 翻訳対象言語
    target_language = models.CharField(max_length=30, default="ja")

    # 制限数
    limit = models.IntegerField(null=True, default=1000)

    # 開始位置
    start = models.IntegerField(null=True, default=1)

    # 強制停止フラグ
    force_stop = models.BooleanField(default=False)

    # リトライ関連のフィールド
    retry_count = models.IntegerField(default=0)
    last_retry_time = models.DateTimeField(null=True)
    max_retries = models.IntegerField(default=3)

    # 翻訳バージョン
    translation_version = models.ForeignKey(
        "TranslationVersion",
        on_delete=models.CASCADE,
        null=True,
        verbose_name="翻訳バージョン",
        help_text="関連する翻訳バージョン",
    )

    # バッチの状況を説明するメッセージ
    status_message = models.CharField(
        max_length=100,
        null=True,
        blank=True,
        verbose_name="状況メッセージ",
        help_text="バッチの現在の状況を説明するメッセージ（例：タグエラー 5/100件）",
    )

    # AI実行開始時刻
    start_time = models.DateTimeField(null=True)

    # AI実行終了時刻
    end_time = models.DateTimeField(null=True)

    def __str__(self):
        return f"{self.book.title} - {self.status}"

    def stop_translation(self) -> None:
        """翻訳を強制停止する"""
        self.force_stop = True
        self.set_status("force-stopped", identifier_field="id")

    @classmethod
    def get_status_type(cls, status: str) -> str:
        """ステータスの型チェックを行い、有効な場合はそのまま返す

        Args:
            status (str): チェックするステータス

        Returns:
            str: 有効なステータス

        Raises:
            ValueError: 無効なステータスの場合
        """
        if any(status == s for s, _ in cls.STATUS_CHOICES):
            return status
        raise ValueError(f"Invalid batch status: {status}")

    def set_status(self, new_status: str) -> None:
        """ステータスを更新する

        Args:
            new_status (str): 新しいステータス
        """
        validated_status = self.get_status_type(new_status)
        super().set_status(validated_status, identifier_field="id")

    @property
    def get_model(self) -> str:
        """使用するモデルを取得する

        Returns:
            str: モデル名（デフォルト: claude）

        Note:
            このプロパティは必ずstr型を返します。
            modelフィールドがNoneの場合はデフォルト値を返します。
        """
        model: str = self.model if self.model is not None else "claude"
        return model

    def update_translation_progress(self, current_index: int, total_chunks: int) -> None:
        """翻訳の進捗状況を更新する

        Args:
            current_index (int): 現在の翻訳インデックス
            total_chunks (int): 翻訳チャンクの総数

        Note:
            - 進捗状況を「current_index/total_chunks」の形式で表示
        """
        self.status_message = f"翻訳中..{current_index + 1}/{total_chunks}"
        self.save(update_fields=["batch_time", "status_message"])

    def update_correction_progress(self, current_index: int, total_chunks: int) -> None:
        """校正の進捗状況を更新する

        Args:
            current_index (int): 現在の校正インデックス
            total_chunks (int): 校正チャンクの総数

        Note:
            - 進捗状況を「current_index/total_chunks」の形式で表示
        """
        self.status_message = f"校正中..{current_index + 1}/{total_chunks}"
        self.save(update_fields=["batch_time", "status_message"])

    def has_reached_max_retries(self) -> bool:
        """最大リトライ回数に達したかどうかを確認する

        Returns:
            bool: 最大リトライ回数に達している場合はTrue
        """
        return self.retry_count >= self.max_retries
