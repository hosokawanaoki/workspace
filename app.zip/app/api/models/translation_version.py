import logging

from api.models.base import BaseModel
from api.models.book import Book
from django.db import models

logger = logging.getLogger(__name__)


class TranslationVersionStatus:
    """翻訳バージョンの状態を表す定数"""

    CHUNKED = "chunked"  # チャンク化済
    TRANSLATING = "translating"  # 翻訳中
    TRANSLATED = "translated"  # 翻訳済
    TAG_RECOVERED = "tag_recovered"  # タグ修復済
    CORRECTED = "corrected"  # 校正済


class TranslationVersion(BaseModel):
    """翻訳バージョンを管理するモデル

    書籍の翻訳の各バージョンを管理します。
    校正や修正などで生じる翻訳の異なるバージョンを追跡します。
    """

    # 関連する書籍
    book = models.ForeignKey(
        Book,
        on_delete=models.CASCADE,
        db_comment="api_book.Book モデルへの参照。翻訳対象となる書籍を示す。",
        help_text="翻訳対象の書籍（api_book.Book）",
    )

    # バージョン番号
    version = models.IntegerField()

    # バージョンの説明
    description = models.TextField(null=True, blank=True)

    # ステータス
    status = models.CharField(
        max_length=20,
        choices=[
            (TranslationVersionStatus.CHUNKED, "チャンク化済"),
            (TranslationVersionStatus.TRANSLATING, "翻訳中"),
            (TranslationVersionStatus.TRANSLATED, "翻訳済"),
            (TranslationVersionStatus.TAG_RECOVERED, "タグ修復済"),
            (TranslationVersionStatus.CORRECTED, "校正済"),
        ],
        default=TranslationVersionStatus.CHUNKED,
    )

    class Meta:
        unique_together = ["book", "version"]
        indexes = [
            models.Index(fields=["book", "version"]),
        ]

    def __str__(self) -> str:
        return f"{self.book.title} - Version {self.version}"

    @classmethod
    def get_version_by_book_and_version(
        cls, book: "Book", version_id: int
    ) -> "TranslationVersion":
        """書籍とバージョンIDから翻訳バージョンを取得する

        Args:
            book (Book): 書籍オブジェクト
            version_id (int): バージョンID

        Returns:
            TranslationVersion: 翻訳バージョン

        Raises:
            TranslationVersion.DoesNotExist: 指定されたバージョンが存在しない場合
        """
        version = cls.get(version=version_id, book=book)
        if not version:
            raise cls.DoesNotExist(
                f"Version {version_id} for book {book.book_id} does not exist"
            )
        return version

    @classmethod
    def get_versions_by_book(cls, book_id: str) -> list["TranslationVersion"]:
        """書籍IDに関連する翻訳バージョンを取得する

        Args:
            book_id (str): 書籍ID

        Returns:
            list[TranslationVersion]: 翻訳バージョンのリスト（バージョン番号の降順）
        """
        from api.models.book import Book

        book = Book.get_book_by_book_id(book_id)
        if not book:
            return []
        return list(cls.filter(book=book).order_by("-version").all())

    @classmethod
    def get_version_history_by_book(cls, book_id: str) -> list["TranslationVersion"]:
        """書籍IDに関連する翻訳バージョン履歴を取得する

        論理削除されたレコードも含めて取得します。

        Args:
            book_id (str): 書籍ID

        Returns:
            list[TranslationVersion]: 翻訳バージョンのリスト（作成日時の降順）
        """
        from api.models.book import Book

        book = Book.get_book_by_book_id(book_id)
        if not book:
            return []
        return list(cls.filter(book=book).order_by("-created_at").all())

    @classmethod
    def get_or_create_version(
        cls, book: "Book", version_number: int = 1
    ) -> "TranslationVersion":
        """バージョンを取得、存在しない場合は作成する

        Args:
            book (Book): 書籍オブジェクト
            version_number (int, optional): バージョン番号. デフォルトは1.

        Returns:
            TranslationVersion: 取得または作成されたバージョン
        """

        logger.info(
            f"書籍ID {book.book_id} のバージョン {version_number} を取得または作成"
        )
        version = cls.get(book=book, version=version_number)
        if version:
            logger.info(
                f"書籍ID {book.book_id} の既存バージョン {version_number} を取得: status={version.status}"
            )
            return version

        logger.info(
            f"書籍ID {book.book_id} の既存バージョン {version_number} が見つかりません"
        )
        logger.info(f"書籍ID {book.book_id} の新規バージョン {version_number} を作成")
        try:
            version = cls.objects.create(
                book=book,
                version=version_number,
                status=TranslationVersionStatus.CHUNKED,
            )
            logger.info(
                f"書籍ID {book.book_id} のバージョン {version_number} を作成完了: status={version.status}"
            )
            return version
        except Exception as e:
            logger.error(
                f"書籍ID {book.book_id} のバージョン {version_number} 作成に失敗: {str(e)}"
            )
            raise
