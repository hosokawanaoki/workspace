from datetime import date
from typing import Dict, List, Optional, Union

from api.models.base import BaseModel
from api.models.mixins.db_operation_mixin import DBOperationMixin
from api.models.mixins.status_operation_mixin import StatusOperationMixin
from api.services.types.book_info import CombinedBookInfo
from django.db import models
from django.db.models import QuerySet


class Book(BaseModel, DBOperationMixin, StatusOperationMixin):
    """Project Gutenbergの書籍情報を管理するモデル

    このモデルは、Project Gutenbergから取得した書籍の情報を保存し、
    翻訳状態を管理するために使用されます。

    Attributes:
        book_id: Project Gutenbergの書籍ID
        title: 原語の書籍タイトル
        title_jp: 日本語に翻訳された書籍タイトル
        author: 著者名
        language: 書籍の原語（例: "en" for English）
        downloads: Project Gutenbergでのダウンロード数
        url: Project Gutenbergでの書籍URL
        copyright_status: 著作権状態
        subject: 書籍のジャンルや主題
        summary: 書籍の要約
        release_date: Project Gutenbergでのリリース日
        status: 翻訳処理の状態
    """

    # 書籍ID: 一意な文字列フィールド (例: prefix_deepseek_en_1234)
    book_id = models.CharField(max_length=200, unique=True)

    # プロバイダー: 書籍の提供元（例: gutenberg）
    provider = models.CharField(max_length=50, null=True)

    # 元のサイトでの書籍ID（例: Gutenbergでの数値ID）
    original_id = models.CharField(max_length=50, null=True)

    @staticmethod
    def create_book_id(prefix: str, raw_id: int, model: str, language: str) -> str:
        """book_idを生成する

        Args:
            prefix (str): プレフィックス（例: gutenberg）
            raw_id (int): 元のbook_id（数値）
            model (str): モデル名
            language (str): 言語コード

        Returns:
            str: 生成されたbook_id (例: prefix_deepseek_en_1234)
        """
        return f"{prefix}_{model}_{language}_{raw_id}"

    # 書籍タイトル: 原文
    title = models.CharField(max_length=200, null=True)

    # 書籍タイトルjp: 翻訳後
    title_jp = models.CharField(max_length=200, null=True)

    # 著者名: 最大500文字の文字列
    author = models.CharField(max_length=500, null=True)

    # 書籍の原語: 最大50文字の文字列（例: "en", "fr"）
    language = models.CharField(max_length=50, null=True)

    # Project Gutenbergでのダウンロード数
    downloads = models.IntegerField(null=True)

    # Project GutenbergのURL: 最大200文字の文字列
    url = models.CharField(max_length=200, null=True)

    # 著作権状態: 最大100文字の文字列（例: "Public domain in the USA."）
    copyright_status = models.CharField(max_length=100, null=True)

    # 書籍のジャンル/主題: 最大200文字の文字列
    subject = models.CharField(max_length=200, null=True)

    # 書籍の要約: 最大8000文字の文字列
    summary = models.CharField(max_length=8000, null=True)
    # リリース日: 日付フィールド
    release_date = models.DateField(null=True)

    # 状態: 翻訳状態を管理
    STATUS_CHOICES = [
        ("raw", "Raw"),  # 翻訳前
        ("waiting", "Waiting"),  # 待機中
        ("ai-execution", "Ai-execution"),  # AI実行中
        ("translating", "Translating"),  # 翻訳途中
        ("translated", "Translated"),  # 翻訳済
        ("tag-error", "Tag-Error"),  # タグエラーあり
        ("error", "Error"),  # エラーあり
        ("complete", "Complete"),  # 完了
        ("notfound", "NotFound"),  # ファイルが存在しない
        ("cancel", "Cancel"),  # キャンセル
    ]
    status = models.CharField(
        max_length=12,
        choices=STATUS_CHOICES,
        default="raw",
    )

    def __str__(self):
        return self.title

    def set_status(self, new_status: str) -> None:
        """ステータスを更新する

        Args:
            new_status (str): 新しいステータス
        """
        super().set_status(new_status, identifier_field="book_id")

    @classmethod
    def get_book_by_book_id(cls, book_id: str) -> Optional["Book"]:
        """書籍IDから書籍を取得する

        Args:
            book_id (int): 書籍ID

        Returns:
            Book: 書籍オブジェクト。存在しない場合はNone
        """
        return cls.get(book_id=book_id)

    @classmethod
    def update_or_create_book(
        cls, book_id: str, data: Optional[Union[Dict, CombinedBookInfo]] = None
    ) -> tuple["Book", bool]:
        """Bookのupdate_or_create操作を実行

        Args:
            book_id (str): 書籍ID
            data (Optional[Dict], optional): 更新データ. Defaults to None.

        Returns:
            tuple[Book, bool]: (Bookインスタンス, 作成フラグ)
        """
        defaults = {"release_date": str(date.today())}

        return cls.update_or_create_record(
            identifier={"book_id": book_id}, data=data, defaults=defaults
        )

    @classmethod
    def get_executing_books(cls) -> "QuerySet[Book]":
        """AI実行中の書籍を取得する

        Returns:
            QuerySet[Book]: AI実行中の書籍のクエリセット
        """
        return cls.filter(status="ai-execution")

    @classmethod
    def get_executing_books_for_stalled_check(cls) -> "QuerySet[Book]":
        """停止したバッチの検出用にAI実行中の書籍を取得する

        Note:
            - 内部結合を使用して、translationbatchが存在する書籍のみを取得
            - FOR UPDATEとの互換性のために外部結合を避ける

        Returns:
            QuerySet[Book]: AI実行中の書籍のクエリセット（翻訳バッチ情報を含む）
        """
        return (
            cls.objects.filter(status="ai-execution", translationbatch__isnull=False)
            .select_related("translationbatch_set")
            .distinct()
        )

    @classmethod
    def get_waiting_books(cls) -> List["Book"]:
        """翻訳待ちの書籍を取得する

        Returns:
            List[Book]: 翻訳待ち状態の書籍のリスト
        """
        return list(cls.filter(status="waiting"))

    @classmethod
    def get_all_books_with_batch(cls) -> "QuerySet[Book]":
        """全ての書籍を最新の翻訳バッチ情報と共に取得する

        Returns:
            QuerySet[Book]: 書籍のクエリセット（翻訳バッチ情報を含む）
        """
        return cls.filter(
            prefetch_fields=[
                "translationbatch_set",
                "translationbatch_set__translation_setting",
            ]
        )

    @classmethod
    def is_valid_status(cls, status: str) -> bool:
        """ステータスが有効かどうかをチェックする

        Args:
            status (str): チェックするステータス

        Returns:
            bool: 有効なステータスの場合True
        """
        return any(status == s for s, _ in cls.STATUS_CHOICES)

    @classmethod
    def get_status_type(cls, status: str) -> str:
        """ステータスの型チェックを行い、有効な場合はそのまま返す

        Args:
            status (str): チェックするステータス

        Returns:
            str: 有効なステータス

        Raises:
            ValueError: 無効なステータスの場合
        """
        if cls.is_valid_status(status):
            return status
        raise ValueError(f"Invalid status: {status}")

    def update_book_info(self, title: Optional[str], author: Optional[str]) -> None:
        """書籍情報を更新する

        Args:
            title (Optional[str]): 新しいタイトル（Noneの場合は更新しない）
            author (Optional[str]): 新しい著者（Noneの場合は更新しない）
        """
        if title and not self.title:
            self.title = title
        if author and not self.author:
            self.author = author
        self.save()

    def refresh_book(self) -> None:
        """bookを再取得する

        Note:
            - DBから最新のbook情報を取得して更新する
            - キャンセル状態の変更を検知するために使用
        """
        self.refresh_from_db()

    def is_waiting(self) -> bool:
        """待機状態かどうかを確認する

        Returns:
            bool: 待機状態の場合はTrue
        """
        return self.status == self.get_status_type("waiting")

    def is_cancelled(self) -> bool:
        """キャンセル状態かどうかを確認する

        Returns:
            bool: キャンセル状態の場合はTrue
        """
        return self.status == self.get_status_type("cancel")

    @property
    def needs_info_update(self) -> bool:
        """書籍情報の更新が必要かどうかを確認する

        Returns:
            bool: タイトルまたは著者が未設定の場合はTrue
        """
        return not self.title or not self.author
