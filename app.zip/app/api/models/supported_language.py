from api.models.base import BaseModel
from django.db import models


class SupportedLanguage(BaseModel):
    """サポートする言語を管理するモデル"""

    # 言語コード (例: 'ja', 'en', 'zh' など)
    language_code = models.CharField(max_length=10, unique=True)

    # 言語名 (例: '日本語', 'English', '中文' など)
    language_name = models.CharField(max_length=50)

    # 有効/無効フラグ
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.language_name} ({self.language_code})"
