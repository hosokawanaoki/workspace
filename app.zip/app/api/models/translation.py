from api.models.base import BaseModel
from api.models.translation_version import TranslationVersion
from django.db import models


class Translation(BaseModel):
    """翻訳テキストを管理するモデル

    翻訳前後のテキストやタグ情報などを保存します。
    多言語対応のため、言語コードも含めて管理します。
    """

    # 関連する翻訳バージョン
    translation_version = models.ForeignKey(TranslationVersion, on_delete=models.CASCADE)

    # 翻訳先言語コード (例: 'ja', 'en', 'zh' など)
    target_language = models.CharField(max_length=10)

    # 行ID（一意の識別子）
    line_id = models.IntegerField()

    # 行番号
    line_number = models.IntegerField()

    # チャンク番号
    chunk_count = models.IntegerField()

    # チャンク最大数
    chunk_max = models.IntegerField()

    # 原文テキスト
    source_text = models.TextField()

    # 翻訳テキスト
    translated_text = models.TextField(null=True)

    # タグ修正後のテキスト
    tag_recoveried = models.TextField(null=True)

    # 原文のタグリスト
    source_tags = models.JSONField(null=True)

    # 翻訳文のタグリスト
    translated_tags = models.JSONField(null=True)

    # 欠落タグリスト
    missing_tags = models.JSONField(null=True)

    # 余分タグリスト
    extra_tags = models.JSONField(null=True)

    # 重複タグリスト
    duplicate_tags = models.JSONField(null=True)

    # 翻訳状態
    # 1: CHUNKED (チャンク化済)
    # 2: TRANSLATED (翻訳済)
    # 3: TAG_RECOVERED (タグ修復済)
    status = models.IntegerField(default=1)  # デフォルトはCHUNKED

    class Meta:
        # line_id、target_language、translation_versionでユニーク制約
        unique_together = ["line_id", "target_language", "translation_version"]
        # インデックス
        indexes = [
            models.Index(fields=["translation_version"]),
            models.Index(fields=["line_id"]),
        ]

    def __str__(self) -> str:
        version_info = (
            f"(Version {self.translation_version.version})" if self.translation_version else ""
        )
        book_title = (
            self.translation_version.book.title if self.translation_version else "Unknown Book"
        )
        return f"{book_title} - {self.target_language} - Line {self.line_number} {version_info}"

    @classmethod
    def delete_by_version(cls, version: "TranslationVersion") -> None:
        """翻訳バージョンに関連する翻訳を削除する

        Args:
            version (TranslationVersion): 翻訳バージョン
        """
        cls.objects.filter(translation_version=version).delete()

    @classmethod
    def get_translations_by_version(
        cls, translation_version: TranslationVersion
    ) -> list["Translation"]:
        """翻訳バージョンに関連する翻訳を取得する

        Args:
            translation_version (TranslationVersion): 翻訳バージョン

        Returns:
            list[Translation]: 翻訳のリスト（作成日時順）
        """
        return list(
            cls.objects.filter(translation_version=translation_version).order_by("created_at").all()
        )

    @classmethod
    def get_translation_stats_by_version(
        cls, translation_version: TranslationVersion
    ) -> tuple[int, int, int, int]:
        """翻訳バージョンの統計情報を取得する

        Args:
            translation_version (TranslationVersion): 翻訳バージョン

        Returns:
            tuple[int, int, int, int]: (タグエラー数, 未翻訳数, エラー行数, 全体行数)のタプル
        """
        translations = cls.get_translations_by_version(translation_version)
        total_count = len(translations)

        # タグエラーの個数を計算
        tag_error_count = sum(
            len(t.missing_tags or []) + len(t.extra_tags or []) + len(t.duplicate_tags or [])
            for t in translations
        )

        # タグエラーがある行数を計算
        error_line_count = sum(
            1
            for t in translations
            if (t.missing_tags and len(t.missing_tags) > 0)
            or (t.extra_tags and len(t.extra_tags) > 0)
            or (t.duplicate_tags and len(t.duplicate_tags) > 0)
        )

        # 未翻訳数を計算（statusがCHUNKEDのものをカウント）
        from api.services.types.translator import TranslationStatus

        untranslated_count = sum(1 for t in translations if t.status == TranslationStatus.CHUNKED)

        return tag_error_count, untranslated_count, error_line_count, total_count
