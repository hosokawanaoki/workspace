from api.models.mixins.db_operation_mixin import DBOperationMixin
from api.models.mixins.status_operation_mixin import StatusOperationMixin
from django.db import models


class BaseModel(DBOperationMixin, StatusOperationMixin, models.Model):
    """全モデルの基底クラス"""

    created_at = models.DateTimeField("作成日時", auto_now_add=True)
    updated_at = models.DateTimeField("更新日時", auto_now=True)

    class Meta:
        abstract = True
