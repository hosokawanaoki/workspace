import logging
from typing import Any, Dict, Optional, Tuple, Type, TypeVar

from django.db import models
from django.db.models.query import QuerySet

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=models.Model)


class DBOperationMixin:
    """データベース操作の共通機能を提供するMixin

    このMixinは、モデルの基本的なCRUD操作を共通化します。
    """

    @classmethod
    def get_latest(cls: Type[T], **kwargs) -> Optional[T]:
        """最新のレコードを取得する

        Args:
            **kwargs: フィルタ条件

        Returns:
            Optional[T]: 最新のレコード、存在しない場合はNone
        """
        try:
            return cls.objects.filter(**kwargs).first()
        except Exception as e:
            logger.error(f"Failed to get latest record: {str(e)}")
            return None

    @classmethod
    def get(cls: Type[T], **kwargs) -> Optional[T]:
        """レコードを取得する

        Args:
            **kwargs: フィルタ条件

        Returns:
            Optional[T]: 該当するレコード、存在しない場合はNone
        """
        try:
            return cls.objects.filter(**kwargs).first()
        except Exception as e:
            logger.error(f"Failed to get record: {str(e)}")
            return None

    @classmethod
    def update_or_create_record(
        cls: Type[T],
        identifier: Dict[str, Any],
        data: Optional[Dict[str, Any]] = None,
        defaults: Optional[Dict[str, Any]] = None,
    ) -> Tuple[T, bool]:
        """レコードの更新または作成を行う

        Args:
            identifier (Dict[str, Any]): レコードを特定するための条件
            data (Optional[Dict[str, Any]], optional): 更新データ
            defaults (Optional[Dict[str, Any]], optional): デフォルト値

        Returns:
            Tuple[T, bool]: (インスタンス, 作成フラグ)
        """
        if defaults is None:
            defaults = {}

        # 既存のレコードを取得
        existing_record = cls.filter(**identifier).first()

        # デフォルト値の設定
        if existing_record:
            for field in cls._meta.fields:
                if field.name not in ["id", "created_at", "updated_at"]:
                    defaults[field.name] = getattr(existing_record, field.name)

        # 新しいデータで更新
        if data:
            defaults.update(data)

        return cls.objects.update_or_create(
            **identifier,
            defaults=defaults,
        )

    @classmethod
    def filter(
        cls: Type[T], prefetch_fields: Optional[list] = None, **kwargs
    ) -> QuerySet[T]:
        """複数のレコードを取得する

        Args:
            prefetch_fields (list, optional): prefetch_relatedで取得する関連フィールド
            **kwargs: フィルタ条件

        Returns:
            QuerySet[T]: フィルタされたクエリセット
        """
        queryset = cls.objects.filter(**kwargs)
        if prefetch_fields:
            queryset = queryset.prefetch_related(*prefetch_fields)
        return queryset

    @classmethod
    def exists_by_status(cls: Type[T], status: str) -> bool:
        """指定したステータスのレコードが存在するかチェックする

        Args:
            status (str): 検索するステータス

        Returns:
            bool: レコードが存在する場合はTrue
        """
        try:
            return bool(cls.filter(status=status).exists())
        except Exception as e:
            logger.error(f"Failed to check status existence: {str(e)}")
            return False

    @classmethod
    def update_status(cls: Type[T], id: int, status: str) -> T:
        """レコードのステータスを更新する

        Args:
            id (int): レコードID
            status (str): 新しいステータス

        Returns:
            T: 更新されたレコード
        """
        record, _ = cls.update_or_create_record(
            identifier={"id": id}, data={"status": status}
        )
        return record
