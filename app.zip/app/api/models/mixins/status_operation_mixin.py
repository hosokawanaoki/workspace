from typing import Optional, TypeVar

from django.db import models

T = TypeVar("T", bound=models.Model)


class StatusOperationMixin:
    """ステータス操作の共通機能を提供するMixin

    このMixinは、ステータスフィールドを持つモデルの操作を共通化します。
    """

    status: models.CharField = None

    def get_latest_status(self, identifier_field: str = "id") -> Optional[str]:
        """DBから最新のステータスを取得する

        Args:
            identifier_field (str): レコードを特定するためのフィールド名. Defaults to 'id'.

        Returns:
            Optional[str]: 最新のステータス、レコードが存在しない場合はNone
        """
        if not hasattr(self, "status"):
            raise AttributeError("モデルにstatusフィールドが存在しません")

        # 型チェック
        if not isinstance(self, models.Model):
            raise TypeError("このMixinはDjangoモデルでのみ使用できます")

        # 指定されたフィールドの存在確認
        if not hasattr(self, identifier_field):
            raise AttributeError(f"モデルに{identifier_field}フィールドが存在しません")

        # クラスから最新のレコードを取得
        identifier = {identifier_field: getattr(self, identifier_field)}
        latest_record = self.__class__.get(**identifier)  # type: ignore

        if latest_record:
            return latest_record.status
        return None

    def set_status(
        self, new_status: str, identifier_field: str = "id", save: bool = True
    ) -> None:
        """ステータスを更新する

        Args:
            new_status (str): 新しいステータス
            identifier_field (str): レコードを特定するためのフィールド名. Defaults to 'id'.
            save (bool, optional): 即座に保存するかどうか. Defaults to True.
        """
        if not hasattr(self, "status"):
            raise AttributeError("モデルにstatusフィールドが存在しません")

        # 指定されたフィールドの存在確認
        if not hasattr(self, identifier_field):
            raise AttributeError(f"モデルに{identifier_field}フィールドが存在しません")

        self.status = new_status
        if save:
            super().save(update_fields=["status"])
