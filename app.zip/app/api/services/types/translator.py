from typing import List, Optional

from pydantic import BaseModel


class TranslationStatus:
    CHUNKED = 1  # チャンク化済
    PROCESSED = 2  # 翻訳/校正済み（翻訳または校正が完了した状態）

    TAG_RECOVERED = 3  # タグ修復済
    # 最終状態の定数
    FINAL_STATUS = TAG_RECOVERED


class Translations(BaseModel):
    id: int
    line_number: int  # 元のHTMLの行番号
    chunk_count: int  # 元のHTMLの行を分割した現在カウント
    chunk_max: int  # 元のHTMLの行を分割した総数
    source_text: str  # 1
    translated_text: Optional[str] = None  # 2
    tag_recoveried: Optional[str] = None  # 3
    source_tags: Optional[List[str]] = None
    translated_tags: Optional[List[str]] = None
    missing_tags: Optional[List[str]] = None
    extra_tags: Optional[List[str]] = None
    duplicate_tags: Optional[List[str]] = None
    tag_recoveried_tags: Optional[List[str]] = None
    error_count: int = 0
    tag_error_count: dict[
        int, int
    ] = {}  # タグエラー数の履歴 {TranslationStatus: エラー数}
    status: int = TranslationStatus.CHUNKED  # デフォルトはチャンク化済


class TranslationInfos(BaseModel):
    timestamp: str
    model: str
    book_id: str  # Project Gutenbergの書籍ID
    batch_id: int  # 翻訳バッチID
    id: int  # データベースのBookモデルのID
    target_language: str = "ja"  # 翻訳対象言語（デフォルトは日本語）
    total_tag_errors: int = 0  # 全体のタグエラー数
    total_chunks: int = 0  # チャンク総数
    version: int = 1  # 翻訳バージョン（デフォルト: 1）


class TranslationsData(BaseModel):
    translation_info: TranslationInfos
    translations: List[Translations]
