"""スクレイピングの進捗を管理するモジュール"""

from dataclasses import dataclass
from typing import Dict, List


@dataclass
class ScrapingProgress:
    """スクレイピングの進捗情報を保持するクラス"""

    catalog: List[Dict]
    failed_ids: List[int]
    last_checked_id: int


class ProgressManager:
    """スクレイピングの進捗を管理するクラス"""

    def __init__(self):
        """ProgressManagerの初期化"""
        self.progress = ScrapingProgress([], [], 0)

    def load_progress(self) -> ScrapingProgress:
        """進捗情報を読み込む

        Returns:
            ScrapingProgress: 現在の進捗情報
        """
        return self.progress

    def save_progress(self, progress: ScrapingProgress) -> None:
        """進捗情報を保存する

        Args:
            progress (ScrapingProgress): 保存する進捗情報
        """
        self.progress = progress
