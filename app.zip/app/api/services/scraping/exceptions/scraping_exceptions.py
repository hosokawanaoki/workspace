"""スクレイピングサービスの例外を定義するモジュール"""

from rest_framework.exceptions import APIException


class GutenbergProcessingError(APIException):
    """Project Gutenbergの処理中に発生するエラー

    書籍のダウンロード、解凍、HTMLの処理などで発生するエラーを表します。
    """

    status_code = 500
    default_detail = "Project Gutenbergの処理中にエラーが発生しました"
    default_code = "gutenberg_processing_error"
