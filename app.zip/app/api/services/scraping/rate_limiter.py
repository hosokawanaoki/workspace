"""レート制限を管理するモジュール"""

import time
from typing import Optional


class RateLimiter:
    """リクエストのレート制限を管理するクラス"""

    def __init__(self, delay_seconds: float = 1.0):
        """RateLimiterの初期化

        Args:
            delay_seconds (float): リクエスト間の待機時間（秒）
        """
        self.delay_seconds = delay_seconds
        self._last_request_time: Optional[float] = None

    def wait(self) -> None:
        """次のリクエストまで待機する

        前回のリクエストからdelay_seconds経過するまで待機します。
        初回リクエスト時は待機しません。
        """
        if self._last_request_time is not None:
            elapsed = time.time() - self._last_request_time
            if elapsed < self.delay_seconds:
                time.sleep(self.delay_seconds - elapsed)
        self._last_request_time = time.time()

    def reset(self) -> None:
        """レート制限の状態をリセットする"""
        self._last_request_time = None
