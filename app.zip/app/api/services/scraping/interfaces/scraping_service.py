"""スクレイピングサービスのインターフェース"""

from abc import ABC, abstractmethod
from typing import Optional


class ScrapingService(ABC):
    """スクレイピングサービスのインターフェース"""

    @abstractmethod
    def start_scraping(
        self,
        start_id: Optional[int] = None,
        end_id: Optional[int] = None,
        max_books: Optional[int] = None,
    ) -> None:
        """スクレイピングを開始する

        Args:
            start_id: 開始ID（オプション）
            end_id: 終了ID（オプション）
            max_books: 最大取得数（オプション）

        Raises:
            ValueError: パラメータが不正な場合
            RuntimeError: スクレイピングに失敗した場合
        """
        pass

    @abstractmethod
    def stop_scraping(self) -> None:
        """スクレイピングを停止する

        Raises:
            RuntimeError: 停止に失敗した場合
        """
        pass

    @abstractmethod
    def get_progress(self) -> dict:
        """スクレイピングの進捗を取得する

        Returns:
            dict: 進捗情報
                - total: 合計処理数
                - current: 現在の処理数
                - status: 状態
                - errors: エラー情報
        """
        pass
