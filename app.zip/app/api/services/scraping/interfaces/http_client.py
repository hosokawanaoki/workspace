"""HTTPクライアントのインターフェースを定義するモジュール"""

from abc import ABC, abstractmethod
from typing import Dict, Optional

from api.services.scraping.interfaces.http_response import HttpResponse


class HttpClient(ABC):
    """HTTPクライアントのインターフェース"""

    @abstractmethod
    def get(self, url: str, headers: Optional[Dict[str, str]] = None) -> HttpResponse:
        """GETリクエストを送信する

        Args:
            url (str): リクエスト先のURL
            headers (Optional[Dict[str, str]]): リクエストヘッダー

        Returns:
            HttpResponse: レスポンスオブジェクト
        """
        pass

    @abstractmethod
    def set_headers(self, headers: Dict[str, str]) -> None:
        """デフォルトヘッダーを設定する

        Args:
            headers (Dict[str, str]): 設定するヘッダー
        """
        pass
