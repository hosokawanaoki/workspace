"""書籍情報をHTMLからパースするモジュール"""

from typing import Optional

from api.services.types.book_info import GutenbergBookInfo
from bs4 import BeautifulSoup, Tag


class BookParser:
    """書籍情報をHTMLからパースするクラス"""

    def parse_book_info(
        self, html: str, original_id: int, url: str
    ) -> GutenbergBookInfo:
        """HTMLから書籍情報を解析する

        Args:
            html (str): 解析対象のHTML
            original_id (int): Gutenberg書籍ID
            url (str): 書籍ページのURL

        Returns:
            Dict: 解析された書籍情報

        抽出する情報:
            - タイトル
            - 著者
            - 言語
            - ダウンロード数
            - リリース日
            - 著作権ステータス
            - 主題
            - カテゴリ
            - LoC分類
            - 概要
        """
        soup = BeautifulSoup(html, "html.parser")
        title = soup.find("h1", {"itemprop": "name"})
        author = soup.find("a", {"itemprop": "creator"})
        meta_table = soup.find("table", {"class": "bibrec"})

        title_tag = title if isinstance(title, Tag) else None
        author_tag = author if isinstance(author, Tag) else None
        meta_table_tag = meta_table if isinstance(meta_table, Tag) else None

        title_text = (
            title_tag.text.strip()
            if title_tag and hasattr(title_tag, "text")
            else "Unknown Title"
        )
        author_text = (
            author_tag.text.strip()
            if author_tag and hasattr(author_tag, "text")
            else "Unknown Author"
        )

        return GutenbergBookInfo(
            original_id=str(original_id),
            title=title_text,
            author=author_text,
            language=self._get_meta_value(meta_table_tag, "Language"),
            downloads=self._parse_downloads(
                self._get_meta_value(meta_table_tag, "Downloads", "0")
            ),
            copyright_status=self._get_meta_value(meta_table_tag, "Copyright Status"),
            subject=self._get_meta_value(meta_table_tag, "Subject"),
            summary=self._get_meta_value(meta_table_tag, "Summary"),
            url=url,
        )

    def _get_meta_value(
        self, soup: Optional[Tag], field_name: str, default: str = "Unknown"
    ) -> str:
        """メタデータの値を取得する

        Args:
            soup (Optional[Tag]): 解析対象のHTML要素
            field_name (str): 取得するフィールド名
            default (str): 値が見つからない場合のデフォルト値

        Returns:
            str: 取得したメタデータの値
        """
        if not soup:
            return default

        row = soup.find("th", string=lambda x: x and field_name.lower() in x.lower())
        if not row:
            return default

        sibling = row.find_next_sibling("td")
        if not sibling or not hasattr(sibling, "text"):
            return default

        return sibling.text.strip()

    def _parse_downloads(self, downloads: str) -> int:
        """ダウンロード数を解析する

        Args:
            downloads (str): ダウンロード数文字列

        Returns:
            int: 解析されたダウンロード数

        Note:
            - ダウンロード数は100単位で切り捨て
            - 数値以外の文字は除去
        """
        if downloads == "0":
            return 0
        return int("".join(filter(str.isdigit, downloads))) // 100
