import logging
from dataclasses import dataclass
from typing import Dict, Optional

from api.services.scraping.gutenberg_scraper import GutenbergScraper, ScraperConfig
from api.services.scraping.interfaces.scraping_service import ScrapingService

logger = logging.getLogger(__name__)


@dataclass
class ScrapingResult:
    """スクレイピング結果を表すデータクラス

    Attributes:
        status (str): 処理状態 ("success" | "interrupted" | "error")
        message (str): 処理結果メッセージ
    """

    status: str
    message: str

    def to_dict(self) -> Dict[str, str]:
        """辞書形式に変換する

        Returns:
            Dict[str, str]: 辞書形式のスクレイピング結果
        """
        return {"status": self.status, "message": self.message}


class ScrapingServiceImpl(ScrapingService):
    """スクレイピングサービスの実装クラス

    Project Gutenbergからの書籍情報スクレイピングを管理します。
    エラーハンドリングとログ出力を適切に行い、スクレイピングの
    進捗状況を追跡します。
    """

    def __init__(self):
        """初期化

        スクレイパーインスタンスをNoneで初期化します。
        実際のスクレイパーはscrape_gutenbergメソッドで作成されます。
        """
        self._scraper: Optional[GutenbergScraper] = None

    def scrape_gutenberg(self, start_id: int = 0) -> Dict[str, str]:
        """Project Gutenbergのスクレイピングを実行する

        指定されたIDから開始して、Project Gutenbergの書籍情報を
        スクレイピングします。処理の途中でキャンセルされた場合は
        進捗を保存します。

        Args:
            start_id: 開始ID. デフォルトは0.

        Returns:
            Dict[str, str]: スクレイピング結果
                - status: 処理状態 ("success" | "interrupted" | "error")
                - message: 処理結果メッセージ

        Raises:
            ScrapingError: スクレイピング処理でエラーが発生した場合
        """
        try:
            logger.info(f"Gutenbergスクレイピングを開始します（開始ID: {start_id}）")

            config = self._create_scraper_config(start_id)
            self._scraper = GutenbergScraper(config)

            return self._execute_scraping()

        except KeyboardInterrupt:
            return self._handle_interruption()

        except Exception as e:
            error_msg = f"スクレイピング中にエラーが発生: {str(e)}"
            logger.error(error_msg, exc_info=True)
            raise ValueError(error_msg) from e

    def _create_scraper_config(self, start_id: int) -> ScraperConfig:
        """スクレイパーの設定を作成する

        Args:
            start_id: 開始ID

        Returns:
            ScraperConfig: スクレイパーの設定
        """
        config = ScraperConfig()
        config.START_ID = start_id
        return config

    def _execute_scraping(self) -> Dict[str, str]:
        """スクレイピングを実行する

        Returns:
            Dict[str, str]: スクレイピング結果
        """
        if not self._scraper:
            raise ValueError("スクレイパーが初期化されていません")

        try:
            self._scraper.scrape_catalog()
            logger.info("スクレイピングが正常に完了しました")

            return ScrapingResult(
                status="success", message="スクレイピングが正常に完了しました"
            ).to_dict()

        except Exception as e:
            error_msg = f"カタログのスクレイピングに失敗: {str(e)}"
            logger.error(error_msg)
            raise ValueError(error_msg) from e

    def _handle_interruption(self) -> Dict[str, str]:
        """スクレイピングの中断を処理する

        Returns:
            Dict[str, str]: 中断処理の結果
        """
        try:
            logger.info("ユーザーによりスクレイピングが中断されました")

            if self._scraper:
                self._scraper._save_progress()
                logger.info("スクレイピングの進捗を保存しました")

            return ScrapingResult(
                status="interrupted",
                message="スクレイピングは中断されましたが、進捗は保存されました",
            ).to_dict()

        except Exception as e:
            error_msg = f"進捗の保存に失敗: {str(e)}"
            logger.error(error_msg)
            return ScrapingResult(status="error", message=error_msg).to_dict()
