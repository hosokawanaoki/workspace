"""requestsライブラリを使用したHTTPクライアントの実装"""

import logging
import time
from dataclasses import dataclass
from typing import Dict, Optional
from urllib.parse import urlparse

import requests
from api.services.scraping.implementations.http_response_impl import HttpResponseImpl
from api.services.scraping.interfaces.http_client import HttpClient
from api.services.scraping.interfaces.http_response import HttpResponse
from requests.exceptions import RequestException, Timeout

logger = logging.getLogger(__name__)


@dataclass
class HttpClientConfig:
    """HTTPクライアントの設定

    Attributes:
        max_retries (int): 最大リトライ回数
        retry_delay (float): リトライ間隔（秒）
        timeout (float): リクエストタイムアウト（秒）
        verify_ssl (bool): SSL証明書の検証を行うかどうか
    """

    max_retries: int = 3
    retry_delay: float = 1.0
    timeout: float = 30.0
    verify_ssl: bool = True


class HttpClientError(Exception):
    """HTTPクライアントの例外基底クラス"""

    pass


class HttpRequestError(HttpClientError):
    """HTTPリクエスト失敗時の例外"""

    pass


class HttpClientImpl(HttpClient):
    """requestsライブラリを使用したHTTPクライアントの実装

    安全なHTTPリクエストの送信、ヘッダー管理、エラーハンドリングを提供します。
    リトライ機能とタイムアウト設定をサポートし、詳細なログ出力を行います。

    Attributes:
        session (requests.Session): リクエストセッション
        default_headers (Dict[str, str]): デフォルトヘッダー
        config (HttpClientConfig): クライアント設定
    """

    def __init__(self, config: Optional[HttpClientConfig] = None):
        """初期化

        Args:
            config: クライアント設定。Noneの場合はデフォルト設定を使用。
        """
        self.session = requests.Session()
        self.default_headers: Dict[str, str] = {
            "User-Agent": "Mozilla/5.0 (compatible; BookScraperBot/1.0)"
        }
        self.config = config or HttpClientConfig()

    def get(self, url: str, headers: Optional[Dict[str, str]] = None) -> HttpResponse:
        """GETリクエストを送信する

        指定されたURLにGETリクエストを送信し、レスポンスを返します。
        エラー時は自動的にリトライを試みます。

        Args:
            url: リクエスト先のURL
            headers: リクエスト固有のヘッダー

        Returns:
            HttpResponse: レスポンスオブジェクト

        Raises:
            HttpRequestError: リクエスト失敗時
            ValueError: 不正なURL形式の場合
        """
        self._validate_url(url)
        merged_headers = self._merge_headers(headers)

        for attempt in range(self.config.max_retries):
            try:
                logger.debug(
                    f"GETリクエスト送信: {url} (試行 {attempt + 1}/{self.config.max_retries})"
                )
                return self._execute_request(url, merged_headers)

            except Timeout as e:
                error_msg = f"リクエストがタイムアウトしました: {str(e)}"
                if attempt < self.config.max_retries - 1:
                    logger.warning(f"{error_msg} - リトライします")
                    time.sleep(self.config.retry_delay)
                else:
                    logger.error(error_msg)
                    raise HttpRequestError(error_msg) from e

            except RequestException as e:
                error_msg = f"リクエストに失敗: {str(e)}"
                if attempt < self.config.max_retries - 1:
                    logger.warning(f"{error_msg} - リトライします")
                    time.sleep(self.config.retry_delay)
                else:
                    logger.error(error_msg)
                    raise HttpRequestError(error_msg) from e

            except Exception as e:
                error_msg = f"予期せぬエラーが発生: {str(e)}"
                logger.error(error_msg)
                raise HttpRequestError(error_msg) from e

    def set_headers(self, headers: Dict[str, str]) -> None:
        """デフォルトヘッダーを設定する

        既存のヘッダーは上書きされます。

        Args:
            headers: 設定するヘッダー

        Raises:
            ValueError: 不正なヘッダー値が含まれる場合
        """
        try:
            self._validate_headers(headers)
            self.default_headers = headers.copy()
            logger.info(f"デフォルトヘッダーを設定: {headers}")

        except Exception as e:
            error_msg = f"ヘッダーの設定に失敗: {str(e)}"
            logger.error(error_msg)
            raise ValueError(error_msg) from e

    def _validate_url(self, url: str) -> None:
        """URLの妥当性を検証する

        Args:
            url: 検証するURL

        Raises:
            ValueError: 不正なURL形式の場合
        """
        try:
            result = urlparse(url)
            if not all([result.scheme, result.netloc]):
                raise ValueError("URLスキームまたはホストが不正です")
        except Exception as e:
            raise ValueError(f"不正なURL形式: {str(e)}") from e

    def _validate_headers(self, headers: Dict[str, str]) -> None:
        """ヘッダーの妥当性を検証する

        Args:
            headers: 検証するヘッダー

        Raises:
            ValueError: 不正なヘッダー値が含まれる場合
        """
        if not isinstance(headers, dict):
            raise ValueError("ヘッダーは辞書形式である必要があります")

        for key, value in headers.items():
            if not isinstance(key, str) or not isinstance(value, str):
                raise ValueError("ヘッダーのキーと値は文字列である必要があります")

    def _merge_headers(
        self, custom_headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, str]:
        """ヘッダーをマージする

        Args:
            custom_headers: マージするカスタムヘッダー

        Returns:
            Dict[str, str]: マージされたヘッダー
        """
        merged = self.default_headers.copy()
        if custom_headers:
            merged.update(custom_headers)
        return merged

    def _execute_request(self, url: str, headers: Dict[str, str]) -> HttpResponse:
        """リクエストを実行する

        Args:
            url: リクエスト先のURL
            headers: リクエストヘッダー

        Returns:
            HttpResponse: レスポンスオブジェクト

        Raises:
            RequestException: リクエスト失敗時
        """
        response = self.session.get(
            url,
            headers=headers,
            timeout=self.config.timeout,
            verify=self.config.verify_ssl,
        )
        response.raise_for_status()
        return HttpResponseImpl(response.status_code, response.text)
