import logging

from api.constants.constants import GUTENBERG
from api.models.book import Book
from api.services.common.file_util.gutenberg_file_util import GutenbergFileUtil
from api.services.scraping.exceptions.scraping_exceptions import (
    GutenbergProcessingError,
)
from api.services.translation.interfaces.text_processing.zip_downloader_interface import (
    FileDownloaderInterface,
)

logger = logging.getLogger(__name__)


class GutenbergDownloaderService:
    """Project Gutenbergのファイルダウンロードを担当するサービス"""

    def __init__(self, file_downloader: FileDownloaderInterface):
        """初期化

        Args:
            file_downloader: ファイルダウンロードインターフェース
        """
        self.file_downloader = file_downloader

    def download_book(self, book_id: str) -> str:
        """Project Gutenbergから書籍をダウンロードして解凍する

        Args:
            book_id (str): 書籍ID

        Returns:
            str: 解凍したHTMLファイルのパス

        Raises:
            GutenbergProcessingError: ダウンロードまたは解凍中にエラーが発生した場合
        """
        try:
            # 書籍の取得
            book = Book.get_book_by_book_id(book_id)
            if not book or not book.original_id:
                raise GutenbergProcessingError(
                    f"書籍 {book_id} のoriginal_idが見つかりません"
                )

            # URLの設定とダウンロード
            file_url = GUTENBERG["ZIP_URL"].format(book.original_id, book.original_id)
            zip_content = self.file_downloader.download(file_url)
            logger.info("ZIPファイルのダウンロード完了")

            # ファイル解凍
            return GutenbergFileUtil.extract_html_from_zip(zip_content, book_id)

        except Exception as e:
            error_msg = f"書籍ID {book_id} のダウンロード中にエラー発生: {str(e)}"
            logger.exception(error_msg)
            raise GutenbergProcessingError(error_msg)
