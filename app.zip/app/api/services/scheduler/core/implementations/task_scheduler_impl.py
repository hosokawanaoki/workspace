"""タスクスケジューラの実装"""

import logging
import uuid
from datetime import datetime
from typing import Callable, Dict, Optional

from api.services.scheduler.core.interfaces.task_scheduler import TaskScheduler
from apscheduler.jobstores.base import JobLookupError
from apscheduler.schedulers.background import BackgroundScheduler

logger = logging.getLogger(__name__)


class TaskSchedulerImpl(TaskScheduler):
    """タスクスケジューラの実装クラス"""

    def __init__(self):
        """初期化"""
        self._scheduler: Optional[BackgroundScheduler] = None
        self._jobs: Dict[str, str] = {}  # task_id -> job_id のマッピング

    def schedule(
        self,
        task: Callable,
        interval_minutes: int,
        task_id: Optional[str] = None,
        next_run_time: Optional[datetime] = None,
    ) -> str:
        """タスクをスケジュールする

        Args:
            task: 実行する関数
            interval_minutes: 実行間隔（分）
            task_id: タスクID（省略時は自動生成）
            next_run_time: 初回実行時間（省略時は現在時刻）

        Returns:
            str: 登録されたタスクID
        """
        if self._scheduler is None:
            self._initialize_scheduler()

        task_id = task_id or str(uuid.uuid4())
        if task_id in self._jobs:
            logger.warning(f"タスク {task_id} は既に登録されています")
            return task_id

        # 初回実行時間が指定されていない場合は現在時刻を使用
        if next_run_time is None:
            next_run_time = datetime.now()

        job = self._scheduler.add_job(
            task,
            "interval",
            minutes=interval_minutes,
            next_run_time=next_run_time,
            id=task_id,
            max_instances=1,  # 同じタスクIDのジョブは1つしか実行されないようにする
            coalesce=True,
            misfire_grace_time=None,
        )
        self._jobs[task_id] = job.id
        logger.info(f"タスク {task_id} を登録しました（実行間隔: {interval_minutes}分）")

        return task_id

    def cancel(self, task_id: str) -> bool:
        """タスクをキャンセルする

        Args:
            task_id: キャンセルするタスクID

        Returns:
            bool: キャンセル成功時はTrue
        """
        if task_id not in self._jobs:
            logger.warning(f"タスク {task_id} は登録されていません")
            return False

        try:
            self._scheduler.remove_job(self._jobs[task_id])
            del self._jobs[task_id]
            logger.info(f"タスク {task_id} をキャンセルしました")
            return True
        except JobLookupError:
            logger.error(f"タスク {task_id} のキャンセルに失敗しました")
            return False

    def start(self) -> None:
        """スケジューラを開始する"""
        if self._scheduler is None:
            self._initialize_scheduler()
        if not self._scheduler.running:
            self._scheduler.start()
            logger.info("スケジューラを開始しました")

    def stop(self) -> None:
        """スケジューラを停止する"""
        if self._scheduler and self._scheduler.running:
            self._scheduler.shutdown()
            self._scheduler = None
            self._jobs.clear()
            logger.info("スケジューラを停止しました")

    def _initialize_scheduler(self) -> None:
        """スケジューラを初期化する"""
        self._scheduler = BackgroundScheduler()
        logging.getLogger("apscheduler").setLevel(logging.INFO)
