"""デフォルトのバッチ実行機能の実装"""

import logging
from typing import Dict, Any, Optional

from api.constants.constants import SCHEDULER
from api.services.scheduler.core.interfaces.batch_executor import BatchExecutor
from api.services.scheduler.core.interfaces.batch_processor import BatchProcessor

logger = logging.getLogger(__name__)


class DefaultExecutor(BatchExecutor):
    """デフォルトのバッチ実行機能の実装"""

    def __init__(self):
        """初期化"""
        self._running_tasks = {}  # タスクIDごとの実行状態を管理
        self._max_concurrent = SCHEDULER[
            "MAX_CONCURRENT_TASKS"
        ]  # 最大同時実行数（異なるタスクID間で）

    def execute(self, processor: BatchProcessor, context: Optional[Dict[str, Any]] = None) -> None:
        """バッチ処理を実行する

        Args:
            processor: 実行するバッチプロセッサ
            context: 実行コンテキスト（オプション）
                     'task_id'キーでタスクIDを指定可能
        """
        # コンテキストからタスクIDを取得（なければデフォルト値を使用）
        context = context or {}
        task_id = context.get("task_id", "default_task")

        # 同じタスクIDのタスクが既に実行中の場合は実行しない
        if task_id in self._running_tasks:
            logger.warning(f"タスクID '{task_id}' は既に実行中です")
            return

        # 最大同時実行数を超える場合は実行しない
        if len(self._running_tasks) >= self._max_concurrent:
            logger.warning(f"既に{self._max_concurrent}件のバッチ処理が実行中です")
            return

        try:
            # タスクの実行状態を記録
            self._running_tasks[task_id] = True
            logger.info(
                f"バッチ処理を開始します（タスクID: {task_id}, 現在の実行数: {len(self._running_tasks)}）"
            )
            processor.process_batch(context)
            logger.info(f"バッチ処理が完了しました（タスクID: {task_id}）")

        except Exception as e:
            logger.error(f"バッチ処理でエラーが発生しました（タスクID: {task_id}）: {str(e)}")
            try:
                processor.handle_error(e, context)
            except Exception as handler_error:
                logger.error(f"エラーハンドラでエラーが発生しました: {str(handler_error)}")

        finally:
            # タスクの実行状態を削除
            if task_id in self._running_tasks:
                del self._running_tasks[task_id]

    def is_running(self) -> bool:
        """実行中かどうかを確認する

        Returns:
            bool: 実行中の場合はTrue
        """
        return len(self._running_tasks) > 0

    def is_task_running(self, task_id: str) -> bool:
        """指定したタスクIDのタスクが実行中かどうかを確認する

        Args:
            task_id: 確認するタスクID

        Returns:
            bool: 実行中の場合はTrue
        """
        return task_id in self._running_tasks
