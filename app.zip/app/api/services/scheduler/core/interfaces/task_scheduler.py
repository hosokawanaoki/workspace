"""タスクスケジューラのインターフェース"""

from abc import ABC, abstractmethod
from typing import Callable, Optional


class TaskScheduler(ABC):
    """タスクスケジューラのインターフェース"""

    @abstractmethod
    def schedule(self, task: Callable, interval_minutes: int, task_id: Optional[str] = None) -> str:
        """タスクをスケジュールする

        Args:
            task: 実行する関数
            interval_minutes: 実行間隔（分）
            task_id: タスクID（省略時は自動生成）

        Returns:
            str: 登録されたタスクID
        """
        pass

    @abstractmethod
    def cancel(self, task_id: str) -> bool:
        """タスクをキャンセルする

        Args:
            task_id: キャンセルするタスクID

        Returns:
            bool: キャンセル成功時はTrue
        """
        pass

    @abstractmethod
    def start(self) -> None:
        """スケジューラを開始する"""
        pass

    @abstractmethod
    def stop(self) -> None:
        """スケジューラを停止する"""
        pass
