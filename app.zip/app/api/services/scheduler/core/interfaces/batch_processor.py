"""バッチ処理を定義するインターフェース"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class BatchProcessor(ABC):
    """バッチ処理を定義するインターフェース

    このインターフェースを実装することで、様々なタイプのバッチ処理を
    スケジューラに登録できます。
    """

    @abstractmethod
    def process_batch(self, context: Optional[Dict[str, Any]] = None) -> None:
        """バッチ処理を実行する

        Args:
            context: 実行コンテキスト（オプション）
        """
        pass

    @abstractmethod
    def handle_error(self, error: Exception, context: Optional[Dict[str, Any]] = None) -> None:
        """エラー処理を行う

        Args:
            error: 発生したエラー
            context: 実行コンテキスト（オプション）
        """
        pass
