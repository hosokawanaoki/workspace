"""バッチ実行を管理するインターフェース"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional

from api.services.scheduler.core.interfaces.batch_processor import BatchProcessor


class BatchExecutor(ABC):
    """バッチ実行を管理するインターフェース"""

    @abstractmethod
    def execute(self, processor: BatchProcessor, context: Optional[Dict[str, Any]] = None) -> None:
        """バッチ処理を実行する

        Args:
            processor: 実行するバッチプロセッサ
            context: 実行コンテキスト（オプション）
        """
        pass

    @abstractmethod
    def is_running(self) -> bool:
        """実行中かどうかを確認する

        Returns:
            bool: 実行中の場合はTrue
        """
        pass
