import logging
from datetime import timedelta
from typing import List

from api.constants.constants import STALL_THRESHOLD_MINUTES
from api.models.book import Book
from api.models.translation_batch import TranslationBatch
from api.services.models.translation_target import TranslationTarget
from api.services.translation.models.translator_config import TranslatorConfig
from django.utils import timezone

logger = logging.getLogger(__name__)


class StalledBatchUtil:
    """停止したバッチの処理を管理するユーティリティクラス"""

    @classmethod
    def detect_stalled_batches(cls) -> List[TranslationTarget]:
        """停止している可能性のあるバッチを検出する

        Returns:
            List[TranslationTarget]: 停止している可能性のあるバッチのリスト
        """
        current_time = timezone.now()
        stall_threshold = current_time - timedelta(minutes=STALL_THRESHOLD_MINUTES)

        # AI実行中のステータスで、一定時間以上更新がないものを検出
        stalled_books = (
            Book.get_executing_books_for_stalled_check()
            .filter(
                translationbatch__updated_at__lt=stall_threshold,
            )
            .distinct()
        )

        stalled_targets = []
        for book in stalled_books:
            latest_batch = TranslationBatch.objects.filter(book=book).latest("updated_at")
            if latest_batch:
                config = TranslatorConfig()  # デフォルトの設定を使用
                target = TranslationTarget(book, latest_batch, config)
                stalled_targets.append(target)

        return stalled_targets

    @classmethod
    def process_stalled_batch(cls, target: TranslationTarget) -> None:
        """停止したバッチを処理する

        Args:
            target (TranslationTarget): 停止したバッチの情報
        """
        try:
            if not target.has_reached_max_retries():
                target.update_retry_count()
            else:
                target.mark_as_error()

        except Exception as e:
            logger.error(f"書籍 {target.book_id} のステータス更新に失敗: {str(e)}")
