"""スケジューラコンポーネントを作成するファクトリ

使用方法:
    実装例は examples/book_batch_processor.py を参照してください。
    起動処理は runners/book_scheduler_runner.py を参照してください。
"""

from typing import Optional, Type

from api.services.scheduler.config.scheduler_config import SchedulerConfig
from api.services.scheduler.core.implementations.default_executor import DefaultExecutor
from api.services.scheduler.core.implementations.task_scheduler_impl import TaskSchedulerImpl
from api.services.scheduler.core.interfaces.batch_executor import BatchExecutor
from api.services.scheduler.core.interfaces.task_scheduler import TaskScheduler


class SchedulerFactory:
    """スケジューラコンポーネントを作成するファクトリ"""

    @staticmethod
    def create_task_scheduler(
        config: Optional[SchedulerConfig] = None,
        scheduler_class: Optional[Type[TaskScheduler]] = None,
    ) -> TaskScheduler:
        """タスクスケジューラを作成する

        Args:
            config: スケジューラ設定（省略時はデフォルト）
            scheduler_class: スケジューラクラス（省略時はデフォルト）

        Returns:
            TaskScheduler: 作成されたスケジューラ
        """
        config = config or SchedulerConfig()
        scheduler_class = scheduler_class or TaskSchedulerImpl
        return scheduler_class()

    @staticmethod
    def create_batch_executor(
        executor_class: Optional[Type[BatchExecutor]] = None,
    ) -> BatchExecutor:
        """バッチ実行機能を作成する

        Args:
            executor_class: 実行クラス（省略時はデフォルト）

        Returns:
            BatchExecutor: 作成された実行機能
        """
        executor_class = executor_class or DefaultExecutor
        return executor_class()
