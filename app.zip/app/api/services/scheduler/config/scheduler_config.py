"""スケジューラの設定を管理するモジュール"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class SchedulerConfig:
    """スケジューラの設定を管理するクラス"""

    # デフォルトの実行間隔（分）
    DEFAULT_INTERVAL_MINUTES: int = 1

    # 最小実行間隔（分）
    MIN_INTERVAL_MINUTES: float = 0.5

    # 最大リトライ回数
    MAX_RETRY_COUNT: int = 3

    # 停止検出の閾値（分）
    STALL_THRESHOLD_MINUTES: int = 30

    # ログレベル
    LOG_LEVEL: str = "INFO"

    def __init__(
        self,
        interval_minutes: Optional[int] = None,
        min_interval_minutes: Optional[float] = None,
        max_retry_count: Optional[int] = None,
        stall_threshold_minutes: Optional[int] = None,
        log_level: Optional[str] = None,
    ):
        """初期化

        Args:
            interval_minutes: 実行間隔（分）
            min_interval_minutes: 最小実行間隔（分）
            max_retry_count: 最大リトライ回数
            stall_threshold_minutes: 停止検出の閾値（分）
            log_level: ログレベル
        """
        self.DEFAULT_INTERVAL_MINUTES = interval_minutes or self.DEFAULT_INTERVAL_MINUTES
        self.MIN_INTERVAL_MINUTES = min_interval_minutes or self.MIN_INTERVAL_MINUTES
        self.MAX_RETRY_COUNT = max_retry_count or self.MAX_RETRY_COUNT
        self.STALL_THRESHOLD_MINUTES = stall_threshold_minutes or self.STALL_THRESHOLD_MINUTES
        self.LOG_LEVEL = log_level or self.LOG_LEVEL

    def validate_interval(self, interval_minutes: int) -> None:
        """実行間隔の妥当性を検証する

        Args:
            interval_minutes: 検証する実行間隔（分）

        Raises:
            ValueError: 実行間隔が最小値未満の場合
        """
        if interval_minutes < self.MIN_INTERVAL_MINUTES:
            raise ValueError(f"実行間隔は{self.MIN_INTERVAL_MINUTES}分以上である必要があります")
