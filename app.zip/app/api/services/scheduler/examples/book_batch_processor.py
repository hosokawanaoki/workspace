"""書籍バッチ処理の実装例"""

import logging
from typing import Any, Dict, Optional

from api.models.book import Book
from api.services.book.implementations.book_info_updater import BookInfoUpdater
from api.services.models.translation_batch_service import TranslationBatchService
from api.services.models.translation_target import TranslationTarget
from api.services.scheduler.core.interfaces.batch_processor import BatchProcessor
from api.services.translation.exceptions.translation_error import CancellationException
from api.services.translation.interfaces.translation_service import TranslationService
from api.services.translation.models.translator_config import TranslatorConfig
from api.utils.translation.translation_process_util import TranslationProcessUtil

logger = logging.getLogger(__name__)


class BookBatchProcessor(BatchProcessor):
    """書籍バッチ処理の実装例

    BatchProcessorインターフェースを実装し、書籍の翻訳処理を
    スケジューラフレームワークに統合する例を示します。
    """

    def __init__(
        self,
        translator_service: TranslationService,
        book_info_updater: BookInfoUpdater,
        translator_config: TranslatorConfig,
    ):
        """初期化

        Args:
            translator_service: 翻訳サービス
            book_info_updater: 書籍情報更新
            translator_config: 翻訳設定
        """
        self.translator_service = translator_service
        self.book_info_updater = book_info_updater
        self.translator_config = translator_config

    def process_batch(self, context: Optional[Dict[str, Any]] = None) -> None:
        """バッチ処理を実行する

        Args:
            context: 実行コンテキスト（オプション）
        """
        try:
            # 待機中の書籍を取得
            waiting_books = Book.get_waiting_books()
            if not waiting_books:
                logger.info("待機中の書籍はありません")
                return

            logger.info(f"待機中の書籍が{len(waiting_books)}件見つかりました")

            # 最も古いバッチを持つ書籍とバッチを取得
            book, batch = TranslationBatchService.find_oldest_batch_book(waiting_books)
            if not book or not batch:
                logger.info("処理可能な書籍が見つかりませんでした")
                return

            if book.needs_info_update:
                logger.info(f"書籍 {book.book_id} の情報更新が必要です")
                self.book_info_updater.update_book_info_from_llm(book)

            # TranslationTargetを作成
            target = TranslationTarget(book=book, batch=batch, config=self.translator_config)
            # バッチのタイプに応じて処理を分岐
            if batch.mode == "translation":
                target.start_processing()
                # 翻訳前の準備処理を実行
                logger.info(f"書籍 {book.book_id} の翻訳前準備処理を開始")
                self.translator_service.prepare_translation(book)
                # 翻訳を実行
                logger.info(f"書籍 {book.book_id} の翻訳処理を開始")
                self.translator_service.start_translate(target)
            else:
                # 校正の場合
                target.start_processing()
                logger.info(f"書籍 {book.book_id} の校正処理を開始")
                self.translator_service.start_correction(target)

            # 翻訳ステータスを更新
            TranslationProcessUtil.update_translation_status(target)
            logger.info(f"書籍 {book.book_id} の翻訳ステータスを更新しました")

        except CancellationException as ce:
            # キャンセル例外は正常終了として扱う
            logger.info(f"キャンセルにより処理を終了しました: {str(ce)}")
            return
        except Exception as e:
            logger.error(f"バッチ処理でエラーが発生しました: {str(e)}")
            raise

    def handle_error(self, error: Exception, context: Optional[Dict[str, Any]] = None) -> None:
        """エラー処理を行う

        Args:
            error: 発生したエラー
            context: 実行コンテキスト（オプション）
        """
        # キャンセル例外は正常終了として扱う
        if isinstance(error, CancellationException):
            logger.info(f"キャンセルにより処理を終了しました: {str(error)}")
            return

        logger.error(f"エラーが発生しました: {str(error)}")
        if context and "book_id" in context:
            book = Book.get_book_by_book_id(context["book_id"])
            if book:
                book.set_status("error")
