"""書籍処理スケジューラの起動を管理するモジュール"""

import logging
from datetime import datetime, timedelta

from django.utils import timezone
from api.models.book import Book
from api.models.translation_batch import TranslationBatch
from api.services.book.factories.book_processor_factory import BookProcessorFactory
from api.services.scheduler.config.scheduler_config import SchedulerConfig
from api.services.scheduler.scheduler_factory import SchedulerFactory
from api.services.scheduler.utils.stalled_batch_util import StalledBatchUtil

logger = logging.getLogger(__name__)


def monitor_batch_processes():
    """バッチ処理の監視タスク（統合版）"""
    logger.info("バッチ処理監視を開始します")

    try:
        # 1. 停止したバッチの検出と処理
        try:
            stalled_targets = StalledBatchUtil.detect_stalled_batches()

            if stalled_targets:
                logger.info(f"{len(stalled_targets)}件の停止したバッチを検出しました")
                for target in stalled_targets:
                    try:
                        StalledBatchUtil.process_stalled_batch(target)
                        logger.info(f"書籍 {target.book_id} の停止したバッチを処理しました")
                    except Exception as e:
                        logger.error(f"書籍 {target.book_id} の停止バッチ処理中にエラー: {str(e)}")
            else:
                logger.info("停止したバッチはありません")

        except Exception as e:
            logger.error(f"停止バッチ検出処理中にエラー: {str(e)}")
            # エラーが発生しても次の監視処理を続行

        # 2. 重複book_idのバッチ検出と処理
        try:
            # 実行中のバッチを取得
            active_batches = TranslationBatch.objects.filter(
                status__in=["pending", "processing"]
            ).select_related("book")

            # book_idごとにグループ化
            book_id_to_batches = {}
            for batch in active_batches:
                book_id = batch.book.book_id
                if book_id not in book_id_to_batches:
                    book_id_to_batches[book_id] = []
                book_id_to_batches[book_id].append(batch)

            # 重複があるbook_idを検出
            duplicate_book_ids = {
                book_id: batches
                for book_id, batches in book_id_to_batches.items()
                if len(batches) > 1
            }

            if duplicate_book_ids:
                logger.info(f"{len(duplicate_book_ids)}件の重複book_idを検出しました")

                # 重複バッチの処理（最も古いバッチ以外を停止）
                for book_id, batches in duplicate_book_ids.items():
                    try:
                        # 作成日時でソート
                        sorted_batches = sorted(batches, key=lambda b: b.created_at)

                        # 最も古いバッチを残し、他を停止
                        oldest_batch = sorted_batches[0]
                        for batch in sorted_batches[1:]:
                            batch.status = "stopped"
                            batch.end_time = timezone.now()
                            batch.save()
                            logger.info(f"書籍 {book_id} の重複バッチ {batch.id} を停止しました")

                        logger.info(
                            f"書籍 {book_id} の最も古いバッチ {oldest_batch.id} は処理を継続します"
                        )

                    except Exception as e:
                        logger.error(f"書籍 {book_id} の重複バッチ処理中にエラー: {str(e)}")
            else:
                logger.info("重複book_idのバッチはありません")

        except Exception as e:
            logger.error(f"重複バッチ検出処理中にエラー: {str(e)}")

        logger.info("バッチ処理監視を完了しました")

    except Exception as e:
        logger.error(f"バッチ監視全体でエラーが発生: {str(e)}")


def start_book_scheduler() -> None:
    """書籍処理スケジューラを起動する"""
    try:
        # スケジューラの設定と初期化
        config = SchedulerConfig(interval_minutes=1)
        scheduler = SchedulerFactory.create_task_scheduler(config=config)
        executor = SchedulerFactory.create_batch_executor()

        # 複数のバッチプロセッサを作成
        batch_processor1 = BookProcessorFactory.create_batch_processor()
        batch_processor2 = BookProcessorFactory.create_batch_processor()
        batch_processor3 = BookProcessorFactory.create_batch_processor()

        # バッチ処理の登録と開始（異なるタスクIDを指定）
        def execute_batch1():
            # タスクID1を指定して実行
            executor.execute(batch_processor1, {"task_id": "processor1"})

        def execute_batch2():
            # タスクID2を指定して実行
            executor.execute(batch_processor2, {"task_id": "processor2"})

        def execute_batch3():
            # タスクID3を指定して実行
            executor.execute(batch_processor3, {"task_id": "processor3"})

        # 現在時刻を取得
        now = datetime.now()

        # 各タスクを登録（異なるタスクIDと初回実行時間を指定）
        # 1番目のタスクは現在時刻（デフォルト）
        scheduler.schedule(execute_batch1, interval_minutes=1, task_id="book_processor_1")

        # 2番目のタスクは20秒後
        scheduler.schedule(
            execute_batch2,
            interval_minutes=1,
            task_id="book_processor_2",
            next_run_time=now + timedelta(seconds=20),
        )

        # 3番目のタスクは40秒後
        scheduler.schedule(
            execute_batch3,
            interval_minutes=1,
            task_id="book_processor_3",
            next_run_time=now + timedelta(seconds=40),
        )

        # 監視タスクを登録（5分間隔）
        scheduler.schedule(
            monitor_batch_processes,
            interval_minutes=5,
            task_id="batch_monitor",
            next_run_time=now + timedelta(seconds=60),  # 1分後に初回実行
        )

        scheduler.start()
        logger.info("Book scheduler and batch monitor started successfully")

    except Exception as e:
        logger.error(f"Failed to start book scheduler: {str(e)}")
        logger.exception("Detailed error traceback:")
        raise
