from django.utils import timezone
import logging

from api.models.book import Book
from api.services.common.file_path_util.translation_paths import TranslationPaths
from api.services.common.text_util.text_post_processor_util import TextPostProcessorUtil
from api.services.models.translation_target import TranslationTarget
from api.services.translation.implementations.correction_controller_service_impl import (
    CorrectionControllerServiceImpl,
)
from api.services.translation.implementations.translation_controller_service_impl import (
    TranslationControllerServiceImpl,
)
from api.services.translation.interfaces.text_pre_processor import TextPreProcessor
from api.services.translation.interfaces.text_processing.text_processor import (
    TagRecoveryService,
)
from api.services.translation.interfaces.translation_service import TranslationService
from api.utils.file.directory_util import DirectoryUtil
from api.utils.llm.factory.llm_service_factory import LLMServiceFactory
from api.utils.translation.translation_process_util import TranslationProcessUtil
from api.services.translation.exceptions.translation_error import CancellationException

logger = logging.getLogger(__name__)


class TranslationServiceImpl(TranslationService):
    """翻訳サービスの実装クラス"""

    def __init__(
        self,
        text_pre_processor: TextPreProcessor,
        tag_recovery_service: TagRecoveryService,
    ):
        """コンストラクタ

        Args:
            text_pre_processor (TextPreProcessor): テキスト前処理サービス
            tag_recovery_service (TagRecoveryService): タグ修復サービス
        """
        self._text_pre_processor = text_pre_processor
        self._tag_recovery_service = tag_recovery_service

    def prepare_translation(self, book: Book) -> None:
        """翻訳前の処理を実行する

        Args:
            book (Book): 書籍オブジェクト

        Raises:
            Exception: 処理中にエラーが発生した場合
        """
        translated_dir = TranslationPaths.get_translated_dir(book.book_id)
        logger.info(f"翻訳ディレクトリをチェック: {translated_dir}")
        if DirectoryUtil.check_path_exists(translated_dir):
            logger.info(f"前回の翻訳データが存在するため、前処理をスキップします: {translated_dir}")
            return
        logger.info("前回の翻訳データは存在しないため、前処理を開始します")

        logger.info(f"翻訳前処理を開始します。book_id: {book.book_id}")
        self._text_pre_processor.process(book)

    def _execute_translation(self, target: TranslationTarget) -> None:
        """翻訳を実行する

        Args:
            target (TranslationTarget): 翻訳対象（翻訳設定を含む）

        Raises:
            Exception: 翻訳実行中にエラーが発生した場合
        """
        logger.info("翻訳を実行します")
        try:
            translation_controller = TranslationControllerServiceImpl(
                target=target,
                llm_service=LLMServiceFactory.create(),
            )
            translation_controller.translate_file()
        except Exception as e:
            TranslationProcessUtil.handle_process_error(target, "翻訳", e)
            raise

    def start_translate(self, target: TranslationTarget) -> None:
        """翻訳プロセス全体を実行する

        Args:
            target (TranslationTarget): 翻訳対象（翻訳設定を含む）

        Returns:
            Tuple[TranslationsData, Optional[List[Any]]]:
                - 翻訳結果のデータ
                - プレースホルダー情報のリスト（オプション）

        Raises:
            ValueError: 設定が不正な場合
            CancellationException: 翻訳処理がキャンセルされた場合
            Exception: その他のエラーが発生した場合
        """
        try:
            self._execute_translation(target)

            logger.info("タグの修復処理を開始します")
            self._tag_recovery_service.recover_and_save(target=target)

            logger.info("翻訳後処理を開始します")
            TextPostProcessorUtil.process(target)

            target.batch.end_time = timezone.now()
            target.batch.save(update_fields=["end_time"])

            return

        except ValueError as ve:
            logger.exception("翻訳設定または処理結果が不正です")
            raise ve
        except CancellationException as ce:
            logger.info(f"翻訳処理がキャンセルされました: {str(ce)}")
            raise
        except Exception:
            logger.exception("翻訳処理でエラーが発生", exc_info=True)
            raise

    def _execute_correction(self, target: TranslationTarget) -> None:
        """校正を実行する

        Args:
            target (TranslationTarget): 校正対象（校正設定を含む）

        Raises:
            Exception: 校正実行中にエラーが発生した場合
        """
        logger.info("校正を実行します")
        try:
            correction_controller = CorrectionControllerServiceImpl(
                target=target,
                llm_service=LLMServiceFactory.create(),
            )
            correction_controller.correct_file()
        except Exception as e:
            TranslationProcessUtil.handle_process_error(target, "校正", e)
            raise

    def start_correction(self, target: TranslationTarget) -> None:
        """校正プロセス全体を実行する

        Args:
            target (TranslationTarget): 校正対象（校正設定を含む）

        Returns:
            Tuple[TranslationsData, Optional[List[Any]]]:
                - 校正結果のデータ
                - プレースホルダー情報のリスト（オプション）

        Raises:
            ValueError: 設定が不正な場合
            CancellationException: 校正処理がキャンセルされた場合
            Exception: その他のエラーが発生した場合
        """
        try:
            self._execute_correction(target)

            logger.info("タグの修復処理を開始します")
            self._tag_recovery_service.recover_and_save(target=target)

            logger.info("翻訳後処理を開始します")
            TextPostProcessorUtil.process(target)

            return

        except ValueError as ve:
            logger.exception("校正設定または処理結果が不正です")
            raise ve
        except CancellationException as ce:
            logger.info(f"校正処理がキャンセルされました: {str(ce)}")
            raise
        except Exception:
            logger.exception("校正処理でエラーが発生", exc_info=True)
            raise
