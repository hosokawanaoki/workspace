import logging
from typing import Tuple

from api.models.book import Book
from api.models.translation_batch import TranslationBatch
from api.models.translation_version import TranslationVersion
from api.services.common.logging_utils import (
    log_error_with_book_id,
)
from api.services.translation.exceptions.translation_error import FileProcessingError
from api.services.translation.interfaces.translation_batch_service import (
    TranslationBatchService,
)
from django.db import DatabaseError

logger = logging.getLogger(__name__)


class TranslationBatchServiceImpl(TranslationBatchService):
    """翻訳バッチサービスの実装クラス

    書籍の翻訳バッチを作成・管理するサービスの実装を提供します。
    """

    def __init__(
        self,
        book_repository=None,
        version_repository=None,
        batch_repository=None,
    ):
        """初期化

        Args:
            book_repository: 書籍リポジトリ
            version_repository: バージョンリポジトリ
            batch_repository: バッチリポジトリ
        """
        self.book_repository = book_repository or Book
        self.version_repository = version_repository or TranslationVersion
        self.batch_repository = batch_repository or TranslationBatch

    def _get_or_create_book(self, book_id: str) -> Tuple[Book, bool]:
        """書籍を取得または作成する

        Args:
            book_id (str): 書籍ID

        Returns:
            Tuple[Book, bool]: (書籍オブジェクト, 新規作成されたかどうか)

        Raises:
            DatabaseError: データベース操作に失敗した場合
        """
        try:
            book, created = self.book_repository.update_or_create_record(
                identifier={"book_id": book_id},
                data={"status": self.book_repository.get_status_type("waiting")},
            )
            action = "作成" if created else "更新"
            logger.info(f"書籍 {book_id} を{action}しました")
            return book, created

        except DatabaseError as e:
            logger.error(f"書籍の取得/作成中にデータベースエラーが発生: {e}")
            raise

    def _create_translation_batch(
        self, book: Book, version_number: int = 1
    ) -> TranslationBatch:
        """翻訳バッチを作成する

        Args:
            book (Book): 対象の書籍
            version_number (int, optional): バージョン番号. デフォルトは1.

        Returns:
            TranslationBatch: 作成された翻訳バッチ

        Raises:
            DatabaseError: データベース操作に失敗した場合
        """
        try:
            # バージョンの作成または取得
            version = self.version_repository.get_or_create_version(
                book, version_number
            )

            # バッチの作成
            batch = self.batch_repository.objects.create(
                book=book,
                status="pending",
                translation_version=version,
            )
            logger.info(
                f"書籍 {book.book_id} の翻訳バッチを作成しました（バージョン: {version.version}）"
            )
            return batch

        except DatabaseError as e:
            logger.error(f"翻訳バッチの作成中にエラーが発生: {e}")
            raise

    def _process_batch_creation(
        self, book_id: str, version_number: int = 1
    ) -> tuple[Book, TranslationBatch]:
        """翻訳バッチ作成の処理を実行

        Args:
            book_id (str): 書籍ID
            version_number (int, optional): バージョン番号. デフォルトは1.

        Returns:
            Tuple[Book, TranslationBatch]: 書籍と作成された翻訳バッチ

        Raises:
            DatabaseError: データベース操作に失敗した場合
        """
        logger.info(f"書籍 {book_id} の翻訳バッチ作成を開始します")

        # 書籍の取得または作成
        book, _ = self._get_or_create_book(book_id)

        # 翻訳バッチの作成
        batch = self._create_translation_batch(book, version_number)

        return book, batch

    def create_batch(
        self, book_id: str, version_number: int = 1
    ) -> tuple[Book, TranslationBatch]:
        """翻訳バッチを作成する

        指定された書籍IDに対して翻訳バッチを作成します。
        書籍が存在しない場合は新規作成し、既に存在する場合はステータスを更新します。

        Args:
            book_id (str): 書籍ID
            version_number (int, optional): バージョン番号. デフォルトは1.

        Returns:
            Tuple[Book, TranslationBatch]: 書籍と作成された翻訳バッチ

        Raises:
            DatabaseError: データベース操作に失敗した場合
            Exception: その他のエラーが発生した場合
        """
        logger.info(f"書籍 {book_id} の翻訳バッチ作成処理を開始")
        try:
            book, batch = self._process_batch_creation(book_id, version_number)
            logger.info(f"書籍 {book_id} の翻訳バッチ作成処理が完了")
            return book, batch
        except Exception as e:
            error_message = "翻訳バッチの作成に失敗しました"
            log_error_with_book_id(book_id, f"{error_message}: {str(e)}", e)
            raise FileProcessingError(f"{error_message}: {str(e)}") from e
