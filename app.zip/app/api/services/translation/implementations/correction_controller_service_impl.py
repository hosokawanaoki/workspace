from api.models.translation import Translation
from api.models.translation_version import TranslationVersionStatus
from api.services.common.logging_utils import (
    log_error_with_book_id,
    log_info_with_book_id,
)
from api.services.models.translation_target import TranslationTarget
from api.services.translation.exceptions.translation_error import CancellationException
from api.services.translation.implementations.base.correction_api_client import (
    CorrectionApiClient,
)
from api.services.translation.implementations.base_book_batch_controller import (
    BaseBookBatchController,
)
from api.services.translation.interfaces.correction_controller_service import (
    CorrectionControllerService,
)
from api.services.types.translator import TranslationStatus
from api.utils.llm.interfaces.llm_service import LLMService
from django.db import transaction


class CorrectionControllerServiceImpl(BaseBookBatchController, CorrectionControllerService):
    """校正制御サービスの実装クラス"""

    def __init__(
        self,
        target: TranslationTarget,
        llm_service: LLMService,
    ):
        """コンストラクタ

        Args:
            target (TranslationTarget): 校正対象
            llm_service (LLMService): LLMサービス
        """
        super().__init__(target, llm_service)
        self._api_client = CorrectionApiClient(
            llm_service=llm_service,
            model=target.batch.get_model,
        )

    def correct_file(self) -> None:
        """ファイルの校正を実行する

        Raises:
            ValueError: 設定が不正な場合
            Exception: その他のエラーが発生した場合
        """
        try:
            log_info_with_book_id(self.target.book_id, "校正を開始します")

            # 校正指示を取得
            correction_instruction = self.target.batch.correction_instruction
            if not correction_instruction:
                raise ValueError("校正指示が設定されていません")

            # キャンセル状態のチェック
            try:
                self.target.handle_cancellation("校正は既にキャンセルされています")
            except CancellationException:
                # キャンセル例外をキャッチして処理を終了
                raise

            # DBから翻訳済みデータを取得して校正を実行
            with transaction.atomic():
                # 前のバージョンからTAG_RECOVEREDステータスのデータを取得
                current_version = self.target.batch.translation_version.version
                previous_version_number = current_version - 1

                log_info_with_book_id(
                    self.target.book_id,
                    f"現在のバージョン: {current_version}, 前のバージョン: {previous_version_number}",
                )

                # 前のバージョンの全データを取得して状態を確認
                all_previous_translations = Translation.objects.filter(
                    translation_version__book=self.target.batch.translation_version.book,
                    translation_version__version=previous_version_number,
                ).order_by("line_number")

                if not all_previous_translations:
                    raise ValueError(
                        f"前のバージョン{previous_version_number}のデータが存在しません"
                    )

                log_info_with_book_id(
                    self.target.book_id,
                    f"前のバージョンの総データ数: {len(all_previous_translations)}",
                )

                # TAG_RECOVEREDステータスのデータのみを取得
                original_translations = Translation.objects.filter(
                    translation_version__book=self.target.batch.translation_version.book,
                    translation_version__version=previous_version_number,
                    status=TranslationStatus.TAG_RECOVERED,
                ).order_by("line_number")

                if not original_translations:
                    raise ValueError(
                        f"校正対象の翻訳データが見つかりません。"
                        f"バージョン{previous_version_number}のTAG_RECOVEREDステータスのデータが存在しません。"
                    )

                # 新しいバージョンにデータをコピー
                new_translations = []
                for translation in original_translations:
                    new_translation = Translation.objects.create(
                        translation_version=self.target.batch.translation_version,
                        line_id=translation.line_id,
                        line_number=translation.line_number,
                        target_language=translation.target_language,
                        chunk_count=translation.chunk_count,
                        chunk_max=translation.chunk_max,
                        source_text=translation.translated_text,  # 前回の翻訳結果をsource_textとして使用
                        translated_text="",  # 校正用の翻訳テキストは空で初期化
                        source_tags=translation.source_tags,
                        translated_tags=translation.translated_tags,
                        status=TranslationStatus.CHUNKED,
                    )
                    new_translations.append(new_translation)

                # 新しい翻訳データを校正
                total_chunks = len(new_translations)
                for i, translation in enumerate(new_translations, 1):
                    # キャンセル状態のチェック
                    try:
                        self.target.handle_cancellation(
                            f"処理がキャンセルされました（進捗: {i}/{total_chunks}）"
                        )
                    except CancellationException:
                        # キャンセル例外をキャッチして処理を終了
                        raise

                    try:
                        # 校正を実行
                        next_translation = new_translations[i] if i < total_chunks else None
                        self._api_client.correct_chunk(
                            chunk=translation,
                            next_chunk=(
                                next_translation.translated_text if next_translation else None
                            ),
                            correction_instruction=correction_instruction,
                            model=self.target.batch.get_model,
                        )
                        translation.save()

                        # 進捗を更新
                        self.target.batch.status_message = f"校正中: {i}/{total_chunks}"
                        self.target.batch.save(update_fields=["status_message"])

                    except Exception as e:
                        self._handle_chunk_error(i, e, total_chunks)
                        raise

                # 現在のバージョンのステータスを更新
                self.target.batch.translation_version.status = TranslationVersionStatus.CORRECTED
                self.target.batch.translation_version.save()

                log_info_with_book_id(self.target.book_id, "校正が完了しました")

        except Exception as e:
            log_error_with_book_id(self.target.book_id, f"校正中にエラーが発生: {str(e)}", e)
            raise
