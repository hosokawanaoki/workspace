import requests
from api.services.scraping.exceptions.scraping_exceptions import (
    GutenbergProcessingError,
)
from api.services.translation.interfaces.text_processing.zip_downloader_interface import (
    FileDownloaderInterface,
)


class FileDownloaderImpl(FileDownloaderInterface):
    """ファイルダウンロードの実装クラス"""

    def download(self, url: str) -> bytes:
        """URLからファイルをダウンロードする

        Args:
            url (str): ダウンロードするファイルのURL

        Returns:
            bytes: ダウンロードしたファイルのバイトデータ

        Raises:
            GutenbergProcessingError: ダウンロード中にエラーが発生した場合
        """
        response = requests.get(url)
        if response.status_code != 200:
            error_msg = (
                f"ファイルのダウンロードに失敗: ステータスコード {response.status_code}"
            )
            raise GutenbergProcessingError(error_msg)
        return response.content
