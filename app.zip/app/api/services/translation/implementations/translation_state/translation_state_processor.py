from datetime import datetime
from typing import Optional

from api.services.common.logging_utils import (
    log_error_with_book_id,
    log_info_with_book_id,
)
from api.services.models.translation_target import TranslationTarget
from api.services.translation.exceptions.translation_error import FileProcessingError
from api.services.translation.implementations.base.translation_api_client import (
    TranslationApiClient,
)
from api.services.translation.models.translation_state import TranslationState
from api.services.types.translator import (
    TranslationInfos,
    TranslationsData,
)
from api.utils.translation.translation_data_util import TranslationDataUtil
from api.utils.translation.translation_file_util import TranslationFileUtil


class TranslationStateProcessor:
    """翻訳状態の処理を行うクラス"""

    def __init__(
        self,
        api_client: TranslationApiClient,
        target: TranslationTarget,
    ):
        """初期化処理

        Args:
            api_client: APIクライアント
            target: 翻訳対象
        """
        self.api_client = api_client
        self.target = target
        self.state: Optional[TranslationState] = None
        self.translation_info: Optional[TranslationInfos] = None

    def _ensure_state_initialized(self) -> None:
        """状態が初期化されていることを確認する"""
        if not self.state:
            raise ValueError("状態が初期化されていません")

    def initialize_state(self, translations_data: TranslationsData) -> None:
        """状態を初期化する"""
        log_info_with_book_id(self.target.book_id, "翻訳状態を初期化します")
        self.translation_info = translations_data.translation_info
        self.state = TranslationState(
            chunks=translations_data.translations,
            config=self.target.config,
        )
        self.state.validate()
        TranslationDataUtil.save_to_db(translations_data)
        log_info_with_book_id(
            self.target.book_id,
            f"翻訳状態を初期化しました。チャンク数: {len(translations_data.translations)}",
        )

    def update_status(self, new_status: str) -> None:
        """状態を更新する"""
        self._ensure_state_initialized()

        try:
            self.target.book.set_status(new_status)
            log_info_with_book_id(
                self.target.book_id, f"ステータスを '{new_status}' に更新しました"
            )

        except Exception as e:
            error_msg = f"ステータス更新に失敗: {str(e)}"
            log_error_with_book_id(self.target.book_id, error_msg, e)
            raise ValueError(error_msg) from e

    def check_status(self) -> Optional[str]:
        """状態をチェックする"""
        if not self.state:
            log_info_with_book_id(self.target.book_id, "翻訳状態が初期化されていません")
            return "状態が初期化されていません"

        current_status = self.target.book.get_latest_status()
        if not self._is_valid_translation_status(current_status):
            message = f"現在のステータス '{current_status}' では" "翻訳を実行できません"
            log_info_with_book_id(self.target.book_id, message)
            return message

        log_info_with_book_id(
            self.target.book_id, f"ステータスチェック完了: {current_status}"
        )
        return None

    def _is_valid_translation_status(self, status: str) -> bool:
        """翻訳実行可能なステータスかを確認"""
        return status in ["ai-execution", "translating"]

    def process_chunk(self, sample_text: str = "", restrictions: str = "") -> bool:
        """チャンクの翻訳処理を実行

        Args:
            sample_text: サンプルテキスト
            restrictions: 制約条件

        Returns:
            bool: 処理を継続するかどうか

        Raises:
            ValueError: 状態が初期化されていない場合
            FileProcessingError: 翻訳処理に失敗した場合
        """
        self._ensure_state_initialized()

        try:
            if not self.state:
                raise ValueError("Translation state is not initialized")
            chunk = self.state.get_next_chunk()
            if not chunk:
                log_info_with_book_id(
                    self.target.book_id, "全てのチャンクの処理が完了しました"
                )
                # 最後のチャンク処理時は必ず保存
                self.save_state(self.target.batch.model, force_save=True)
                return False

            # 翻訳を実行
            self.api_client.translate_chunk(
                chunk,
                *self.state.get_surrounding_chunks(),
                sample_text=sample_text,
                restrictions=restrictions,
                model=self.target.batch.get_model,
            )

            self.state.mark_chunk_complete(self.state.current_index)
            return True
        except Exception as e:
            error_message = "チャンクの翻訳処理に失敗"
            log_error_with_book_id(self.target.book_id, f"{error_message}: {str(e)}", e)
            raise FileProcessingError(f"{error_message}: {str(e)}") from e

    def _should_save_state(self, processed_count: int) -> bool:
        """中間状態を保存すべきかを判定

        Args:
            processed_count: 処理済みチャンク数

        Returns:
            bool: 保存すべき場合True
        """
        return processed_count % 10 == 0  # 10件ごとに中間保存

    def save_state(self, model: str, force_save: bool = False) -> None:
        """状態を保存する

        Args:
            model: モデル名
            force_save: 強制保存フラグ（Trueの場合は_should_save_stateの結果に関わらず保存）

        Raises:
            ValueError: 状態が初期化されていない場合
            FileProcessingError: 状態保存に失敗した場合
        """
        self._ensure_state_initialized()
        if not self.state:
            raise ValueError("Translation state is not initialized")
        processed_count, total_count = self.state.get_progress()

        if not force_save and not self._should_save_state(processed_count):
            return

        def _save_current_state() -> None:
            log_info_with_book_id(
                self.target.book_id,
                f"状態を保存します（{processed_count}/{total_count}）",
            )

            # 翻訳状態の保存
            if not self.state:
                raise ValueError("Translation state is not initialized")

            # translation_infoの更新
            if self.translation_info:
                self.translation_info.timestamp = datetime.now().isoformat()
                self.translation_info.model = model

            # TranslationsDataの作成
            translations_data = TranslationsData(
                translation_info=self.translation_info,
                translations=self.state.chunks,
            )

            # 保存
            TranslationDataUtil.save_to_db(translations_data)
            TranslationFileUtil.save_recoveried_content(translations_data, self.target)

            # 進捗情報の更新
            if not self.state:
                raise ValueError("Translation state is not initialized")
            self.target.update_translation_progress(
                self.state.current_index,
                self.state.chunks,
            )

            log_info_with_book_id(
                self.target.book_id,
                f"状態を保存しました。進捗: {processed_count}/{total_count}, "
                f"バッチ時間: {self.target.batch.batch_time}",
            )

        try:
            _save_current_state()
        except Exception as e:
            error_message = "状態の保存に失敗"
            log_error_with_book_id(self.target.book_id, f"{error_message}: {str(e)}", e)
            raise FileProcessingError(f"{error_message}: {str(e)}") from e
