"""翻訳APIとの通信を行うクラス"""

from typing import Optional

from api.services.common.text_util.tag_replacer_util import TagReplacerUtil
from api.services.translation.implementations.base.base_api_client import BaseApiClient
from api.services.types.translator import Translations
from api.utils.llm.interfaces.llm_service import LLMService
from api.utils.llm.models.prompt_type import PromptType


class TranslationApiClient(BaseApiClient):
    """翻訳APIとの通信を行うクラス"""

    def __init__(
        self,
        llm_service: LLMService,
        model: str = "",
    ):
        """初期化処理

        Args:
            llm_service: LLMサービス
            model: 使用するモデル名
        """
        super().__init__(llm_service)
        if model:
            self.llm_service.update_config(model)

    def translate_chunk(
        self,
        chunk: Translations,
        previous_chunk: Optional[str],
        next_chunk: Optional[str],
        sample_text: str = "",
        restrictions: str = "",
        model: str = "",
    ) -> None:
        """チャンクを翻訳APIに送信する

        Args:
            chunk: 翻訳対象のチャンク
            previous_chunk: 前のチャンクの内容
            next_chunk: 次のチャンクの内容
            sample_text: サンプルテキスト
            restrictions: 制約条件
            model: 使用するモデル

        Raises:
            FileProcessingError: 翻訳に失敗した場合
        """
        # パラメータの準備
        params = {
            "chunk": TagReplacerUtil.convert_tags_to_entities(chunk.source_text),
            "restrictions": restrictions,
            "sample": TagReplacerUtil.convert_tags_to_entities(sample_text),
            "next_chunk": TagReplacerUtil.convert_tags_to_entities(next_chunk),
        }

        # 基底クラスの処理メソッドを呼び出し
        self._process_chunk(chunk, PromptType.TRANSLATION, params, model)
