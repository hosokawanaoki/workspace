"""APIクライアントの基底クラス"""

import logging

from api.services.common.text_util.tag_replacer_util import TagReplacerUtil
from api.services.translation.exceptions.translation_error import FileProcessingError
from api.services.types.translator import Translations, TranslationStatus
from api.utils.llm.interfaces.llm_service import LLMService
from api.utils.llm.models.prompt_type import PromptType

logger = logging.getLogger(__name__)


class BaseApiClient:
    """APIクライアントの基底クラス"""

    def __init__(
        self,
        llm_service: LLMService,
    ):
        """初期化処理

        Args:
            llm_service: LLMサービス
        """
        self.llm_service = llm_service

    def _process_chunk(
        self,
        chunk: Translations,
        prompt_type: PromptType,
        params: dict,
        model: str = "",
    ) -> None:
        """チャンクを処理する

        Args:
            chunk: 処理対象のチャンク
            prompt_type: プロンプトタイプ
            params: APIパラメータ
            model: 使用するモデル

        Raises:
            FileProcessingError: 処理に失敗した場合
        """
        try:
            # LLMを使用して処理を実行
            logger.info(f"チャンクID {chunk.id}: {prompt_type.value}APIを呼び出します")
            response = self.llm_service.send_message(
                prompt_type=prompt_type,
                variables=[params],
                model=model,
            )

            # 結果の後処理
            chunk.translated_text = TagReplacerUtil.convert_entities_to_tags(
                response.content
            )
            chunk.status = TranslationStatus.PROCESSED
            logger.info(
                f"チャンクID {chunk.id}: チャンクの{prompt_type.value}が完了しました"
            )

        except Exception as e:
            error_message = f"チャンクの{prompt_type.value}に失敗しました"
            raise FileProcessingError(f"{error_message}: {str(e)}") from e
