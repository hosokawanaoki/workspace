"""書籍バッチ処理の実装例"""

import logging
from typing import Any, Dict, List, Optional, Tuple

from api.models.book import Book
from api.models.translation_batch import TranslationBatch
from api.services.book.implementations.book_info_updater import BookInfoUpdater
from api.services.models.translation_batch_service import TranslationBatchService
from api.services.models.translation_target import TranslationTarget
from api.services.scheduler.core.interfaces.batch_processor import BatchProcessor
from api.services.translation.exceptions.translation_error import CancellationException
from api.services.translation.interfaces.translation_service import TranslationService
from api.services.translation.models.translator_config import TranslatorConfig
from api.utils.translation.translation_process_util import TranslationProcessUtil
from django.db import transaction

logger = logging.getLogger(__name__)


class BookBatchProcessor(BatchProcessor):
    """書籍バッチ処理の実装例

    BatchProcessorインターフェースを実装し、書籍の翻訳処理を
    スケジューラフレームワークに統合する例を示します。
    """

    def __init__(
        self,
        translator_service: TranslationService,
        book_info_updater: BookInfoUpdater,
        translator_config: TranslatorConfig,
    ):
        """初期化

        Args:
            translator_service: 翻訳サービス
            book_info_updater: 書籍情報更新
            translator_config: 翻訳設定
        """
        self.translator_service = translator_service
        self.book_info_updater = book_info_updater
        self.translator_config = translator_config

    def process_batch(self, context: Optional[Dict[str, Any]] = None) -> None:
        """バッチ処理を実行する

        Args:
            context: 実行コンテキスト（オプション）
                - task_id: 処理するタスクID
        """
        try:
            # コンテキストからタスクIDを取得
            task_id = context.get("task_id", "default") if context else "default"
            logger.info(f"タスク {task_id}: バッチ処理を開始します")

            # 待機中の書籍を取得
            waiting_books = Book.get_waiting_books()
            if not waiting_books:
                logger.info(f"タスク {task_id}: 待機中の書籍はありません")
                return

            logger.info(f"タスク {task_id}: 待機中の書籍が{len(waiting_books)}件見つかりました")

            # トランザクションを使用して、バッチの選択とステータス更新を原子的に行う
            book, batch = self._select_and_lock_batch(waiting_books, task_id)
            if not book or not batch:
                logger.info(f"タスク {task_id}: 処理可能な書籍が見つかりませんでした")
                return

            if book.needs_info_update:
                logger.info(f"タスク {task_id}: 書籍 {book.book_id} の情報更新が必要です")
                self.book_info_updater.update_book_info_from_llm(book)

            # TranslationTargetを作成
            target = TranslationTarget(book=book, batch=batch, config=self.translator_config)
            # バッチのタイプに応じて処理を分岐
            if batch.mode == "translation":
                target.start_processing()
                # 翻訳前の準備処理を実行
                logger.info(f"タスク {task_id}: 書籍 {book.book_id} の翻訳前準備処理を開始")
                self.translator_service.prepare_translation(book)
                # 翻訳を実行
                logger.info(f"タスク {task_id}: 書籍 {book.book_id} の翻訳処理を開始")
                self.translator_service.start_translate(target)
            else:
                # 校正の場合
                target.start_processing()
                logger.info(f"タスク {task_id}: 書籍 {book.book_id} の校正処理を開始")
                self.translator_service.start_correction(target)

            # 翻訳ステータスを更新
            TranslationProcessUtil.update_translation_status(target)
            logger.info(f"タスク {task_id}: 書籍 {book.book_id} の翻訳ステータスを更新しました")

        except CancellationException as ce:
            # キャンセル例外は正常終了として扱う
            logger.info(f"タスク {task_id}: キャンセルにより処理を終了しました: {str(ce)}")
            return
        except Exception as e:
            logger.error(f"タスク {task_id}: バッチ処理でエラーが発生しました: {str(e)}")
            raise

    def _select_and_lock_batch(
        self, waiting_books: List[Book], task_id: str
    ) -> Tuple[Optional[Book], Optional[TranslationBatch]]:
        """バッチを選択してロックする（ステータスを処理中に更新）

        Args:
            waiting_books: 待機中の書籍リスト
            task_id: タスクID

        Returns:
            Tuple[Optional[Book], Optional[TranslationBatch]]: 選択した書籍とバッチのタプル
        """
        try:
            with transaction.atomic():
                # 最も古いバッチを持つ書籍とバッチを取得
                book, batch = TranslationBatchService.find_oldest_batch_book(waiting_books)
                if not book or not batch:
                    return None, None

                # バッチのステータスを処理中に更新（他のプロセスが同じバッチを選ばないようにする）
                if batch.status == "pending":
                    batch.set_status("processing")
                    logger.info(
                        f"タスク {task_id}: バッチID {batch.id} のステータスを 'processing' に更新しました"
                    )
                else:
                    logger.warning(
                        f"タスク {task_id}: バッチID {batch.id} のステータスが 'pending' ではありません（現在: {batch.status}）"
                    )
                    return None, None

                return book, batch
        except Exception as e:
            logger.error(
                f"タスク {task_id}: バッチの選択とロック中にエラーが発生しました: {str(e)}"
            )
            return None, None

    def handle_error(self, error: Exception, context: Optional[Dict[str, Any]] = None) -> None:
        """エラー処理を行う

        Args:
            error: 発生したエラー
            context: 実行コンテキスト（オプション）
        """
        # キャンセル例外は正常終了として扱う
        if isinstance(error, CancellationException):
            task_id = context.get("task_id", "default") if context else "default"
            logger.info(f"タスク {task_id}: キャンセルにより処理を終了しました: {str(error)}")
            return

        logger.error(f"エラーが発生しました: {str(error)}")
        if context and "book_id" in context:
            book = Book.get_book_by_book_id(context["book_id"])
            if book:
                book.set_status("error")
