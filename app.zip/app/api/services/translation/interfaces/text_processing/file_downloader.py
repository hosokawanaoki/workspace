"""FileDownloaderインターフェース"""

from abc import ABC, abstractmethod


class FileDownloader(ABC):
    """ファイルダウンロード処理のインターフェース"""

    @abstractmethod
    def download_file(self, url: str, save_path: str) -> None:
        """ファイルをダウンロードする

        Args:
            url (str): ダウンロード元のURL
            save_path (str): 保存先のパス
        """
        pass
