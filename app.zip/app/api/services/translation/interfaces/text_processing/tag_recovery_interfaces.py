from abc import ABC, abstractmethod
from typing import List

from api.services.types.translator import TranslationsData


class TagRecoveryPromptService(ABC):
    """タグ復元プロンプトサービスのインターフェース"""

    @abstractmethod
    def get_duplicate_tag_instruction(self, duplicate_tags: List[str]) -> str:
        """重複タグの修正指示を取得する

        Args:
            duplicate_tags: 重複タグのリスト

        Returns:
            str: 修正指示
        """
        pass

    @abstractmethod
    def get_missing_tag_instruction(self, missing_tags: List[str]) -> str:
        """欠損タグの修正指示を取得する

        Args:
            missing_tags: 欠損タグのリスト

        Returns:
            str: 修正指示
        """
        pass

    @abstractmethod
    def recovery_prompt_common(
        self, source_text: str, translated_text: str, instruction: str
    ) -> str:
        """共通のタグ復元プロンプトを取得する

        Args:
            source_text: 原文
            translated_text: 翻訳文
            instruction: 修正指示

        Returns:
            str: プロンプト
        """
        pass


class TagRecoveryValidator(ABC):
    """タグ復元バリデーターのインターフェース"""

    @abstractmethod
    def validate_recovery(self, recover_tags: TranslationsData) -> bool:
        """タグ復元結果を検証する

        Args:
            recover_tags: タグ復元後のTranslationsData

        Returns:
            bool: すべてのタグが正しく修復されたかどうか
        """
        pass
