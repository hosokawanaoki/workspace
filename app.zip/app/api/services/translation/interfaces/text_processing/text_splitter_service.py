from abc import ABC, abstractmethod
from typing import List

from api.services.types.translator import Translations, TranslationsData


class TextSplitterService(ABC):
    """テキスト分割サービスのインターフェース

    大きなテキストを翻訳可能な単位に分割する責務を持つ
    """

    @abstractmethod
    def create_chunks(self, lines: List[str]) -> List[Translations]:
        """テキストを翻訳可能な単位に分割する

        Args:
            lines (List[str]): 分割対象のテキスト行のリスト

        Returns:
            List[Translations]: 分割されたテキストのリスト
        """
        pass

    @abstractmethod
    def prepare_chunks(self, lines: List[str], book_id: str) -> TranslationsData:
        """チャンク分割してTranslationsDataを作成する

        Args:
            lines: 分割対象のテキスト行のリスト
            book_id: 書籍ID

        Returns:
            TranslationsData: チャンク分割されたデータ
        """
        pass
