from abc import ABC, abstractmethod


class ZipDownloaderInterface(ABC):
    """ZIPファイルのダウンロードと解凍を行うインターフェース"""

    @abstractmethod
    def download_and_extract(self, book_id: str) -> str:
        """ZIPファイルをダウンロードして解凍する

        Args:
            book_id (str): 書籍ID

        Returns:
            str: 解凍したHTMLファイルのパス

        Raises:
            GutenbergProcessingError: ダウンロードまたは解凍中にエラーが発生した場合
        """
        pass


class FileDownloaderInterface(ABC):
    """ファイルダウンロードを行うインターフェース"""

    @abstractmethod
    def download(self, url: str) -> bytes:
        """URLからファイルをダウンロードする

        Args:
            url (str): ダウンロードするファイルのURL

        Returns:
            bytes: ダウンロードしたファイルのバイトデータ

        Raises:
            GutenbergProcessingError: ダウンロード中にエラーが発生した場合
        """
        pass
