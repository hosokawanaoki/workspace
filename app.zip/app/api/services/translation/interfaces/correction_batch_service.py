from abc import ABC, abstractmethod
from typing import Dict


class CorrectionBatchService(ABC):
    """校正バッチサービスのインターフェース

    書籍の校正バッチを作成・管理するためのインターフェースを定義します。
    """

    @abstractmethod
    def create_batch(
        self, book_id: str, version_name: str, correction_instruction: str, model: str
    ) -> Dict[str, int]:
        """校正バッチを作成する

        Args:
            book_id (str): 書籍ID
            version_name (str): バージョンの説明
            correction_instruction (str): 校正指示
            model (str): 使用するLLMモデル

        Returns:
            Dict[str, int]: 作成されたバージョンIDとバッチID
                - version_id: 作成されたバージョンのID
                - batch_id: 作成されたバッチのID

        Raises:
            ValueError: パラメータが不正な場合
            Exception: その他のエラーが発生した場合
        """
        pass
