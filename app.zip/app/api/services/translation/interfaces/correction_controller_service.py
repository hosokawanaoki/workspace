from abc import ABC, abstractmethod


class CorrectionControllerService(ABC):
    """校正制御サービスのインターフェース"""

    @abstractmethod
    def correct_file(self) -> None:
        """ファイルの校正を実行する

        Raises:
            ValueError: 設定が不正な場合
            Exception: その他のエラーが発生した場合
        """
        pass
