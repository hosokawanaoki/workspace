from abc import ABC, abstractmethod

from api.models.book import Book


class TextPreProcessor(ABC):
    """テキスト前処理のインターフェース"""

    @abstractmethod
    def process(self, book: Book) -> str:
        """テキストの前処理を実行する

        Args:
            book (Book): 処理対象の書籍

        Returns:
            str: 処理済みのテキスト

        Raises:
            Exception: 処理中にエラーが発生した場合
        """
        pass
