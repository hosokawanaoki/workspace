class TranslationError(Exception):
    """翻訳処理に関連するエラーの基底クラス"""

    pass


class FileProcessingError(TranslationError):
    """ファイル処理に関連するエラー"""

    pass


class CancellationException(TranslationError):
    """キャンセル処理に関連するエラー

    翻訳処理がキャンセルされた場合に発生する例外です。
    この例外をキャッチすることで、キャンセル処理を適切に行うことができます。
    """

    pass
