from abc import ABC, abstractmethod


class BookService(ABC):
    """書籍関連のサービスインターフェース"""

    @abstractmethod
    def validate_book_id(self, book_id: str | None) -> None:
        """書籍IDの妥当性を検証する

        Args:
            book_id (str | None): 書籍ID

        Raises:
            ValueError: book_idが提供されていない場合
        """
        pass
