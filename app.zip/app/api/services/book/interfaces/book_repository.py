from typing import Protocol

from api.models.book import Book
from django.db.models import QuerySet


class BookRepository(Protocol):
    def has_executing_books(self) -> bool:
        """AI実行中の書籍が存在するかチェックする

        Returns:
            bool: AI実行中の書籍が存在する場合はTrue
        """
        pass

    def get_waiting_books(self) -> QuerySet[Book]:
        """翻訳待ちの書籍を取得する

        Returns:
            QuerySet[Book]: 翻訳待ち状態の書籍のクエリセット
        """
        pass

    def update_book_status(self, book_id: str, status: str) -> Book:
        """書籍のステータスを更新する

        Args:
            book_id (int): 書籍ID
            status (str): 新しいステータス
        """
        pass
