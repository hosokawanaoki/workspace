"""書籍バッチサービスのインターフェース"""

from abc import ABC, abstractmethod
from typing import Optional, Tuple, TypedDict

from api.models.book import Book
from api.models.translation_batch import TranslationBatch


class BatchCreationResult(TypedDict):
    """バッチ作成結果の型定義"""

    batch_id: str
    version_id: str


class BookBatchService(ABC):
    """書籍バッチサービスのインターフェース"""

    @abstractmethod
    def create_translation_batch(
        self,
        book_id: str,
        translation_setting_id: int,
        limit: int,
        model: str,
        provider: Optional[str] = None,
        original_id: Optional[str] = None,
        language: Optional[str] = None,
        version: int = 1,
    ) -> Tuple[Book, TranslationBatch]:
        """書籍のステータスをwaitingに更新し、翻訳バッチを作成する

        Args:
            book_id (str): 書籍ID
            translation_setting_id (int): 翻訳設定ID
            limit (int): 制限数
            model (str): 使用するLLMモデル
            provider (str, optional): プロバイダー
            original_id (str, optional): オリジナルID
            language (str, optional): 言語
            version (int, optional): バージョン番号

        Returns:
            Tuple[Book, TranslationBatch]: 更新された書籍と作成された翻訳バッチ

        Raises:
            ValueError: パラメータが不正な場合
        """
        pass

    @abstractmethod
    def cancel_translation_batch(self, book_id: str) -> None:
        """書籍IDに基づいて翻訳バッチをキャンセルする

        Args:
            book_id: 書籍ID

        Raises:
            ValueError: 書籍が見つからない場合
        """
        pass

    @abstractmethod
    def delete_translation_batch(self, book_id: str) -> None:
        """書籍IDに基づいて翻訳バッチ削除し、関連ファイルを削除する

        Args:
            book_id: 書籍ID

        Raises:
            ValueError: 書籍が見つからない場合
        """
        pass
