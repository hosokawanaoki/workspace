"""書籍処理の依存関係を初期化するファクトリ"""

from api.services.book.implementations.book_info_updater import BookInfoUpdater
from api.services.scraping.book_parser import BookParser
from api.services.scraping.gutenberg_scraper import GutenbergScraper, ScraperConfig
from api.services.scraping.implementations.gutenberg_downloader_service import (
    GutenbergDownloaderService,
)
from api.services.scraping.implementations.http_client_impl import HttpClientImpl
from api.services.scraping.progress_manager import ProgressManager
from api.services.translation.implementations.book_batch_processor import (
    BookBatchProcessor,
)
from api.services.translation.implementations.text_processing.file_downloader_impl import (
    FileDownloaderImpl,
)
from api.services.translation.implementations.text_processing.tag_recovery_service_impl import (
    TagRecoveryServiceImpl,
)
from api.services.translation.implementations.text_processing.text_pre_processor_impl import (
    TextPreProcessorImpl,
)
from api.services.translation.implementations.translation_service_impl import (
    TranslationServiceImpl,
)
from api.services.translation.models.translator_config import TranslatorConfig


class BookProcessorFactory:
    """書籍処理の依存関係を初期化するファクトリ"""

    @staticmethod
    def create_batch_processor() -> BookBatchProcessor:
        """書籍バッチプロセッサを作成する

        Returns:
            BookBatchProcessor: 初期化された書籍バッチプロセッサ
        """
        # 基本コンポーネントの初期化
        file_downloader = FileDownloaderImpl()
        http_client = HttpClientImpl()
        progress_manager = ProgressManager()
        book_parser = BookParser()

        # Gutenberg関連のコンポーネントを初期化
        scraper = GutenbergScraper(
            config=ScraperConfig(),
            http_client=http_client,
            progress_manager=progress_manager,
            book_parser=book_parser,
        )
        gutenberg_downloader = GutenbergDownloaderService(
            file_downloader=file_downloader,
        )

        # BookInfoUpdaterの初期化
        book_info_updater = BookInfoUpdater(
            scraper=scraper,
        )

        # テキスト処理コンポーネントの初期化
        text_pre_processor = TextPreProcessorImpl(
            file_downloader=file_downloader,
            book_info_updater=book_info_updater,
            gutenberg_downloader=gutenberg_downloader,
        )
        tag_recovery_service = TagRecoveryServiceImpl()

        # 翻訳サービスの初期化
        translator_service = TranslationServiceImpl(
            text_pre_processor=text_pre_processor,
            tag_recovery_service=tag_recovery_service,
        )

        # 翻訳設定の初期化
        translator_config = TranslatorConfig()

        # バッチプロセッサの作成
        return BookBatchProcessor(
            translator_service=translator_service,
            book_info_updater=book_info_updater,
            translator_config=translator_config,
        )
