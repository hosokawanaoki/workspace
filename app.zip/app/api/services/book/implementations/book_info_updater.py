import json
import logging

from api.models.book import Book
from api.services.scraping.gutenberg_scraper import GutenbergScraper
from api.services.types.book_info import (
    CombinedBookInfo,
)
from api.utils.llm.factory.llm_service_factory import LLMServiceFactory
from api.utils.llm.models.prompt_type import PromptType

logger = logging.getLogger(__name__)


class BookInfoUpdater:
    """生成AIを使用して書籍情報を更新するクラス"""

    def __init__(
        self,
        scraper: GutenbergScraper,
    ):
        """BookInfoUpdaterを初期化する

        Args:
            scraper: Gutenbergスクレイパー
        """
        self.scraper = scraper

    def update_book_info_from_llm(self, book: Book) -> None:
        """生成AIを使用して書籍情報を更新する

        Args:
            book (Book): 更新対象の書籍
        """
        try:
            # 単一の書籍情報を取得
            book_info = self.scraper.get_single_book(int(book.original_id))
            if not book_info:
                raise ValueError(f"書籍 {book.book_id} の情報が取得できませんでした")

            # スクレイピング結果をログ出力
            logger.info(f"スクレイピング結果: {book_info}")

            # プロンプト変数の準備
            title = book_info["title"]
            logger.info(f"LLMに送信するタイトル: '{title}'")

            # 生成AIにリクエスト
            response = LLMServiceFactory.create().send_message(
                prompt_type=PromptType.GET_BOOK,
                variables=[{"title": title}],  # 辞書をリストとして渡す
                model="claude",  # 固定のモデルを使用
            )
            logger.info(f"生成AIからの応答: {response.content}")

            # レスポンスの内容を検証
            content = response.content.strip()
            # 余分な改行とスペースを削除
            content = "".join(line.strip() for line in content.splitlines())
            logger.info(f"整形後のJSON: {content}")
            try:
                llm_data = json.loads(content)
                # スクレイピングで取得した情報とLLMの翻訳を結合
                combined_data: CombinedBookInfo = {
                    "title": book_info["title"],
                    "title_jp": llm_data["title_jp"],
                    "author": book_info["author"],
                    "language": book_info["language"],
                    "downloads": book_info["downloads"],
                    "copyright_status": book_info["copyright_status"],
                    "subject": book_info["subject"],
                    "summary": book_info["summary"],
                    "url": book_info["url"],
                    "original_id": book_info["original_id"],
                }
                Book.update_or_create_book(book.book_id, combined_data)
                logger.info(f"書籍 {book.book_id} の情報をDBに保存しました")
            except json.JSONDecodeError as json_error:
                logger.error(
                    f"JSONパースエラー: {str(json_error)}, 受信内容: {content}"
                )
                # JSONパースエラーの場合でもbook_idとoriginal_idを保存
                Book.update_or_create_book(
                    book.book_id,
                    {"book_id": book.book_id, "original_id": book_info["original_id"]},
                )
                logger.info(f"書籍 {book.book_id} をIDのみでDBに保存しました")

        except Exception as ai_error:
            logger.error(
                f"書籍 {book.book_id} の生成AIからの更新に失敗: {str(ai_error)}"
            )
            # エラーが発生した場合でもbook_idとoriginal_idを保存
            Book.update_or_create_book(
                book.book_id, {"book_id": book.book_id, "original_id": book.original_id}
            )
            logger.info(f"書籍 {book.book_id} をIDのみでDBに保存しました")
