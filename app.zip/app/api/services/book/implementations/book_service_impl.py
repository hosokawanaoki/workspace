import logging
from typing import Optional

from api.models.book import Book
from api.services.book.interfaces.book_service import BookService

logger = logging.getLogger(__name__)


class BookServiceImpl(BookService):
    """書籍関連のサービス実装クラス"""

    def validate_book_id(self, book_id: str | None) -> None:
        """書籍IDの妥当性を検証する

        Args:
            book_id (str | None): 書籍ID

        Raises:
            ValueError: book_idが不正な場合
        """
        if not book_id:
            raise ValueError("book_idは必須パラメータです。")

        if not isinstance(book_id, str):
            logger.error(f"Invalid book_id type: {type(book_id)}")
            raise ValueError("book_idは文字列である必要があります")

        # book_idの形式を検証（provider_id_book_id_model_language）
        parts = book_id.split("_")
        if len(parts) != 4:
            logger.error(f"Invalid book_id format: {book_id}")
            raise ValueError(
                "book_idは'provider_id_book_id_model_language'の形式である必要があります"
            )

    def get_or_create_book(
        self,
        book_id: str,
        status: Optional[str] = None,
        provider: Optional[str] = None,
        original_id: Optional[str] = None,
        language: Optional[str] = None,
    ) -> Book:
        """書籍IDに基づいて書籍を取得または作成する

        Args:
            book_id (str): 書籍ID
            status (Optional[str], optional): 設定するステータス. Defaults to None.
            provider (Optional[str], optional): プロバイダー. Defaults to None.
            original_id (Optional[str], optional): 元のID. Defaults to None.
            language (Optional[str], optional): 言語. Defaults to None.

        Returns:
            Book: 書籍オブジェクト

        Raises:
            ValueError: book_idが不正な場合
        """
        self.validate_book_id(book_id)
        data = {}
        if status:
            # ステータスの検証
            data["status"] = Book.get_status_type(status)
        if provider:
            data["provider"] = provider
        if original_id:
            data["original_id"] = original_id
        if language:
            data["language"] = language

        book, _ = Book.update_or_create_record(
            identifier={"book_id": book_id},
            data=data,
        )
        return book
