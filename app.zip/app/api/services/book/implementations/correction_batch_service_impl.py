import logging

from api.models.book import Book
from api.models.translation_version import TranslationVersion
from api.services.book.implementations.book_service_impl import BookServiceImpl
from api.services.models.translation_batch_service import TranslationBatchService
from api.services.models.translation_version_service import TranslationVersionService
from api.services.translation.interfaces.correction_batch_service import (
    CorrectionBatchService,
)

logger = logging.getLogger(__name__)


class CorrectionBatchServiceImpl(CorrectionBatchService):
    """校正バッチサービスの実装クラス

    書籍の校正バッチを作成・管理するサービスの実装を提供します。
    """

    def __init__(self, book_service=None):
        """初期化

        Args:
            book_service: 書籍サービス（省略時はデフォルト）
        """
        self.book_service = book_service or BookServiceImpl()

    def _process_batch_creation(
        self, book_id: str, version_name: str, correction_instruction: str, model: str
    ) -> dict[str, int]:
        """校正バッチ作成の処理を実行

        Args:
            book_id (str): 書籍ID
            version_name (str): バージョンの説明
            correction_instruction (str): 校正指示

        Returns:
            dict[str, int]: 作成されたバージョンIDとバッチID

        Raises:
            ValueError: パラメータが不正な場合
            DatabaseError: データベース操作に失敗した場合
        """
        logger.info(f"書籍 {book_id} の校正バッチ作成を開始します")

        # 書籍の取得
        book = Book.get_book_by_book_id(book_id)
        if not book:
            raise ValueError(f"書籍 {book_id} が見つかりません")
        logger.info(f"書籍 {book_id} を取得しました")

        # ステータスを待機中に更新
        book.set_status("waiting")
        logger.info(f"書籍 {book_id} のステータスを待機中に更新しました")

        # 次のバージョン番号を取得
        next_version_number = TranslationVersionService.get_next_version_number(book)
        logger.info(f"書籍 {book_id} の次のバージョン番号: {next_version_number}")

        # 新しいバージョンの作成
        new_version = TranslationVersion.objects.create(
            book=book,
            version=next_version_number,
            description=version_name,
        )
        logger.info(f"書籍 {book_id} のバージョン {new_version.version} を作成しました")

        # 校正用バッチの作成
        batch = TranslationBatchService.create_batch(
            book=book,
            version_number=next_version_number,  # 作成したバージョン番号を指定
            translation_setting=None,  # 校正では不要
            model=model,
            limit=1000,  # デフォルト制限
            mode="correction",
            correction_instruction=correction_instruction,
        )
        logger.info(f"書籍 {book_id} の校正バッチを作成しました")

        return {
            "version_id": new_version.id,
            "batch_id": batch.id,
        }

    def create_batch(
        self, book_id: str, version_name: str, correction_instruction: str, model: str
    ) -> dict[str, int]:
        """校正バッチを作成する

        Args:
            book_id (str): 書籍ID
            version_name (str): バージョンの説明
            correction_instruction (str): 校正指示

        Returns:
            dict[str, int]: 作成されたバージョンIDとバッチID
                - version_id: 作成されたバージョンのID
                - batch_id: 作成されたバッチのID

        Raises:
            ValueError: パラメータが不正な場合
            DatabaseError: データベース操作に失敗した場合
            Exception: その他のエラーが発生した場合
        """
        logger.info(f"書籍 {book_id} の校正バッチ作成処理を開始")
        result = self._process_batch_creation(
            book_id, version_name, correction_instruction, model
        )
        logger.info(f"書籍 {book_id} の校正バッチ作成処理が完了")
        return result
