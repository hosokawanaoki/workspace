import logging
from typing import Tuple

from api.models.book import Book
from api.models.translation_batch import TranslationBatch
from api.models.translation_setting import TranslationSetting
from api.services.book.implementations.book_service_impl import BookServiceImpl
from api.services.book.interfaces.book_batch_service import BookBatchService
from api.services.models.translation_batch_service import TranslationBatchService
from api.services.models.translation_service import TranslationService
from api.services.models.translation_version_service import TranslationVersionService
from api.utils.llm.consts import LLM

logger = logging.getLogger(__name__)


class BookBatchServiceImpl(BookBatchService):
    """書籍バッチ処理の実装クラス"""

    ALLOWED_MODELS = LLM["AVAILABLE_MODELS"]

    def __init__(self):
        self.book_service = BookServiceImpl()

    def _validate_model(self, model: str) -> None:
        """モデル名の妥当性を検証する

        Args:
            model (str): 検証するモデル名

        Raises:
            ValueError: モデル名が不正な場合
        """
        if model not in self.ALLOWED_MODELS:
            raise ValueError(
                f"不正なモデル名です。許可されたモデル: {', '.join(self.ALLOWED_MODELS)}"
            )

    def _get_translation_setting(self, translation_setting_id: int | None) -> None:
        """翻訳設定を取得する

        Args:
            translation_setting_id (int | None): 翻訳設定ID

        Returns:
            TranslationSetting: 翻訳設定

        Raises:
            ValueError: translation_setting_idが不正な場合
        """

        if translation_setting_id is None:
            raise ValueError("translation_setting_idは必須パラメータです。")

        setting = TranslationSetting.get(id=translation_setting_id)
        if not setting:
            raise ValueError(f"id={translation_setting_id}の翻訳設定が見つかりません。")

        return setting

    def create_translation_batch(
        self,
        book_id: str,
        translation_setting_id: int,
        limit: int,
        model: str,
        provider: str = None,
        original_id: str = None,
        language: str = None,
        version: int = 1,
    ) -> Tuple[Book, TranslationBatch]:
        """書籍のステータスをwaitingに更新し、翻訳バッチを作成する

        Args:
            book_id (str): 書籍ID
            translation_setting_id (int): 翻訳設定ID
            limit (int): 制限数
            model (str, optional): 使用するLLMモデル.

        Returns:
            Tuple[Book, TranslationBatch]: 更新された書籍と作成された翻訳バッチ

        Raises:
            ValueError: パラメータが不正な場合
        """
        try:
            setting = self._get_translation_setting(translation_setting_id)
            self._validate_model(model)

            book = self.book_service.get_or_create_book(
                book_id=book_id,
                status="waiting",
                provider=provider,
                original_id=original_id,
                language=language,
            )
            batch = TranslationBatchService.create_batch(
                book=book,
                translation_setting=setting,
                model=model,
                limit=limit,
                version_number=version,
            )

            return book, batch

        except Exception as e:
            logger.error(f"Error creating translation batch: {str(e)}")
            raise

    def cancel_translation_batch(self, book_id: str) -> None:
        """書籍IDに基づいて翻訳バッチをキャンセルする

        Args:
            book_id: 書籍ID

        Raises:
            ValueError: 書籍が見つからない場合
        """
        try:
            book = Book.get_book_by_book_id(book_id)
            if not book:
                raise ValueError(f"書籍 {book_id} が見つかりません")

            # ステータスチェック
            if book.status not in ["waiting", "ai-execution"]:
                raise ValueError(
                    f"キャンセルできるのは待機中またはAI実行中の書籍のみです。現在のステータス: {book.status}"
                )

            batch = TranslationBatchService.get_latest_for_book(book)
            if not batch:
                raise ValueError(f"書籍 {book_id} に関連する翻訳バッチが見つかりません")

            book.update_or_create_record(
                identifier={"id": book.id}, data={"status": "cancel"}
            )
            batch.update_or_create_record(
                identifier={"id": batch.id}, data={"status": "stopped"}
            )

            logger.info(f"書籍 {book_id} の翻訳バッチをキャンセルしました")

        except Exception as e:
            logger.error(f"翻訳バッチのキャンセル中にエラーが発生しました: {str(e)}")
            raise

    def delete_translation_batch(self, book_id: str) -> None:
        """書籍IDに基づいて翻訳バッチ削除し、関連ファイルを削除する

        Args:
            book_id: 書籍ID

        Raises:
            ValueError: 書籍が見つからない場合
        """
        try:
            book = Book.get_book_by_book_id(book_id)
            if not book:
                raise ValueError(f"書籍 {book_id} が見つかりません")

            # 関連するTranslationVersionを取得して削除
            versions = TranslationVersionService.get_versions_for_book(book)
            for version in versions:
                TranslationService.delete_by_version(version)

            # 書籍の削除
            book.delete()

            logger.info(f"書籍 {book_id} を削除しました")

        except Exception as e:
            logger.error(f"翻訳を削除中にエラーが発生しました: {str(e)}")
            raise
