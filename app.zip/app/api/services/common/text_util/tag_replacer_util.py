"""タグ置換および変換ユーティリティ"""

import logging
import re
from typing import Dict, List, Literal, Optional, TextIO

from api.constants.constants import HTML_TAGS, SYSTEM
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)


class TagReplacerUtil:
    """タグ置換および変換処理のユーティリティクラス

    テキスト内のHTMLタグの置換、変換、正規化などの機能を提供します。
    全てのメソッドは静的メソッドとして実装されています。
    """

    _tag_pattern = re.compile(r"<[^>]+>")
    _placeholder_format = "TAG_{}"

    @staticmethod
    def replace_tags_with_placeholders(html_path: str) -> tuple[str, list[dict]]:
        """HTMLファイル内のタグをプレースホルダーに置き換える

        Args:
            html_path (str): HTMLファイルのパス

        Returns:
            Tuple[str, List[Dict]]: 処理済みHTMLと置換情報のリスト

        Raises:
            GutenbergProcessingError: タグ置換処理中にエラーが発生した場合
        """
        # HTMLファイルの読み込み
        mode: Literal["r"] = "r"
        file: TextIO
        with open(
            html_path,
            mode=mode,
            encoding=SYSTEM["DEFAULT_ENCODING"],
        ) as file:
            html_content = file.read()

        soup = BeautifulSoup(html_content, "html.parser")
        tag_info_list = []
        tag_counter = 1

        # HTMLタグをプレースホルダーに置換
        for element in soup.find_all(True):
            placeholder = f"tag{tag_counter}"
            tag_info = {
                "placeholder": placeholder,
                "tag_name": element.name,
                "attributes": dict(element.attrs),
                "self_close": element.is_empty_element,
            }

            # 開始タグの挿入
            start_tag = soup.new_string(
                HTML_TAGS["TAG_START_FORMAT"].format("tag" + str(tag_counter))
            )
            element.insert_before(start_tag)

            # 終了タグの挿入（自己終了タグでない場合）
            if not element.is_empty_element:
                end_tag = soup.new_string(
                    HTML_TAGS["TAG_END_FORMAT"].format("tag" + str(tag_counter))
                )
                element.insert_after(end_tag)

            tag_info_list.append(tag_info)

            # 子要素を保持しながら元のタグを削除
            for child in list(element.children):
                element.insert_before(child)
            element.decompose()

            tag_counter += 1

        return str(soup), tag_info_list

    @staticmethod
    def restore_tags(text: str, tag_map: dict[str, str]) -> str:
        """プレースホルダーを元のタグに戻す

        Args:
            text (str): 処理対象のテキスト
            tag_map (dict[str, str]): タグとプレースホルダーのマッピング

        Returns:
            str: 復元後のテキスト
        """
        restored_text = text
        for placeholder, tag in tag_map.items():
            restored_text = restored_text.replace(placeholder, tag)
        return restored_text

    @staticmethod
    def convert_tags_to_entities(text: Optional[str]) -> str:
        """タグをHTMLエンティティに変換する

        Args:
            text: 変換対象のテキスト

        Returns:
            str: 変換後のテキスト。入力がNoneまたは空文字の場合は空文字を返す
        """
        if not text:
            return ""
        return text.replace("[", "&#91;").replace("]", "&#93;").replace("/", "&#47;")

    @staticmethod
    def convert_entities_to_tags(text: Optional[str]) -> Optional[str]:
        """HTMLエンティティをタグに戻す

        Args:
            text: 変換対象のテキスト

        Returns:
            Optional[str]: 変換後のテキスト
        """
        if text is None:
            return None
        return text.replace("&#91;", "[").replace("&#93;", "]").replace("&#47;", "/")

    @staticmethod
    def html_tag_recovery(content: str) -> str:
        """HTMLコンテンツ内のタグ記法を正規化する

        Args:
            content: 正規化対象のHTMLコンテンツ

        Returns:
            str: 正規化されたHTMLコンテンツ
        """
        content = re.sub(r"\[tag\s*(\d+)\s*\]", r"[tag\1]", content)
        content = re.sub(r"\[/tag\s*(\d+)\s*\]", r"[/tag\1]", content)
        content = content.replace("[/ tag", "[/tag").replace("[ tag", "[tag")
        content = re.sub(r"\[tag(\d+)\s+(\d+)\]", r"[tag\1\2]", content)
        content = re.sub(r"\[/tag(\d+)\s+(\d+)\]", r"[/tag\1\2]", content)
        content = re.sub(r"\[tag(\d+)］", r"[tag\1]", content)
        content = re.sub(r"\[/tag(\d+)］", r"[/tag\1]", content)
        content = re.sub(r"\[/tag(\d+)]。", r"。[/tag\1]", content)
        return content

    @staticmethod
    def replace_placeholders_with_tags(text: str, tag_info_list: List[Dict]) -> str:
        """テキスト内のプレースホルダーを対応するHTMLタグに置き換える

        Args:
            text: 置換対象のテキスト
            tag_info_list: タグ情報のリスト

        Returns:
            str: 置換後のテキスト
        """
        for tag_info in tag_info_list:
            placeholder = tag_info["placeholder"].replace("tag", "")  # "tag1" -> "1"
            tag_name = tag_info["tag_name"]
            attributes = tag_info.get("attributes", {})

            attr_str = " ".join(
                f'{key}="{value if isinstance(value, str) else " ".join(value)}"'
                for key, value in attributes.items()
            )

            start_tag = (
                f"<{tag_name} {attr_str}>".strip() if attr_str else f"<{tag_name}>"
            )
            end_tag = f"</{tag_name}>"

            placeholder_start = "[tag{}]".format(placeholder)
            placeholder_end = "[/tag{}]".format(placeholder)

            text = text.replace(placeholder_start, start_tag)
            if not tag_info.get("self_close", False):
                text = text.replace(placeholder_end, end_tag)

        return text
