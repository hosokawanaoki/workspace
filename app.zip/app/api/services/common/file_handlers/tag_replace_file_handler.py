from typing import Dict, List

from api.constants.constants import DIRS
from api.services.common.file_path_util.translation_paths import TranslationPaths
from api.utils.file.directory_util import DirectoryUtil
from api.utils.file.file_util import FileUtil
from api.utils.file.file_writer_util import FileWriterUtil


class TagReplaceFileHandler:
    """タグ置換関連のファイル操作を管理するクラス"""

    @staticmethod
    def save_tag_info(book_id: str, tag_info_list: List[Dict]) -> None:
        """タグ情報JSONファイルを保存する

        Args:
            book_id: 書籍ID
            tag_info_list: タグ情報リスト
        """
        # タグ置換ディレクトリの作成
        tag_replace_dir = TranslationPaths.get_tag_replace_dir(book_id)
        DirectoryUtil.ensure_directory(tag_replace_dir)

        # JSONファイルを保存
        json_path = TranslationPaths.get_tag_json_path(book_id)
        FileWriterUtil.save_json_file(json_path, tag_info_list)

    @staticmethod
    def save_processed_html(book_id: str, html_content: str) -> None:
        """処理済みHTMLファイルを保存する

        Args:
            book_id: 書籍ID
            html_content: HTMLコンテンツ
        """
        # タグ置換ディレクトリの作成
        tag_replace_dir = TranslationPaths.get_tag_replace_dir(book_id)
        DirectoryUtil.ensure_directory(tag_replace_dir)

        # HTMLファイルを保存
        html_path = TranslationPaths.get_inside_html_path(book_id, DIRS["TAG_REPLACE"])
        FileWriterUtil.save_file_with_permission(html_path, html_content)

    @staticmethod
    def save_all(book_id: str, html_content: str, tag_info_list: List[Dict]) -> str:
        """すべてのファイルを保存する

        Args:
            book_id: 書籍ID
            html_content: HTMLコンテンツ
            tag_info_list: タグ情報リスト

        Returns:
            str: 保存したHTMLファイルのパス
        """
        # タグ置換ディレクトリの作成
        tag_replace_dir = TranslationPaths.get_tag_replace_dir(book_id)
        DirectoryUtil.ensure_directory(tag_replace_dir)

        # タグ情報JSONファイルを保存
        TagReplaceFileHandler.save_tag_info(book_id, tag_info_list)

        # 処理済みHTMLファイルを保存
        TagReplaceFileHandler.save_processed_html(book_id, html_content)

        # 翻訳ディレクトリの作成と空ファイルの作成
        translated_dir = TranslationPaths.get_translated_dir(book_id)
        DirectoryUtil.ensure_directory(translated_dir)
        translated_path = TranslationPaths.get_translated_html_path(book_id)

        # 翻訳ファイルが存在しない場合のみ空ファイルを作成
        if not FileWriterUtil.check_path_exists(translated_path):
            FileWriterUtil.save_file_with_permission(translated_path, "")

        # HTMLファイルのパスを返す
        return TranslationPaths.get_inside_html_path(book_id, DIRS["TAG_REPLACE"])

    @staticmethod
    def exists(book_id: str) -> bool:
        """タグ置換ファイルが存在するかチェック

        Args:
            book_id: 書籍ID

        Returns:
            bool: すべてのファイルが存在する場合True
        """
        json_path = TranslationPaths.get_tag_json_path(book_id)
        html_path = TranslationPaths.get_inside_html_path(book_id, DIRS["TAG_REPLACE"])
        return FileWriterUtil.check_path_exists(
            json_path
        ) and FileWriterUtil.check_path_exists(html_path)

    @staticmethod
    def delete(book_id: str) -> None:
        """タグ置換ファイルを削除する

        Args:
            book_id: 書籍ID

        Note:
            ファイルが存在しない場合は何もしない
        """
        json_path = TranslationPaths.get_tag_json_path(book_id)
        html_path = TranslationPaths.get_inside_html_path(book_id, DIRS["TAG_REPLACE"])
        FileUtil.remove_file(json_path)
        FileUtil.remove_file(html_path)
