class TranslationError(Exception):
    """翻訳処理に関する基本的な例外クラス"""

    pass


class TranslationServiceError(TranslationError):
    """翻訳サービスに関するエラー"""

    pass


class InvalidTranslationDataError(TranslationError):
    """無効な翻訳データに関するエラー"""

    pass


class TranslationFileError(TranslationError):
    """翻訳ファイルの処理に関するエラー"""

    pass


class TranslationLimitExceededError(TranslationError):
    """翻訳の制限超過に関するエラー"""

    pass


class AfterTranslateError(TranslationError):
    """翻訳後の処理に関するエラー"""

    pass
