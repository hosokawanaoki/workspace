# プロジェクトインフラ構成

## コンテナ構成

| サービス名 | 説明 | ポート |
|------------|------|--------|
| backend | Djangoアプリケーション | 8000 |
| frontend | Reactアプリケーション | 3000 |
| db | PostgreSQLデータベース | 5432 |
| pgadmin | PostgreSQL管理ツール | 5050 |

## 環境構築

### 必要条件
- Docker 20.10以上
- Docker Compose 2.0以上

### 環境変数設定
`.env`ファイルを作成し、以下の環境変数を設定：

```bash
ANTHROPIC_API_KEY
DEEPSEEK_API_KEY
```

## コンテナ操作

### 開発環境起動
```bash
docker-compose -f docker-compose.yml -f docker-compose.dev.yml up -d
```

### 本番環境起動
```bash
docker-compose -f docker-compose.yml -f docker-compose.prod.yml up -d
```

### コンテナ停止
```bash
docker-compose down
```

### ログ確認
```bash
# バックエンドログ
docker-compose logs -f backend

# フロントエンドログ  
docker-compose logs -f frontend
```

### データベース操作
```bash
# マイグレーション実行
docker-compose exec backend python manage.py migrate

# シェル起動
docker-compose exec backend python manage.py shell

# バッチ実行例
docker-compose exec backend python manage.py your_command
```
### 開発環境起動
```bash
docker-compose exec backend uv run python app/manage.py runserver 0.0.0.0:8000
```
## スクリプト使用方法

### run.sh 主要コマンド

```bash
# 開発環境起動 & サーバー実行
./run.sh dev

# コンテナ停止
./run.sh down

# ログ表示
./run.sh logs

# 開発サーバーリロード
./run.sh reload

# 本番環境起動
./run.sh
```

開発サーバーを停止するにはCtrl+Cを押してください。

## トラブルシューティング

### コンテナ再構築
```bash
docker-compose down
docker-compose build --no-cache
docker-compose up -d
```

### ボリューム削除
```bash
docker-compose down -v
```

### ネットワーク確認
```bash
docker network inspect your_project_name_default
```

## 各サービスREADME
- バックエンド: [backend/README.md](backend/README.md)
- フロントエンド: [frontend/README.md](frontend/README.md)
