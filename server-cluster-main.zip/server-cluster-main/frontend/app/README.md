# React + TypeScript + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

## 書籍の状態遷移とボタン表示

書籍は以下の状態を持ち、翻訳処理の進行に応じて遷移します。各状態で表示されるボタンと、そのボタンを押した時の遷移先が異なります：

| 状態 | 説明 | ボタンと遷移先 |
|------|------|----------------|
| `raw` | 翻訳前の初期状態 | ・編集<br>・翻訳 → waiting |
| `waiting` | 翻訳待ち（翻訳バッチ作成時） | ・キャンセル → error |
| `ai-execution` | AI翻訳実行中（翻訳処理開始時） | ・キャンセル → error |
| `translating` | 翻訳途中（一部翻訳完了時） | ・編集<br>・翻訳 → ai-execution<br>・削除 |
| `translated` | 翻訳済み（全文翻訳完了かつタグ修復成功時） | ・編集<br>・本生成 → complete<br>・削除 |
| `tag-error` | タグエラーあり（翻訳完了後のタグ修復失敗時） | ・編集<br>・タグ修復 → translated<br>・削除 |
| `error` | その他エラー（処理中の予期せぬエラー発生時） | ・編集<br>・翻訳 → ai-execution |
| `complete` | 完了（最終確認完了時） | なし |
| `notfound` | ファイルが存在しない（ファイル不在時） | なし |
| `force-stopped` | 強制停止状態 | ・編集 |

特記事項：
- AI翻訳中（ai-execution）と待機中（waiting）は編集不可
- 30分以上更新がない場合は自動的にerror状態に遷移
- translating状態での翻訳は未翻訳部分から再開
- 予期せぬエラーが発生した場合は自動的にerror状態に遷移
- 削除ボタンは該当データの完全削除を行う

## コメント規約

APIサービス層のコードには以下の形式でJSDocコメントを記載します：

```typescript
/**
 * メソッドの目的を簡潔に説明
 * @param {型} パラメータ名 - パラメータの説明
 * @returns {型} 返り値の説明
 * @throws {Error} 発生する可能性のあるエラーの説明
 */
```

### 例

```typescript
/**
 * 指定されたIDの書籍データを取得する
 * @param {number} id - 書籍ID
 * @returns {Promise<Book>} 書籍データ
 * @throws {Error} APIエラーが発生した場合
 */
async getBook(id: number): Promise<Book> {
  // 実装
}
```

## Expanding the ESLint configuration

If you are developing a production application, we recommend updating the configuration to enable type aware lint rules:

- Configure the top-level `parserOptions` property like this:

```js
export default tseslint.config({
  languageOptions: {
    // other options...
    parserOptions: {
      project: ['./tsconfig.node.json', './tsconfig.app.json'],
      tsconfigRootDir: import.meta.dirname,
    },
  },
})
```

- Replace `tseslint.configs.recommended` to `tseslint.configs.recommendedTypeChecked` or `tseslint.configs.strictTypeChecked`
- Optionally add `...tseslint.configs.stylisticTypeChecked`
- Install [eslint-plugin-react](https://github.com/jsx-eslint/eslint-plugin-react) and update the config:

```js
// eslint.config.js
import react from 'eslint-plugin-react'

export default tseslint.config({
  // Set the react version
  settings: { react: { version: '18.3' } },
  plugins: {
    // Add the react plugin
    react,
  },
  rules: {
    // other rules...
    // Enable its recommended rules
    ...react.configs.recommended.rules,
    ...react.configs['jsx-runtime'].rules,
  },
})
