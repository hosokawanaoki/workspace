/**
 * 書籍IDのバリデーション
 */
export const validateBookId = (id: string): boolean => {
  // prefix_model_language_id の形式をチェック
  return /^[a-z]+_[a-z0-9-]+_[a-z]{2}_\d+$/.test(id);
};

/**
 * モデル名のバリデーション
 */
export const validateModel = (model: string | undefined): string => {
  if (!model) {
    throw new Error('モデルは必須パラメータです');
  }
  return model;
};
