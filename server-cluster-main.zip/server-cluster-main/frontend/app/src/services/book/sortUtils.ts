import { SortConfig } from '@/types/Book';

/**
 * ソート方向を切り替え
 */
export const toggleSortDirection = <T>(
  currentKey: keyof T,
  newKey: keyof T,
  currentDirection: 'asc' | 'desc'
): 'asc' | 'desc' => {
  return currentKey === newKey && currentDirection === 'asc' ? 'desc' : 'asc';
};

/**
 * 汎用的なソート関数
 */
export const sortItems = <T>(
  items: T[],
  config: SortConfig<T>
): T[] => {
  return [...items].sort((a, b) => {
    const aValue = a[config.key] ?? '';
    const bValue = b[config.key] ?? '';

    // 値が数値型の場合は数値として比較
    if (typeof aValue === 'number' && typeof bValue === 'number') {
      return config.direction === 'asc' ? aValue - bValue : bValue - aValue;
    }

    // その他の場合は文字列として比較
    if (String(aValue) < String(bValue)) {
      return config.direction === 'asc' ? -1 : 1;
    }
    if (String(aValue) > String(bValue)) {
      return config.direction === 'asc' ? 1 : -1;
    }
    return 0;
  });
};
