import { BookStatus } from '@/types/Book';

/**
 * 編集ボタンを表示すべきかどうかを判定
 */
export const shouldShowEditButton = (status: BookStatus): boolean => {
  return status !== BookStatus.Complete &&
    status !== BookStatus.NotFound &&
    status !== BookStatus.AiExecution;
};

/**
 * ステータスに基づいて利用可能なアクションを判定
 */
export const getAvailableActions = (status: BookStatus): {
  canTranslate: boolean;
  canCancel: boolean;
  canGenerate: boolean;
  canRepair: boolean;
  canDelete: boolean;
} => {
  if (status === BookStatus.ForceStopped) {
    return {
      canTranslate: false,
      canCancel: false,
      canGenerate: false,
      canRepair: false,
      canDelete: true
    };
  }

  return {
    // 修正後：配列を使用して可読性を上げ、適切な状態のみを許可
    canTranslate: [
      BookStatus.Raw,
      BookStatus.Error,
      BookStatus.Translating,
      BookStatus.Cancel
    ].includes(status),
    canCancel: [
      BookStatus.Waiting,
      BookStatus.AiExecution
    ].includes(status),
    canGenerate: status === BookStatus.Translated,
    canRepair: status === BookStatus.TagError,
    canDelete: status !== BookStatus.AiExecution,
  };
};
/**
 * デフォルトのAIモデル名を取得
 */
export const getDefaultModel = (): string => {
  return "claude-3-haiku-20240307";
};
