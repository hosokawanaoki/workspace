export interface TranslationExample {
  before: string;
  after: string;
}

export interface TranslationSetting {
  id?: number;
  pattern_id?: number;
  name: string;
  constraints: string | null;
  examples: TranslationExample[] | null;
}
