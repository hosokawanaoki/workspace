export interface LatestBatch {
  batch_time: string;
  status: string;
  model: string;
  translation_setting?: {
    id: number;
    name: string;
  };
  limit: number;
  status_message?: string;
  force_stop: boolean;
}

export interface TranslationVersion {
  version: number;
  description?: string;
  status: string;
}

export interface Book {
  id: number;
  book_id: string;
  provider?: string;
  original_id?: string;
  title_jp: string;
  title: string;
  author: string;
  language: string;
  downloads: number;
  copyright_status: string;
  subject: string;
  summary: string;
  status: BookStatus;
  model?: string;
  latest_batch?: LatestBatch;
  current_version?: TranslationVersion;
  version_history?: TranslationVersion[];
}

export enum BookStatus {
  Raw = 'raw',
  Waiting = 'waiting',
  AiExecution = 'ai-execution',
  Translating = 'translating',
  Translated = 'translated',
  TagError = 'tag-error',
  Error = 'error',
  Complete = 'complete',
  NotFound = 'notfound',
  ForceStopped = 'force-stopped',
  Cancel = 'cancel'
}

export const BookStatusLabels: Record<BookStatus, string> = {
  [BookStatus.ForceStopped]: '⛔ 強制停止',
  [BookStatus.Raw]: '⚪ 翻訳前',     
  [BookStatus.Waiting]: '🟡 待機中',   
  [BookStatus.AiExecution]: '🤖 AI実行中',
  [BookStatus.Translating]: '🔵 翻訳中', 
  [BookStatus.Translated]: '🟢 翻訳済',
  [BookStatus.TagError]: '🔴 タグエラーあり',
  [BookStatus.Error]: '⚠️ エラーあり',  
  [BookStatus.Complete]: '🎉 完了',  
  [BookStatus.NotFound]: '❌ ファイルが存在しない',
  [BookStatus.Cancel]: '🚫 キャンセル'
};

export interface TranslateResponse {
  code?: string;
  not_found?: string[];
  message?: string;
}

export type SortConfig<T> = {
  key: keyof T;
  direction: 'asc' | 'desc';
};

export interface book_TranslateRequest {
  original_id: string;
  provider_id: string;  // 例: "gutenberg"
  translation_setting_id: number;
  model: string;
  limit?: number;
  start?: number;
}
