import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import './App.css'
import Home from '@/pages/Home';
import About from '@/pages/About';
import { Navbar, Nav } from 'react-bootstrap';
import Edit from '@/pages/Edit';
import AddLlm from '@/pages/AddLlm';
import AddVersion from '@/pages/AddVersion';
import TranslationSettings from '@/pages/TranslationSettings';

function App() {
  return (
    <Router>
      <Navbar bg="light" expand="lg">
        <Navbar.Brand as={Link} to="/">翻訳しよう会</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mr-auto">
            <Nav.Link as={Link} to="/">ホーム</Nav.Link>
            <Nav.Link as={Link} to="/about">分析</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Navbar>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/edit/:id" element={<Edit />} />
        <Route path="/addLlm" element={<AddLlm />} />
        <Route path="/translation-settings" element={<TranslationSettings />} />
        <Route path="/books/:id/versions/new" element={<AddVersion />} />
      </Routes>
    </Router>
  );
}


export default App
