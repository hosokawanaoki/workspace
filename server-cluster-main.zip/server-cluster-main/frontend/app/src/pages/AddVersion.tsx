import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useForm, SubmitHandler } from 'react-hook-form';
import { Form, Button, Container, Row, Col, Spinner } from 'react-bootstrap';
import { ApiError } from '@/api/errorHandler';
import { bookService } from '@/api/services/bookService';
import { getLlmModels } from '@/constants/llmModels';
import type { LlmModel } from '@/constants/llmModels';

type FormValues = {
  version_name: string;
  correction_instruction: string;
  model: string;
};

const AddVersion: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initialModel = searchParams.get('model') || '';
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue
  } = useForm<FormValues>();
  const [isLoading, setIsLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  const [models, setModels] = useState<LlmModel[]>([]);

  // モデル一覧の取得
  useEffect(() => {
    const fetchModels = async () => {
      const modelList = await getLlmModels();
      setModels(modelList);
    };
    fetchModels();
  }, []);

  // モデルの初期値設定
  useEffect(() => {
    if (initialModel && models.length > 0) {
      setValue('model', initialModel);
    }
  }, [initialModel, models, setValue]);

  const onSubmit: SubmitHandler<FormValues> = async (data) => {
    if (!id) return;
    
    setIsLoading(true);
    try {
      const result = await bookService.createVersion(id, {
        version_name: data.version_name,
        correction_instruction: data.correction_instruction,
        model: data.model,
      });

      setSuccessMessage('新しいバージョンを作成しました');
    } catch (error) {
      if (error instanceof ApiError) {
        alert(`エラーが発生しました: ${error.message}`);
      } else {
        alert('予期せぬエラーが発生しました');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Container>
      <Row className="justify-content-md-center">
        <Col md="6">
          <h2>新規バージョン作成</h2>
          {isLoading ? (
            <div className="text-center">
              <Spinner animation="border" role="status">
                <span className="visually-hidden">Loading...</span>
              </Spinner>
            </div>
          ) : (
            <>
              {successMessage && (
                <div className="mt-3 p-3 bg-success text-white rounded">
                  {successMessage}
                </div>
              )}
              <Form onSubmit={handleSubmit(onSubmit)}>
                <Form.Group controlId="formVersionName" className="mb-3">
                  <Form.Label>バージョン名</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="バージョン名を入力してください"
                    {...register('version_name', {
                      required: 'バージョン名は必須項目です'
                    })}
                    isInvalid={!!errors.version_name}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.version_name?.message}
                  </Form.Control.Feedback>
                </Form.Group>

                <Form.Group controlId="formModel" className="mb-3">
                  <Form.Label>モデル</Form.Label>
                  <Form.Select
                    {...register('model', {
                      required: 'モデルは必須項目です'
                    })}
                    isInvalid={!!errors.model}
                  >
                    <option value="">モデルを選択してください</option>
                    {models.map((model) => (
                      <option key={model.value} value={model.value}>
                        {model.label}
                      </option>
                    ))}
                  </Form.Select>
                  <Form.Control.Feedback type="invalid">
                    {errors.model?.message}
                  </Form.Control.Feedback>
                </Form.Group>

                <Form.Group controlId="formCorrectionInstruction" className="mb-3">
                  <Form.Label>校正指示</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={5}
                    placeholder="校正指示を入力してください"
                    {...register('correction_instruction', {
                      required: '校正指示は必須項目です'
                    })}
                    isInvalid={!!errors.correction_instruction}
                  />
                  <Form.Text className="text-muted">
                    例：「より自然な日本語になるように修正してください」「文体を統一してください」など
                  </Form.Text>
                  <Form.Control.Feedback type="invalid">
                    {errors.correction_instruction?.message}
                  </Form.Control.Feedback>
                </Form.Group>

                <div className="d-flex justify-content-center gap-2">
                  <Button variant="primary" type="submit" className="mt-3">
                    バッチ処理登録
                  </Button>
                  <Button 
                    variant="secondary" 
                    className="mt-3"
                    onClick={() => navigate(`/edit/${id}`)}
                  >
                    キャンセル
                  </Button>
                </div>
              </Form>
            </>
          )}
        </Col>
      </Row>
    </Container>
  );
};

export default AddVersion;
