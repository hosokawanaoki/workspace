import React from 'react';
import FileUploadForm from '../components/Analysis/FileUploadForm';
import SampleChart from '../components/Analysis/SampleChart';

const About: React.FC = () => {
  return (
    <div className="about-container">
      <h1>分析</h1>
      <div className="content-wrapper">
        <FileUploadForm />
        <SampleChart />
      </div>
      <style>{`
        .about-container {
          padding: 20px;
          max-width: 1200px;
          margin: 0 auto;
        }
        .content-wrapper {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }
        h1 {
          margin-bottom: 20px;
          color: #333;
        }
      `}</style>
    </div>
  );
};

export default About;
