import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { Tab, Tabs, Container } from 'react-bootstrap';
import { bookService } from '../api/services/bookService';

import EditTab from '../components/Edit/EditTab';
import TranslationHistoryTab from '../components/Edit/TranslationHistoryTab';
import InfoTab from '../components/Edit/InfoTab';

const EditPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const initialTab = searchParams.get('tab') || 'edit';
  const [activeTab, setActiveTab] = useState(initialTab);

  if (!id) {
    return (
      <Container className="py-4">
        <div className="alert alert-danger">
          IDが指定されていません
        </div>
      </Container>
    );
  }

  return (
    <Container className="py-4">
      <div className="bg-white rounded shadow-sm p-4">
        <h2 className="mb-4 text-primary">書籍管理</h2>
        
        <Tabs
          activeKey={activeTab}
          onSelect={(k) => k && setActiveTab(k)}
          className="mb-4"
          fill
        >
          <Tab 
            eventKey="edit" 
            title="編集"
            tabClassName="fw-bold text-primary"
          >
            <EditTab id={id} />
          </Tab>
          <Tab 
            eventKey="history" 
            title="再翻訳"
            tabClassName="fw-bold text-primary"
          >
            <TranslationHistoryTab id={id} />
          </Tab>
          <Tab 
            eventKey="info" 
            title="タグ"
            tabClassName="fw-bold text-primary"
          >
            <InfoTab id={id} />
          </Tab>
        </Tabs>
      </div>

      <style>
        {`
          .nav-tabs .nav-link {
            color: #6c757d;
            border: none;
            padding: 1rem 2rem;
            transition: all 0.2s;
          }
          .nav-tabs .nav-link:hover {
            color: #0d6efd;
            background-color: #f8f9fa;
            border: none;
          }
          .nav-tabs .nav-link.active {
            color: #0d6efd;
            background-color: #fff;
            border: none;
            border-bottom: 3px solid #0d6efd;
          }
          .tab-content {
            background-color: #fff;
            border-radius: 0 0 0.5rem 0.5rem;
          }
        `}
      </style>
    </Container>
  );
};

export default EditPage;
