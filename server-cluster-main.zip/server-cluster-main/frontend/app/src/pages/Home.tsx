import React, { useEffect, useState, Dispatch, SetStateAction } from 'react';
import { useNavigate } from 'react-router-dom';
import { Container } from 'react-bootstrap';
import { Book, BookStatus } from '@/types/Book';
import { useBooks } from '@/hooks/useBooks';
import { bookService } from '@/api';
import HeaderActions from '@/components/Book/HeaderActions';
import BookList from '@/components/Book/BookList';
import WarningModal from '@/components/WarningModal/WarningModal';

const Home: React.FC = () => {
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState<boolean>(false);
  const [notFoundItems, setNotFoundItems] = useState<string[]>([]);
  
  const {
    loading,
    error,
    sortConfig,
    sortedBooks,
    handleSort,
    fetchBooks,
    translateLLM,
    books,
    setBooks
  } = useBooks();

  useEffect(() => {
    fetchBooks();
    
    const interval = setInterval(async () => {
      try {
        const newBooks = await bookService.getBooks();
        setBooks((prevBooks: Book[]) => {
          // 変更のある書籍のみを更新
          return prevBooks.map((prevBook: Book) => {
            const newBook = newBooks.find(book => book.id === prevBook.id);
            if (!newBook) return prevBook;
            
            // ステータスまたはlatest_batchの内容が変更された場合に更新
            const hasStatusChanged = newBook.status !== prevBook.status;
            const hasLatestBatchChanged = JSON.stringify(newBook.latest_batch) !== JSON.stringify(prevBook.latest_batch);
            
            return hasStatusChanged || hasLatestBatchChanged ? newBook : prevBook;
          });
        });
      } catch (error) {
        console.error('定期更新中にエラーが発生しました:', error);
      }
    }, 20000); // 20秒ごとに更新

    return () => clearInterval(interval);
  }, []);

  const handleAddLlmClick = () => {
    navigate('/addLlm');
  };

  const handleTranslationSettingsClick = () => {
    navigate('/translation-settings');
  };

  const handleEditClick = (id: string) => {
    navigate(`/edit/${id}`);
  };

  const handleDeleteClick = async (bookId: string) => {
    try {
      await bookService.deleteBook(bookId);
      alert('書籍を削除しました');
      fetchBooks();
    } catch (err) {
      alert('削除中にエラーが発生しました');
    }
  };

  const handleActionClick = async (id: string, status: BookStatus) => {
    try {
      let response;
      
      switch (status) {
        case BookStatus.Waiting:
        case BookStatus.AiExecution:
        case BookStatus.Translating:
          response = await bookService.cancelTranslation(id);
          alert('翻訳をキャンセルしました');
          break;
          
        case BookStatus.Translated:
          response = await bookService.translateRepairBook(id);
          if (response.code === 'file_empty') {
            alert('ファイルが空なので処理を終了しました');
            return;
          }
          if (Array.isArray(response.not_found) && response.not_found.length > 0) {
            setNotFoundItems(response.not_found);
            setShowModal(true);
          } else {
            alert(`書籍ID: ${id} の翻訳データを基にEPUBを作成しました。`);
          }
          break;
          
        case BookStatus.TagError:
          response = await bookService.repairTags(id);
          navigate(`/edit/${id}?tab=info`);
          break;
          
        default:
          break;
      }
      
      // 状態が変更された可能性があるので、書籍一覧を更新
      fetchBooks();
    } catch (err) {
      alert('処理中にエラーが発生しました');
    }
  };

  const handleCloseModal = () => setShowModal(false);

  return (
    <Container fluid className="mt-2 bg-app-secondary px-4 shadow-sm">
      <WarningModal show={showModal} handleClose={handleCloseModal} notFoundItems={notFoundItems} />
      <HeaderActions
        error={error || undefined}
        onAddLlmClick={handleAddLlmClick}
        onTranslationSettingsClick={handleTranslationSettingsClick}
      />
      <BookList
        loading={loading}
        sortedBooks={sortedBooks}
        sortConfig={sortConfig}
        handleSort={handleSort}
        handleEditClick={handleEditClick}
        handleActionClick={handleActionClick}
        translateLLM={translateLLM}
        handleDeleteClick={handleDeleteClick}
      />
    </Container>
  );
};

export default Home;
