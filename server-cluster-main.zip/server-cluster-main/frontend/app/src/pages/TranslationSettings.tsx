import React, { useState, useEffect } from 'react';
import { Form, Button, Container, Row, Col, Table } from 'react-bootstrap';
import { translationSettingService } from '@/api/services/translationSettingService';
import { TranslationSetting, TranslationExample } from '@/types/TranslationSetting';

const TranslationSettings: React.FC = () => {
  const [settings, setSettings] = useState<TranslationSetting[]>([]);
  const [editingSetting, setEditingSetting] = useState<TranslationSetting | null>(null);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const data = await translationSettingService.getTranslationSettings();
      setSettings(data);
    } catch (error) {
      console.error('翻訳設定の取得に失敗しました:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSetting) return;

    try {
      console.log('送信前のデータ:', editingSetting);

      const settingData = {
        ...editingSetting,
        examples: editingSetting.examples?.filter(example => example.before.trim() && example.after.trim()) || []
      };

      console.log('送信するデータ:', settingData);

      if (editingSetting.id) {
        await translationSettingService.updateTranslationSetting({
          ...settingData,
          id: editingSetting.id
        });
      } else {
        await translationSettingService.createTranslationSetting(settingData);
      }
      await loadSettings();
      setEditingSetting(null);
    } catch (error) {
      console.error('翻訳設定の保存に失敗しました:', error);
    }
  };

  return (
    <Container>
      <Row className="mb-4">
        <Col>
          <h2>翻訳設定管理</h2>
          <Button 
            variant="primary" 
            onClick={() => setEditingSetting({ 
              name: '', 
              constraints: '', 
              examples: [
                { before: '', after: '' },
                { before: '', after: '' },
                { before: '', after: '' }
              ] 
            })}
            className="mb-3"
          >
            新規作成
          </Button>
        </Col>
      </Row>

      {editingSetting ? (
        <Row>
          <Col>
            <Form onSubmit={handleSubmit}>
              <Form.Group className="mb-3">
                <Form.Label className="w-100 text-center">名前</Form.Label>
                <Form.Control
                  type="text"
                  value={editingSetting.name}
                  onChange={(e) => setEditingSetting({
                    ...editingSetting,
                    name: e.target.value
                  })}
                  required
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label className="w-100 text-center">制約事項</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={3}
                  value={editingSetting.constraints || ''}
                  onChange={(e) => setEditingSetting({
                    ...editingSetting,
                    constraints: e.target.value
                  })}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label className="w-100 text-center">翻訳例</Form.Label>
                {[0, 1, 2].map((index) => (
                  <div key={index} className="mb-3 p-3 border rounded">
                    <Form.Group className="mb-2">
                      <Form.Label>翻訳前</Form.Label>
                      <Form.Control
                        as="textarea"
                        value={editingSetting.examples?.[index]?.before || ''}
                        onChange={(e) => {
                          const newExamples = [...(editingSetting.examples || [])];
                          while (newExamples.length <= index) {
                            newExamples.push({ before: '', after: '' });
                          }
                          newExamples[index] = { ...newExamples[index], before: e.target.value };
                          setEditingSetting({
                            ...editingSetting,
                            examples: newExamples
                          });
                        }}
                      />
                    </Form.Group>
                    <Form.Group className="mb-2">
                      <Form.Label>翻訳後</Form.Label>
                      <Form.Control
                        as="textarea"
                        value={editingSetting.examples?.[index]?.after || ''}
                        onChange={(e) => {
                          const newExamples = [...(editingSetting.examples || [])];
                          while (newExamples.length <= index) {
                            newExamples.push({ before: '', after: '' });
                          }
                          newExamples[index] = { ...newExamples[index], after: e.target.value };
                          setEditingSetting({
                            ...editingSetting,
                            examples: newExamples
                          });
                        }}
                      />
                    </Form.Group>
                  </div>
                ))}
              </Form.Group>

              <div className="d-flex gap-2">
                <Button variant="primary" type="submit">
                  保存
                </Button>
                <Button variant="secondary" onClick={() => setEditingSetting(null)}>
                  キャンセル
                </Button>
              </div>
            </Form>
          </Col>
        </Row>
      ) : (
        <Row>
          <Col>
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>名前</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {settings.map((setting) => (
                  <tr key={setting.id}>
                    <td>{setting.id}</td>
                    <td>{setting.name}</td>
                    <td>
                      <div className="d-flex gap-2">
                        <Button
                          variant="primary"
                          size="sm"
                          onClick={() => {
                            const examples = [...(setting.examples || [])];
                            while (examples.length < 3) {
                              examples.push({ before: '', after: '' });
                            }
                            setEditingSetting({
                              ...setting,
                              examples
                            });
                          }}
                        >
                          編集
                        </Button>
                        <Button
                          variant="danger"
                          size="sm"
                          onClick={async () => {
                            if (window.confirm('この翻訳設定を削除してもよろしいですか？')) {
                              try {
                                await translationSettingService.deleteTranslationSetting(setting.id!);
                                await loadSettings();
                              } catch (error) {
                                console.error('翻訳設定の削除に失敗しました:', error);
                                alert('削除中にエラーが発生しました');
                              }
                            }
                          }}
                        >
                          削除
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Col>
        </Row>
      )}
    </Container>
  );
};

export default TranslationSettings;
