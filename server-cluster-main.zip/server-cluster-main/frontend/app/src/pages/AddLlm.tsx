import React, { useState, useEffect } from 'react';
import { llmService } from '@/api/services/llm';
import { LlmModel } from '@/constants/llmModels';
import { useLocation, useNavigate } from 'react-router-dom';
import { useForm, SubmitHandler } from 'react-hook-form';
import { Form, Button, Container, Row, Col, Spinner } from 'react-bootstrap';
import { ApiError } from '@/api/errorHandler';
import { bookService } from '@/api/services/bookService';
import { translationSettingService } from '@/api/services/translationSettingService';
import { TranslationSetting } from '@/types/TranslationSetting';

type FormValues = {
  original_id: string;
  translation_setting_id: number;
  model: string; // AIモデル
  executionType: number; // 実行件数（limitとして使用）
};

const AddLlm: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const {
    model,
    translation_setting_id,
    limit,
    original_id,
    status,
  } = location.state || {};

  const isTranslating = status === 'translating';
  const [isLoading, setIsLoading] = useState(true);
  const [llmModels, setLlmModels] = useState<LlmModel[]>([]);
  const [translationSettings, setTranslationSettings] = useState<TranslationSetting[]>([]);
  const [selectedSetting, setSelectedSetting] = useState<TranslationSetting | null>(null);
  const [successMessage, setSuccessMessage] = useState('');

  // LLMモデル一覧と翻訳設定の取得
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [models, settings] = await Promise.all([
          llmService.getModels(),
          translationSettingService.getTranslationSettings()
        ]);
        setLlmModels(models);
        setTranslationSettings(settings);
      } catch (error) {
        console.error('データの取得に失敗しました:', error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    reset,
    formState: { errors },
  } = useForm<FormValues>();

  // フォームの初期化
  useEffect(() => {
    if (!isLoading && translationSettings.length > 0) {
      reset({
        model,
        translation_setting_id: translation_setting_id ? Number(translation_setting_id) : undefined,
        executionType: limit,
        original_id: original_id
      });
    }
  }, [isLoading, translationSettings, model, translation_setting_id, limit, original_id, reset]);

  const watchedTranslationSettingId = watch('translation_setting_id');
  const watchedModel = watch('model');

  // 選択された翻訳設定の更新
  useEffect(() => {
    const setting = translationSettings.find(s => s.id === watchedTranslationSettingId);
    setSelectedSetting(setting || null);
  }, [watchedTranslationSettingId, translationSettings]);

  const onSubmit: SubmitHandler<FormValues> = async (data) => {
    setIsLoading(true);
    try {
      const result = await bookService.translate({
        original_id: data.original_id,
        provider_id: 'gutenberg',  // 追加
        translation_setting_id: data.translation_setting_id,
        model: data.model,
        limit: data.executionType
      });

      setSuccessMessage(`ID: ${data.original_id} をバッチ処理に追加しました\n`);
    } catch (error) {
      if (error instanceof ApiError) {
        alert(`エラーが発生しました: ${error.message}`);
      } else {
        alert('予期せぬエラーが発生しました');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Container>
      <Row className="justify-content-md-center">
        <Col md="6">
          <h2>AI翻訳</h2>
          {isLoading ? (
            // ローディング時の表示
            <div className="text-center">
              <Spinner animation="border" role="status">
                <span className="visually-hidden">Loading...</span>
              </Spinner>
            </div>
          ) : (
            // フォームと事例表示用ブロックを一緒に返すために <>
            <>
              {successMessage && (
                <div className="mt-3 p-3 bg-success text-white rounded">
                  <pre style={{ whiteSpace: 'pre-wrap' }}>{successMessage}</pre>
                </div>
              )}
              <Form onSubmit={handleSubmit(onSubmit)}>
                <Form.Group controlId="formOriginalId" className="mb-3">
                  <Form.Label className="w-100 text-center">Original ID</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Original IDを入力してください"
                    {...register('original_id', {
                      required: 'Original IDは必須項目です'
                    })}
                    isInvalid={!!errors.original_id}
                    disabled={isTranslating}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.original_id?.message}
                  </Form.Control.Feedback>
                </Form.Group>

                <Form.Group controlId="formModel" className="mb-3">
                  <Form.Label className="w-100 text-center">AIモデル</Form.Label>
                  <Form.Control
                    as="select"
                    {...register('model', { required: 'AIモデルは必須項目です' })}
                    isInvalid={!!errors.model}
                    disabled={isTranslating}
                    value={watchedModel || ''}
                  >
                    <option value="">選択してください</option>
                    {llmModels.map((model) => (
                      <option key={model.value} value={model.value}>
                        {model.label}
                      </option>
                    ))}
                  </Form.Control>
                  <Form.Control.Feedback type="invalid">
                    {errors.model?.message}
                  </Form.Control.Feedback>
                </Form.Group>

                <Form.Group controlId="formTranslationSetting" className="mb-3">
                  <Form.Label className="w-100 text-center">翻訳設定</Form.Label>
                  <Form.Control
                    as="select"
                    {...register('translation_setting_id', {
                      required: '翻訳設定は必須項目です',
                      valueAsNumber: true
                    })}
                    isInvalid={!!errors.translation_setting_id}
                    disabled={isTranslating}
                  >
                    <option value="">選択してください</option>
                    {translationSettings.map((setting) => (
                      <option
                        key={setting.id}
                        value={setting.id}
                      >
                        {setting.name}
                      </option>
                    ))}
                  </Form.Control>
                  <Form.Control.Feedback type="invalid">
                    {errors.translation_setting_id?.message}
                  </Form.Control.Feedback>
                </Form.Group>

                {/* 翻訳設定の詳細表示 */}
                {selectedSetting && (
                  <div className="mt-4 p-3 bg-light rounded text-start">
                    {selectedSetting.constraints && (
                      <div>
                        <Form.Label className="w-100 text-center">制約事項</Form.Label>
                        <pre style={{ whiteSpace: 'pre-wrap' }} className="mb-0">{selectedSetting.constraints}</pre>
                      </div>
                    )}
                    {selectedSetting.examples && selectedSetting.examples.length > 0 && (
                      <div className="mt-4">
                        <Form.Label className="w-100 text-center">翻訳例</Form.Label>
                        {selectedSetting.examples.map((example, index) => (
                          <div key={index} className="mb-3">
                            <p><strong>翻訳前:</strong></p>
                            <pre style={{ whiteSpace: 'pre-wrap' }}>{example.before}</pre>
                            <p><strong>翻訳後:</strong></p>
                            <pre style={{ whiteSpace: 'pre-wrap' }}>{example.after}</pre>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
                <Form.Group controlId="formExecutionType" className="mb-3">
                  <Form.Label className="w-100 text-center">実行件数</Form.Label>
                  <Form.Control
                    as="select"
                    {...register('executionType', {
                      required: '実行件数は必須項目です',
                      valueAsNumber: true
                    })}
                    isInvalid={!!errors.executionType}
                  >
                    <option value="">選択してください</option>
                    <option value="2">2件</option>
                    <option value="10">10件</option>
                    <option value="30">30件</option>
                    <option value="50">50件</option>
                    <option value="10000">全件</option>
                  </Form.Control>
                  <Form.Control.Feedback type="invalid">
                    {errors.executionType?.message}
                  </Form.Control.Feedback>
                </Form.Group>

                <div className="d-flex justify-content-center gap-2">
                  <Button variant="primary" type="submit" className="mt-3">
                    AI翻訳
                  </Button>
                  <Button
                    variant="secondary"
                    className="mt-3"
                    onClick={() => navigate('/translation-settings')}
                  >
                    翻訳設定
                  </Button>
                </div>
              </Form>
            </>
          )}
        </Col>
      </Row>
    </Container>
  );
};

export default AddLlm;
