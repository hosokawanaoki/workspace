import axios from 'axios';

const VITE_APP_BASE_API_URL = import.meta.env.VITE_APP_BASE_API_URL;

if (!VITE_APP_BASE_API_URL) {
  throw new Error('VITE_APP_BASE_API_URL is not defined');
}

const apiClient = axios.create({
  baseURL: VITE_APP_BASE_API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// レスポンスインターセプター
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('APIエラー:', {
      message: error.message,
      response: error.response?.data,
      config: error.config,
    });
    return Promise.reject(error);
  }
);

export default apiClient;
