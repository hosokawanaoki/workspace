import { TranslationSetting } from '@/types/TranslationSetting';
import { API_ENDPOINTS } from '@/api/endpoints';
import apiClient from '@/api/apiClient';
import { handleApiError } from '@/api/errorHandler';

export abstract class TranslationSettingService {
  /**
   * 全ての翻訳設定を取得する
   * @returns {Promise<TranslationSetting[]>} 翻訳設定の配列
   * @throws {Error} APIエラーが発生した場合
   */
  async getTranslationSettings(): Promise<TranslationSetting[]> {
    try {
      const response = await apiClient.get(API_ENDPOINTS.TRANSLATION_SETTINGS.LIST);
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 翻訳設定を作成する
   * @param {Omit<TranslationSetting, 'id'>} data - 作成する翻訳設定データ
   * @returns {Promise<TranslationSetting>} 作成された翻訳設定
   * @throws {Error} APIエラーが発生した場合
   */
  async createTranslationSetting(data: Omit<TranslationSetting, 'id'>): Promise<TranslationSetting> {
    try {
      const response = await apiClient.post(API_ENDPOINTS.TRANSLATION_SETTINGS.CREATE, data);
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 翻訳設定を更新する
   * @param {TranslationSetting} data - 更新する翻訳設定データ
   * @returns {Promise<TranslationSetting>} 更新された翻訳設定
   * @throws {Error} APIエラーが発生した場合
   */
  async updateTranslationSetting(data: TranslationSetting & { id: number }): Promise<TranslationSetting> {
    try {
      const response = await apiClient.put(API_ENDPOINTS.TRANSLATION_SETTINGS.UPDATE(data.id), data);
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 翻訳設定を削除する
   * @param {number} id - 削除する翻訳設定のID
   * @returns {Promise<void>}
   * @throws {Error} APIエラーが発生した場合
   */
  async deleteTranslationSetting(id: number): Promise<void> {
    try {
      await apiClient.delete(API_ENDPOINTS.TRANSLATION_SETTINGS.DELETE(id));
    } catch (error) {
      throw handleApiError(error);
    }
  }
}

/**
 * 翻訳設定サービスのデフォルト実装クラス
 * TranslationSettingServiceの抽象クラスを継承し、具体的な実装を提供
 */
export class DefaultTranslationSettingService extends TranslationSettingService {}

export const translationSettingService = new DefaultTranslationSettingService();
