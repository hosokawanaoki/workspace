import { Book, book_TranslateRequest as TranslateRequest, TranslateResponse } from '@/types/Book';
import { API_ENDPOINTS } from '@/api/endpoints';
import apiClient from '@/api/apiClient';
import { handleApiError } from '@/api/errorHandler';
import { validateBookId, validateModel } from '@/services/book/validateUtils';

export interface TranslationHistory {
  date: string;
  from_status: string;
  to_status: string;
  details: string;
  version: number;
}

export interface TagError {
  line: number;
  position: number;
  error_type: string;
  content: string;
  suggestion?: string;
}

export interface TranslationVersion {
  id: number;
  version: number;
  description: string | null;
  status: 'chunked' | 'translating' | 'translated' | 'tag_recovered';
  created_at: string;
}

export interface TranslationPair {
  previous_text: string;
  current_text: string;
}

export interface TranslationContent {
  translations: TranslationPair[];
  version_type: 'original' | 'comparison';
  previous_version: number;
  current_version: number;
}

export abstract class BookService {
  abstract get_book_by_id(id: string): Promise<Book>;
  abstract validate_book_id(id: string): boolean;

  /**
   * 全ての書籍データを取得する
   * @returns {Promise<Book[]>} 書籍データの配列
   * @throws {Error} APIエラーが発生した場合
   */
  async getBooks(): Promise<Book[]> {
    try {
      const response = await apiClient.get(API_ENDPOINTS.BOOKS.LIST);
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 指定されたIDの書籍データを取得する
   * @param {number} id - 書籍ID
   * @returns {Promise<Book>} 書籍データ
   * @throws {Error} APIエラーが発生した場合
   */
  async getBook(id: string): Promise<Book> {
    try {
      const response = await apiClient.get(API_ENDPOINTS.BOOKS.DETAIL(id));
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 新しい書籍データを作成する
   * @param {Partial<Book>} data - 作成する書籍データ
   * @returns {Promise<Book>} 作成された書籍データ
   * @throws {Error} APIエラーが発生した場合
   */
  async createBook(data: Partial<Book>): Promise<Book> {
    try {
      const response = await apiClient.put(API_ENDPOINTS.BOOKS.CREATE, data);
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 指定されたIDの書籍データを更新する
   * @param {number} id - 書籍ID
   * @param {Partial<Book>} data - 更新する書籍データ
   * @returns {Promise<Book>} 更新された書籍データ
   * @throws {Error} APIエラーが発生した場合
   */
  async updateBook(id: string, data: Partial<Book>): Promise<Book> {
    try {
      const response = await apiClient.post(API_ENDPOINTS.BOOKS.UPDATE(id), data);
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 書籍の翻訳履歴を取得する
   * @param {number} id - 書籍ID
   * @returns {Promise<TranslationHistory[]>} 翻訳履歴の配列
   * @throws {Error} APIエラーが発生した場合
   */
  async getTranslationHistory(id: string): Promise<TranslationHistory[]> {
    try {
      const response = await apiClient.get(API_ENDPOINTS.BOOKS.HISTORY(id));
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 書籍のタグエラー情報を取得する
   * @param {number} id - 書籍ID
   * @returns {Promise<TagError[]>} タグエラー情報の配列
   * @throws {Error} APIエラーが発生した場合
   */
  async getTagErrors(id: string): Promise<TagError[]> {
    try {
      const response = await apiClient.get(API_ENDPOINTS.BOOKS.TAG_ERRORS(id));
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 特定のタグエラーを修正する
   * @param {number} id - 書籍ID
   * @param {number} errorIndex - エラーのインデックス
   * @returns {Promise<void>}
   * @throws {Error} APIエラーが発生した場合
   */
  async fixTagError(id: string, errorIndex?: number): Promise<void> {
    try {
      const data = errorIndex !== undefined ? { error_index: errorIndex } : {};
      await apiClient.post(API_ENDPOINTS.BOOKS.FIX_TAG_ERROR(id), data);
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 書籍の翻訳を実行する
   * @param {TranslateRequest} data - 翻訳リクエストデータ
   * @returns {Promise<TranslateResponse>} 翻訳結果
   * @throws {Error} APIエラーが発生した場合
   */
  async translate(data: TranslateRequest): Promise<TranslateResponse> {
    try {
      const validatedData = {
        ...data,
        model: validateModel(data.model)
      };
      const response = await apiClient.post(API_ENDPOINTS.BOOKS.TRANSLATE, validatedData);
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 書籍の翻訳修復を実行する
   * @param {number} id - 書籍ID
   * @returns {Promise<TranslateResponse>} 翻訳修復結果
   * @throws {Error} APIエラーが発生した場合
   */
  async translateRepairBook(id: string): Promise<TranslateResponse> {
    try {
      const response = await apiClient.post(API_ENDPOINTS.BOOKS.TRANSLATE_REPAIR(id));
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * LLMを使用して書籍の翻訳を実行する
   * @param {TranslateRequest} data - 翻訳リクエストデータ
   * @returns {Promise<TranslateResponse>} 翻訳結果
   * @throws {Error} APIエラーが発生した場合
   */
  async translateLLM(data: TranslateRequest): Promise<TranslateResponse> {
    try {
      const validatedData = {
        ...data,
        model: validateModel(data.model)
      };
      const response = await apiClient.post(API_ENDPOINTS.BOOKS.TRANSLATE, validatedData);
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 進行中の翻訳をキャンセルする
   * @param {number} id - 書籍ID
   * @returns {Promise<TranslateResponse>} キャンセル結果
   * @throws {Error} APIエラーが発生した場合
   */
  async cancelTranslation(id: string): Promise<TranslateResponse> {
    try {
      const response = await apiClient.post(API_ENDPOINTS.BOOKS.TRANSLATE_CANCEL(id));
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 書籍のタグ情報を修復する
   * @param {number} id - 書籍ID
   * @returns {Promise<TranslateResponse>} タグ修復結果
   * @throws {Error} APIエラーが発生した場合
   */
  async repairTags(id: string): Promise<TranslateResponse> {
    try {
      const response = await apiClient.post(API_ENDPOINTS.BOOKS.REPAIR_TAGS(id));
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 書籍の翻訳バージョン一覧を取得する
   * @param {number} id - 書籍ID
   * @returns {Promise<TranslationVersion[]>} 翻訳バージョンの配列
   * @throws {Error} APIエラーが発生した場合
   */
  async getVersions(id: string): Promise<TranslationVersion[]> {
    try {
      const response = await apiClient.get(API_ENDPOINTS.BOOKS.VERSIONS(id));
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 特定バージョンの翻訳内容を取得する
   * @param {number} bookId - 書籍ID
   * @param {number} versionId - バージョンID
   * @returns {Promise<TranslationContent>} 翻訳内容
   * @throws {Error} APIエラーが発生した場合
   */
  async getVersionContent(bookId: string, versionId: number): Promise<TranslationContent> {
    try {
      const response = await apiClient.get(
        API_ENDPOINTS.BOOKS.VERSION_CONTENT(bookId, versionId)
      );
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }
}

/**
 * 書籍サービスのデフォルト実装クラス
 * BookServiceの抽象クラスを継承し、具体的な実装を提供
 */
export class DefaultBookService extends BookService {
  /**
   * 指定されたIDの書籍データを取得する
   * @param {number} id - 書籍ID
   * @returns {Promise<Book>} 書籍データ
   * @throws {Error} APIエラーが発生した場合
   */
  get_book_by_id(id: string): Promise<Book> {
    return this.getBook(id);
  }

  /**
   * 書籍IDのバリデーションを行う
   * @param {number} id - 検証対象の書籍ID
   * @returns {boolean} バリデーション結果
   */
  validate_book_id(id: string): boolean {
    return validateBookId(id);
  }

  /**
   * 書籍を削除する
   * @param {string} bookId - 削除する書籍ID
   * @returns {Promise<void>}
   * @throws {Error} APIエラーが発生した場合
   */
  async deleteBook(bookId: string): Promise<void> {
    try {
      await apiClient.delete(API_ENDPOINTS.BOOKS.DELETE_BATCH, {
        data: { book_id: bookId }
      });
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 書籍の特定バージョンを削除する
   * @param {string} bookId - 書籍ID
   * @param {number} versionId - 削除するバージョンID
   * @returns {Promise<void>}
   * @throws {Error} APIエラーが発生した場合
   */
  async deleteVersion(bookId: string, versionId: number): Promise<void> {
    try {
      await apiClient.delete(API_ENDPOINTS.BOOKS.DELETE_VERSION(bookId, versionId));
    } catch (error) {
      throw handleApiError(error);
    }
  }

  /**
   * 新しいバージョンを作成する
   * @param {string} bookId - 書籍ID
   * @param {object} data - バージョン作成データ
   * @param {string} data.version_name - バージョン名
   * @param {string} data.correction_instruction - 校正指示
   * @returns {Promise<any>} 作成されたバージョン情報
   * @throws {Error} APIエラーが発生した場合
   */
  async createVersion(bookId: string, data: { version_name: string; correction_instruction: string; model: string }): Promise<any> {
    try {
      const response = await apiClient.post(API_ENDPOINTS.BOOKS.CREATE_VERSION(bookId), data);
      return response.data;
    } catch (error) {
      throw handleApiError(error);
    }
  }
}

export const bookService = new DefaultBookService();
