import { API_ENDPOINTS } from '../endpoints';
import apiClient from '../apiClient';
import { LlmModel } from '@/constants/llmModels';

export const llmService = {
  /**
   * 利用可能なLLMモデルの一覧を取得する
   * @returns Promise<LlmModel[]> LLMモデルの一覧
   */
  async getModels(): Promise<LlmModel[]> {
    const response = await apiClient.get(API_ENDPOINTS.LLM.LIST);
    return response.data;
  },

  /**
   * モデル名から表示名を取得する
   * @param value モデル名
   * @returns Promise<string> 表示名
   */
  async getLlmModelLabel(value: string): Promise<string> {
    const models = await this.getModels();
    const model = models.find(model => model.value === value);
    return model?.label || value;
  }
};
