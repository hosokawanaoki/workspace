import { AxiosError } from 'axios';

export class ApiError extends Error {
  constructor(
    message: string,
    public statusCode?: number,
    public response?: any
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

export const handleApiError = (error: unknown): never => {
  if (error instanceof AxiosError) {
    console.error('APIエラー:', {
      message: error.message,
      response: error.response?.data,
      config: error.config,
    });

    throw new ApiError(
      error.response?.data?.message || 'APIリクエストに失敗しました',
      error.response?.status,
      error.response?.data
    );
  }

  if (error instanceof Error) {
    console.error('予期しないエラー:', error);
    throw new ApiError(error.message);
  }

  console.error('不明なエラー:', error);
  throw new ApiError('予期しないエラーが発生しました');
};
