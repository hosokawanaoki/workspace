export const API_ENDPOINTS = {
  LLM: {
    // LLMモデル一覧取得
    LIST: '/api/llm-models',
  },
  TRANSLATION_SETTINGS: {
    // 翻訳設定一覧取得
    LIST: '/api/translation-settings',
    // 翻訳設定作成
    CREATE: '/api/translation-settings',
    // 翻訳設定更新
    UPDATE: (id: string) => `/api/translation-settings/${id}`,
    DELETE: (id: string) => `/api/translation-settings/${id}`,
  },
  BOOKS: {
    // 書籍一覧取得
    LIST: '/api/books',
    // 書籍詳細取得
    DETAIL: (id: string) => `/api/books/${id}`,
    // 書籍作成
    CREATE: '/api/books',
    // 書籍更新
    UPDATE: (id: string) => `/api/books/${id}`,
    // 翻訳履歴取得
    HISTORY: (id: string) => `/api/books/${id}/history`,
    // タグエラー取得
    TAG_ERRORS: (id: string) => `/api/books/${id}/tag-errors`,
    // タグエラー修正
    FIX_TAG_ERROR: (id: string) => `/api/books/${id}/tag-errors`,
    // 翻訳バージョン一覧取得
    VERSIONS: (id: string) => `/api/books/${id}/versions`,
    // 翻訳バージョンの内容取得
    VERSION_CONTENT: (bookId: string, versionId: number) => 
      `/api/books/${bookId}/versions/${versionId}/content`,
    // バッチ翻訳
    TRANSLATE_BATCH: '/api/translate/batch',
    // 翻訳修復
    TRANSLATE_REPAIR: (id: string) => `/api/translate/${id}`,
    // 翻訳
    TRANSLATE: '/api/translate',
    // 翻訳キャンセル
    TRANSLATE_CANCEL: (id: string) => `/api/translate/cancel/${id}`,
    // タグ修復
    REPAIR_TAGS: (id: string) => `/api/translate/repair/${id}`,
    // 書籍削除
    DELETE_BATCH: '/api/translate/batch',
    // バージョン削除
    DELETE_VERSION: (bookId: string, versionId: number) => `/api/books/${bookId}/versions/${versionId}`,
    // バージョン作成
    CREATE_VERSION: (bookId: string) => `/api/books/${bookId}/versions`
  }
} as const;
