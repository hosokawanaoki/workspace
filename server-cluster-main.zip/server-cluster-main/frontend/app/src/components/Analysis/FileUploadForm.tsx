import React, { useState, useRef } from 'react';

const FileUploadForm: React.FC = () => {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      setSelectedFile(files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="upload-container">
      <div
        className={`upload-area ${isDragging ? 'dragging' : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileSelect}
          style={{ display: 'none' }}
        />
        <p>ファイルをドラッグ&ドロップ、または</p>
        <button onClick={handleButtonClick} className="select-button">
          ファイルを選択
        </button>
        {selectedFile && (
          <p className="selected-file">
            選択されたファイル: {selectedFile.name}
          </p>
        )}
      </div>
      <style>{`
        .upload-container {
          margin: 20px 0;
        }
        .upload-area {
          border: 2px dashed #ccc;
          border-radius: 8px;
          padding: 20px;
          text-align: center;
          background-color: #f8f9fa;
          transition: all 0.3s ease;
        }
        .upload-area.dragging {
          background-color: #e9ecef;
          border-color: #6c757d;
        }
        .select-button {
          background-color: #007bff;
          color: white;
          border: none;
          padding: 10px 20px;
          border-radius: 4px;
          cursor: pointer;
          margin: 10px 0;
          transition: background-color 0.3s ease;
        }
        .select-button:hover {
          background-color: #0056b3;
        }
        .selected-file {
          margin-top: 10px;
          color: #28a745;
        }
      `}</style>
    </div>
  );
};

export default FileUploadForm;
