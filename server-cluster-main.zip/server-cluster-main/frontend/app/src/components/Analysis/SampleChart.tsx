import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';

const SampleChart: React.FC<{}> = () => {
  // サンプルデータ
  const data = [
    { name: '1月', value1: 400, value2: 240 },
    { name: '2月', value1: 300, value2: 139 },
    { name: '3月', value1: 200, value2: 980 },
    { name: '4月', value1: 278, value2: 390 },
    { name: '5月', value1: 189, value2: 480 },
    { name: '6月', value1: 239, value2: 380 },
  ];

  return (
    <div className="chart-container">
      <h3>サンプルグラフ</h3>
      <ResponsiveContainer width="100%" height={400}>
        <BarChart
          data={data}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar
            dataKey="value1"
            fill="#8884d8"
            name="データ1"
          />
          <Bar
            dataKey="value2"
            fill="#82ca9d"
            name="データ2"
          />
        </BarChart>
      </ResponsiveContainer>
      <style>{`
        .chart-container {
          margin: 20px 0;
          padding: 20px;
          background-color: white;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h3 {
          margin-top: 0;
          color: #333;
          text-align: center;
        }
      `}</style>
    </div>
  );
};

export default SampleChart;
