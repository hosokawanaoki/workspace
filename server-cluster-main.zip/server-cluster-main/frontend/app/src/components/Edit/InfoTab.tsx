import React, { useEffect, useState } from 'react';
import { Alert, Form, Button } from 'react-bootstrap';
import { bookService, TranslationVersion, TranslationContent, TranslationPair } from '../../api/services/bookService';
import * as DiffMatchPatch from 'diff-match-patch';

interface InfoTabProps {
  id: string;
}

const InfoTab: React.FC<InfoTabProps> = ({ id }) => {
  const [versions, setVersions] = useState<Array<TranslationVersion>>([]);
  const [selectedVersion, setSelectedVersion] = useState<TranslationVersion | null>(null);
  const [translationContent, setTranslationContent] = useState<TranslationContent | null>(null);
  const [previousContent, setPreviousContent] = useState<TranslationContent | null>(null);
  const [loading, setLoading] = useState(true);
  const [contentLoading, setContentLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showDiff, setShowDiff] = useState(false);

  const dmp = new DiffMatchPatch.diff_match_patch();

  useEffect(() => {
    const fetchVersions = async () => {
      try {
        const versionData = await bookService.getVersions(id);
        setVersions(versionData);
        
        if (versionData.length > 0) {
          setSelectedVersion(versionData[0]);
          try {
            const content = await bookService.getVersionContent(id, versionData[0].version);
            setTranslationContent(content);
            if (versionData[0].version > 1) {
              const prevContent = await bookService.getVersionContent(id, versionData[0].version - 1);
              setPreviousContent(prevContent);
            }
          } catch (err) {
            console.error('Error fetching content:', err);
            setError('翻訳内容の取得に失敗しました。');
          }
        }
      } catch (err) {
        console.error('Error fetching versions:', err);
        setError('バージョン情報の取得に失敗しました。');
      } finally {
        setLoading(false);
      }
    };

    fetchVersions();
  }, [id]);

  const handleVersionChange = async (event: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedVersion = Number(event.target.value);
    const version = versions.find(v => v.version === selectedVersion);
    setSelectedVersion(version || null);
    
    if (version) {
      setContentLoading(true);
      try {
        const content = await bookService.getVersionContent(id, version.version);
        setTranslationContent(content);
        if (version.version > 1) {
          const prevContent = await bookService.getVersionContent(id, version.version - 1);
          setPreviousContent(prevContent);
        } else {
          setPreviousContent(null);
        }
      } catch (err) {
        setError('翻訳内容の取得に失敗しました。');
      } finally {
        setContentLoading(false);
      }
    }
  };

  if (loading) {
    return (
      <div className="p-4 bg-light rounded">
        <Alert variant="info">読み込み中...</Alert>
      </div>
    );
  }

  if (versions.length === 0) {
    return (
      <div className="p-4 bg-light rounded">
        <Alert variant="info">翻訳バージョンがありません。</Alert>
      </div>
    );
  }

  const getStatusText = (status: string) => {
    const statusMap: { [key: string]: string } = {
      chunked: 'チャンク化済',
      translating: '翻訳中',
      translated: '翻訳済',
      tag_recovered: 'タグ修復済'
    };
    return statusMap[status] || status;
  };

  return (
    <div className="p-4 bg-light rounded">
      <Form.Group className="mb-4">
        <Form.Label className="fw-bold">翻訳バージョン</Form.Label>
        <Form.Select 
          value={selectedVersion?.version || ''}
          onChange={handleVersionChange}
          className="mb-3"
        >
          {versions.map(version => (
            <option key={version.id} value={version.version}>
              Version {version.version} - {getStatusText(version.status)}
            </option>
          ))}
        </Form.Select>
      </Form.Group>

      {selectedVersion && (
        <>
          <div className="mb-4">
            <h5 className="mb-3">バージョン情報</h5>
            <table className="table">
              <tbody>
                <tr>
                  <th>バージョン番号</th>
                  <td>{selectedVersion.version}</td>
                </tr>
                <tr>
                  <th>ステータス</th>
                  <td>{getStatusText(selectedVersion.status)}</td>
                </tr>
                <tr>
                  <th>作成日時</th>
                  <td>{new Date(selectedVersion.created_at).toLocaleString('ja-JP')}</td>
                </tr>
                {selectedVersion.description && (
                  <tr>
                    <th>説明</th>
                    <td>{selectedVersion.description}</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div>
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h5 className="mb-0">翻訳内容</h5>
              {selectedVersion.version > 1 && (
                <Button
                  variant={showDiff ? "outline-primary" : "primary"}
                  size="sm"
                  onClick={() => setShowDiff(!showDiff)}
                >
                  {showDiff ? "通常表示" : "差分表示"}
                </Button>
              )}
            </div>
            {contentLoading ? (
              <Alert variant="info">読み込み中...</Alert>
            ) : error ? (
              <Alert variant="danger">{error}</Alert>
            ) : translationContent ? (
              <div>
                <div className="translation-content">
                  {translationContent.translations.map((item: TranslationPair, index: number) => (
                    <div key={index} className="translation-card mb-4">
                      <div className="row g-0">
                        <div className="col-md-6 border-end">
                          <div className="source-text p-3">
                            <small className="text-muted d-block mb-2">原文</small>
                            <div style={{ fontFamily: 'Roboto, sans-serif' }}>
                              {item.previous_text}
                            </div>
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="translated-text p-3">
                            <small className="text-muted d-block mb-2">翻訳</small>
                          <div style={{ fontFamily: 'Noto Sans JP, sans-serif' }}>
                            {showDiff && previousContent ? (
                              <div dangerouslySetInnerHTML={{
                                __html: dmp.diff_prettyHtml(
                                  dmp.diff_main(
                                    previousContent.translations[index]?.current_text || '',
                                    item.current_text
                                  )
                                )
                              }} />
                            ) : (
                              item.current_text
                            )}
                          </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <style>
                  {`
                    .translation-content {
                      background: white;
                      border-radius: 0.5rem;
                      box-shadow: 0 2px 4px rgba(0,0,0,0.05);
                    }
                    .translation-card {
                      background: white;
                      border: 1px solid #e9ecef;
                      border-radius: 0.5rem;
                      transition: transform 0.2s;
                    }
                    .translation-card:hover {
                      transform: translateY(-2px);
                      box-shadow: 0 4px 6px rgba(0,0,0,0.05);
                    }
                    .source-text, .translated-text {
                      background-color: #f8f9fa;
                      min-height: 100px;
                      border-radius: 0.5rem;
                      margin: 0.5rem;
                    }
                    .del {
                      background-color: #ffd7d7;
                      text-decoration: line-through;
                    }
                    .ins {
                      background-color: #d7ffd7;
                    }
                  `}
                </style>
              </div>
            ) : (
              <Alert variant="warning">翻訳内容がありません。</Alert>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default InfoTab;
