import React, { useState, useEffect } from 'react';
import { Table, Alert, Button, Modal } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { bookService, TranslationHistory } from '../../api/services/bookService';

interface TranslationHistoryTabProps {
  id: string;
}

const TranslationHistoryTab: React.FC<TranslationHistoryTabProps> = ({ id }) => {
  const navigate = useNavigate();
  const [histories, setHistories] = useState<TranslationHistory[]>([]);
  const [book, setBook] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedVersion, setSelectedVersion] = useState<number | null>(null);

  const fetchData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [historyData, bookData] = await Promise.all([
        bookService.getTranslationHistory(id),
        bookService.getBook(id)
      ]);
      setHistories(historyData);
      setBook(bookData);
    } catch (err) {
      setError('履歴データの取得に失敗しました');
      console.error('Error fetching history:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [id]);

  const handleDeleteClick = (version: number) => {
    setSelectedVersion(version);
    setShowDeleteModal(true);
  };

  const handleDeleteConfirm = async () => {
    if (selectedVersion === null) return;

    try {
      await bookService.deleteVersion(id, selectedVersion);
      await fetchData(); // データを再取得
      setShowDeleteModal(false);
    } catch (err) {
      setError('バージョンの削除に失敗しました');
      console.error('Error deleting version:', err);
    }
  };

  if (isLoading) {
    return (
      <div className="p-4 bg-light rounded">
        <div className="text-center">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 bg-light rounded">
        <Alert variant="danger" className="mb-0">
          {error}
        </Alert>
      </div>
    );
  }

  if (!histories || histories.length === 0) {
    return (
      <div className="p-4 bg-light rounded">
        <Alert variant="info" className="mb-0">
          翻訳履歴はありません
        </Alert>
      </div>
    );
  }

  return (
    <div className="p-4 bg-light rounded">
      <div className="d-flex justify-content-end mb-3">
        <Button
          variant="primary"
          onClick={() => navigate(`/books/${id}/versions/new?model=${book?.latest_batch?.model || ''}`)}
        >
          新規バージョン作成
        </Button>
      </div>
      <Table hover className="bg-white shadow-sm rounded">
        <thead className="bg-light">
          <tr>
            <th className="py-3 text-secondary border-0">作成日時</th>
            <th className="py-3 text-secondary border-0">バージョン情報</th>
            <th className="py-3 text-secondary border-0">操作</th>
          </tr>
        </thead>
        <tbody>
          {histories.map((history, index) => (
            <tr key={index}>
              <td className="py-3 align-middle">
                <span className="text-muted">{history.date}</span>
              </td>
              <td className="py-3 align-middle">
                <span className="text-dark">
                  version{history.version}
                  {history.details && ` - ${history.details}`}
                </span>
              </td>
              <td className="py-3 align-middle">
                {history.version > 1 && (
                  <Button
                    variant="outline-danger"
                    size="sm"
                    onClick={() => handleDeleteClick(history.version)}
                  >
                    削除
                  </Button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </Table>

      {/* 削除確認モーダル */}
      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>バージョン削除の確認</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Version {selectedVersion} を削除してもよろしいですか？
          <br />
          この操作は取り消せません。
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            キャンセル
          </Button>
          <Button variant="danger" onClick={handleDeleteConfirm}>
            削除
          </Button>
        </Modal.Footer>
      </Modal>

      <style>
        {`
          .table {
            border-collapse: separate;
            border-spacing: 0;
          }
          .table th:first-child {
            border-top-left-radius: 0.5rem;
          }
          .table th:last-child {
            border-top-right-radius: 0.5rem;
          }
          .badge {
            font-weight: 500;
            letter-spacing: 0.5px;
          }
        `}
      </style>
    </div>
  );
};

export default TranslationHistoryTab;
