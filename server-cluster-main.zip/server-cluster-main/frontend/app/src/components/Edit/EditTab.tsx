import React, { useState, useEffect } from 'react';
import { Form, Button, Alert } from 'react-bootstrap';
import { bookService } from '../../api/services/bookService';

interface EditTabProps {
  id: string;
}

interface BookData {
  title: string;
  title_jp: string;
  author: string;
}

const EditTab: React.FC<EditTabProps> = ({ id }) => {
  const [bookData, setBookData] = useState<BookData>({
    title: '',
    title_jp: '',
    author: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    const fetchBookData = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const response = await bookService.getBook(id);
        setBookData({
          title: response.title || '',
          title_jp: response.title_jp || '',
          author: response.author || ''
        });
      } catch (err) {
        setError('書籍データの取得に失敗しました');
        console.error('Error fetching book data:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchBookData();
  }, [id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setSuccessMessage(null);

    try {
      await bookService.updateBook(id, bookData);
      setSuccessMessage('更新が完了しました');
    } catch (err) {
      setError('更新に失敗しました');
      console.error('Error updating book:', err);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="p-4 bg-light rounded">
        <div className="text-center">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 bg-light rounded">
      {error && (
        <Alert variant="danger" className="mb-4">
          {error}
        </Alert>
      )}
      
      {successMessage && (
        <Alert variant="success" className="mb-4">
          {successMessage}
        </Alert>
      )}

      <Form onSubmit={handleSubmit}>
        <Form.Group className="mb-4">
          <Form.Label className="fw-bold text-primary">タイトル（原語）</Form.Label>
          <Form.Control
            type="text"
            value={bookData.title}
            onChange={(e) => setBookData({...bookData, title: e.target.value})}
            placeholder="原語のタイトルを入力"
            className="form-control-lg border-0 shadow-sm"
          />
        </Form.Group>

        <Form.Group className="mb-4">
          <Form.Label className="fw-bold text-primary">タイトル（日本語）</Form.Label>
          <Form.Control
            type="text"
            value={bookData.title_jp}
            onChange={(e) => setBookData({...bookData, title_jp: e.target.value})}
            placeholder="日本語のタイトルを入力"
            className="form-control-lg border-0 shadow-sm"
          />
        </Form.Group>

        <Form.Group className="mb-4">
          <Form.Label className="fw-bold text-primary">著者</Form.Label>
          <Form.Control
            type="text"
            value={bookData.author}
            onChange={(e) => setBookData({...bookData, author: e.target.value})}
            placeholder="著者名を入力"
            className="form-control-lg border-0 shadow-sm"
          />
        </Form.Group>

        <div className="d-flex justify-content-center mt-5">
          <Button 
            variant="primary" 
            type="submit"
            size="lg"
            className="px-5 py-2 shadow-sm fw-bold"
            disabled={isLoading}
          >
            {isLoading ? '保存中...' : '保存'}
          </Button>
        </div>
      </Form>

      <style>
        {`
          .form-control-lg {
            background-color: #ffffff;
            transition: all 0.2s;
          }
          .form-control-lg:focus {
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.15);
            border-color: #0d6efd;
          }
          .form-control-lg::placeholder {
            color: #adb5bd;
          }
        `}
      </style>
    </div>
  );
};

export default EditTab;
