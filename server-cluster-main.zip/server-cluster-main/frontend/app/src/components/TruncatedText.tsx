import React from 'react';

const TruncatedText = ({ text, maxLength = 50 }) => {
  if (!text) return null;

  const shouldTruncate = text.length > maxLength;
  const displayText = shouldTruncate 
    ? text.slice(0, maxLength) + '...' 
    : text;

  return <span>{displayText}</span>;
};

export default TruncatedText;