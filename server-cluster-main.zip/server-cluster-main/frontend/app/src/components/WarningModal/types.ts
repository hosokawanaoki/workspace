export interface WarningModalProps {
    show: boolean;
    handleClose: () => void;
    notFoundItems: string[];
  }
  
  export interface ModalContentProps {
    notFoundItems: string[];
  }