import React, { useState } from 'react';
import { Modal, Button } from 'react-bootstrap';
import { WarningModalProps } from '@/components/WarningModal/types';

const WarningModal: React.FC<WarningModalProps> = ({ show, handleClose, notFoundItems }) => {
  return (
    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>警告</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {notFoundItems.length > 0 ? (
          <>
            <p>以下の項目が見つかりませんでした:</p>
            <ul>
              {notFoundItems.map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>
          </>
        ) : (
          <p>全ての項目が正常に処理されました。</p>
        )}
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          閉じる
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default WarningModal;