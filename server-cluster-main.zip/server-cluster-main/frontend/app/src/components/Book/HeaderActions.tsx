import React from 'react';
import { Button, Alert } from 'react-bootstrap';

interface HeaderActionsProps {
  error?: string;
  onAddLlmClick: () => void;
  onTranslationSettingsClick: () => void;
}

const HeaderActions: React.FC<HeaderActionsProps> = ({
  error,
  onAddLlmClick,
  onTranslationSettingsClick,
}) => {
  return (
    <div className="d-flex justify-content-between align-items-center mb-3">
      <div>
        {error && <Alert variant="danger" className="bg-status-error text-white shadow-sm">{error}</Alert>}
      </div>
      <div>
        <Button variant="primary" className="bg-primary-main border-0 shadow-sm transition-default me-2" onClick={onAddLlmClick}>
          AI翻訳
        </Button>
        <Button variant="secondary" className="border-0 shadow-sm transition-default" onClick={onTranslationSettingsClick}>
          翻訳設定
        </Button>
      </div>
    </div>
  );
};

export default HeaderActions;
