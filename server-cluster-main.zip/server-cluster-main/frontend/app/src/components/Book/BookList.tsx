import { Book, BookStatus, BookStatusLabels, SortConfig } from '@/types/Book';
import React from 'react';
import { Table } from 'react-bootstrap';
import BookActionButtons from '@/components/Book/BookActionButtons';

const formatDateTime = (dateTimeStr: string | undefined): string => {
  if (!dateTimeStr) return '未設定';
  const date = new Date(dateTimeStr);
  return `${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日 ${date.getHours()}:${String(date.getMinutes()).padStart(2, '0')}:${String(date.getSeconds()).padStart(2, '0')}`;
};

interface BookListProps {
  loading: boolean;
  sortedBooks: Book[];
  sortConfig: SortConfig<Book>;
  handleSort: (key: keyof Book) => void;
  handleEditClick: (id: string) => void;
  handleActionClick: (id: string, status: BookStatus) => void;
  translateLLM: (id: string, model: string) => void;
  handleDeleteClick: (bookId: string) => void;
}

const BookList: React.FC<BookListProps> = ({
  loading,
  sortedBooks,
  sortConfig,
  handleSort,
  handleEditClick,
  handleActionClick,
  translateLLM,
  handleDeleteClick,
}) => {
  if (loading) {
    return <p>データを読み込み中...</p>;
  }


  return (
    <Table striped bordered hover responsive className="table-main">
      <thead>
        <tr>
          <th onClick={() => handleSort('id')} style={{ width: '6%' }}>
            ID {sortConfig.key === 'id' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
          </th>
          <th onClick={() => handleSort('book_id')} style={{ width: '7%' }}>
            書籍情報 {sortConfig.key === 'book_id' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
          </th>
          <th onClick={() => handleSort('title_jp')} style={{ width: '25%' }}>
            書籍タイトル {sortConfig.key === 'title_jp' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
          </th>
          <th style={{ width: '25%' }}>
            詳細
            <div style={{ fontSize: '0.9em', marginTop: '4px' }}>
              <div onClick={() => handleSort('author')} style={{ cursor: 'pointer' }}>
                作者 {sortConfig.key === 'author' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
              </div>
              <div onClick={() => handleSort('downloads')} style={{ cursor: 'pointer' }}>
                ダウンロード数 {sortConfig.key === 'downloads' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
              </div>
            </div>
          </th>
          <th style={{ width: '20%'}}>翻訳履歴</th>
          <th onClick={() => handleSort('status')} style={{ width: '10%'}}>
            状態 {sortConfig.key === 'status' && (sortConfig.direction === 'asc' ? '▲' : '▼')}
          </th>
          <th style={{ width: '10%' }}>操作</th>
        </tr>
      </thead>
      <tbody>
        {sortedBooks.map((book) => (
          <tr key={book.id}>
            <td>{book.id}</td>
            <td>
              <div>{book.original_id} </div>
              <div style={{ fontSize: '0.9em', color: '#666', marginTop: '4px' }}>
                jp
              </div>
              <div style={{ fontSize: '0.9em', color: '#666', marginTop: '4px' }}>
                {book.provider}
              </div>
            </td>
            <td>
              {(book.status === BookStatus.Translated || book.status === BookStatus.Translating || book.status === BookStatus.TagError) ? (
                <>
                  <div>
                    {book.title_jp && (
                      <a
                        href={`${import.meta.env.VITE_APP_BASE_API_URL}/data/書籍一式/${book.book_id}/最終出力/pg${book.book_id}_v1-images.html`}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {book.title_jp}
                        {book.current_version && ` (Version ${book.current_version.version})`}
                      </a>
                    )}
                  </div>
                  <div style={{ fontSize: '0.9em', color: '#666', marginTop: '4px' }}>
                    <a
                      href={`${import.meta.env.VITE_APP_BASE_API_URL}/data/書籍一式/${book.book_id}/最終出力/pg${book.book_id}_v1-images.html`}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{ color: '#666' }}
                    >
                      {book.title}
                      {book.current_version && ` (Version ${book.current_version.version})`}
                    </a>
                  </div>
                </>
              ) : (
                <>
                  <div>{book.title_jp}</div>
                  <div style={{ fontSize: '0.9em', color: '#666', marginTop: '4px' }}>{book.title}</div>
                </>
              )}
            </td>
            <td style={{ textAlign: 'left' }}>
              <div style={{ fontSize: '0.9em', display: 'inline-block', textAlign: 'left' }}>
                <div>作者: {book.author}</div>
                <div>原語: {book.language}</div>
                <div>ダウンロード数: {book.downloads}</div>
              </div>
            </td>
            <td style={{ textAlign: 'left' }}>
              <div style={{ fontSize: '0.9em', display: 'inline-block', textAlign: 'left' }}>
                <div>モデル: {book.latest_batch?.model || '未設定'}</div>
                <div>翻訳設定: {book.latest_batch?.translation_setting?.name || '未設定'}</div>
                <div>件数: {book.latest_batch?.limit || '未設定'}</div>
                <div>登録時間: {formatDateTime(book.latest_batch?.batch_time)}</div>
                {book.version_history && book.version_history.length > 0 && (
                  <div style={{ marginTop: '8px', borderTop: '1px solid #ddd', paddingTop: '8px' }}>
                    <div>バージョン履歴:</div>
                    {book.version_history.map((version) => (
                      <div key={version.version}>
                        <a
                          href={`${import.meta.env.VITE_APP_BASE_API_URL}/data/書籍一式/${book.book_id}/version${version.version}/pg${book.book_id}-images.html`}
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{ color: '#0066cc' }}
                        >
                          Version {version.version}
                          {version.description && ` - ${version.description}`}
                        </a>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </td>
            <td style={{ textAlign: 'left' }}>
              <div>{BookStatusLabels[book.status as BookStatus]}</div>
              {book.latest_batch?.status_message && (
                <div style={{ fontSize: '0.9em', marginTop: '4px', color: '#666' }}>
                  {book.latest_batch?.status_message}
                </div>
              )}
            </td>
            <td style={{ whiteSpace: 'nowrap' }}>
              <BookActionButtons
                bookId={book.book_id}
                original_id={book.original_id}
                status={book.status}
                model={book.latest_batch?.model}
                limit={book.latest_batch?.limit}
                latest_batch={book.latest_batch}
                onEdit={handleEditClick}
                onAction={handleActionClick}
                onRetry={translateLLM}
                onDelete={handleDeleteClick}
              />
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
};

export default BookList;
