import { useNavigate } from 'react-router-dom';
import { getAvailableActions, getDefaultModel, shouldShowEditButton } from '@/services/book/statusUtils';
import { BookStatus } from '@/types/Book';
import React from 'react';
import { Button } from 'react-bootstrap';

const VITE_APP_BASE_API_URL = import.meta.env.VITE_APP_BASE_API_URL;

interface BookActionButtonsProps {
  bookId?: string;
  original_id?: string;
  status?: BookStatus;
  model?: string;
  limit?: number;
  latest_batch?: {
    batch_time: string;
    status: string;
    model: string;
    mode?: string;
    translation_setting?: {
      id: number
    }
    limit: number;
    force_stop: boolean;
  };
  onEdit: (id: string) => void;
  onAction: (id: string, status: BookStatus) => void;
  onRetry: (id: string, model: string) => void;
  onDelete: (bookId: string) => void;
}

const BookActionButtons: React.FC<BookActionButtonsProps> = ({
  bookId = '',
  original_id = '',
  status,
  model,
  limit,
  latest_batch,
  onEdit,
  onAction,
  onRetry,
  onDelete,
}) => {
  const navigate = useNavigate();
  const buttons: JSX.Element[] = [];

  if (status && shouldShowEditButton(status)) {
    buttons.push(
      <Button
        key="edit"
        variant="primary"
        size="sm"
        className="bg-primary-main border-0 shadow-sm transition-default"
        onClick={() => onEdit(bookId)}
      >
        詳細
      </Button>
    );
  }

  const actions = status ? getAvailableActions(status) : { canTranslate: false, canCancel: false, canRepair: false, canGenerate: false, canDelete: false };

  if (status === BookStatus.Translated || status === BookStatus.Translating || status === BookStatus.TagError) {
    const downloadUrl = `${VITE_APP_BASE_API_URL}/data/書籍一式/${bookId}/最終出力/pg${bookId}.epub`;
    buttons.push(
      <Button
        key="download"
        variant="success"
        size="sm"
        className="bg-success border-0 shadow-sm transition-default"
        as="a"
        href={downloadUrl}
        download
      >
        ダウンロード
      </Button>
    );
  }

  if (actions.canTranslate && latest_batch?.translation_setting) {
    buttons.push(
      <Button
        key="translate"
        variant="primary"
        size="sm"
        className="bg-primary-main border-0 shadow-sm transition-default"
        onClick={() => navigate('/addLlm', {
          state: {
            original_id: original_id,
            ...(latest_batch ? {
              batch_time: latest_batch.batch_time,
              status: status,  // latest_batch.statusからstatusに変更
              model: latest_batch.model,
              translation_setting_id: latest_batch?.translation_setting?.id,
              limit: latest_batch.limit,
              force_stop: latest_batch.force_stop
            } : {})
          }
        })}
      >
        {latest_batch?.mode === 'correction' ? '校正中' : '翻訳'}
      </Button>
    );
  }

  if (actions.canCancel && status) {
    buttons.push(
      <Button
        key="cancel"
        variant="danger"
        size="sm"
        className="bg-status-error border-0 shadow-sm transition-default"
        onClick={() => onAction(bookId, status)}
      >
        キャンセル
      </Button>
    );
  }

  if (actions.canRepair && status) {
    buttons.push(
      <Button
        key="repair"
        variant="warning"
        size="sm"
        className="bg-status-warning border-0 shadow-sm transition-default"
        onClick={() => onAction(bookId, status)}
      >
        タグ修復
      </Button>
    );
  }

  if (actions.canDelete && !actions.canCancel) {
    buttons.push(
      <Button
        key="delete"
        variant="danger"
        size="sm"
        className="bg-status-error border-0 shadow-sm transition-default"
        onClick={() => {
          if (window.confirm('本当に削除しますか？')) {
            onDelete(String(bookId));
          }
        }}
      >
        削除
      </Button>
    );
  }

  return (
    <>
      {buttons.map((button, index) => (
        <React.Fragment key={index}>
          {index > 0 && ' '}
          {button}
        </React.Fragment>
      ))}
    </>
  );
};

export default BookActionButtons;
