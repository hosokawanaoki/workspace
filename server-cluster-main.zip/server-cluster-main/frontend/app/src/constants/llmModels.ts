import { llmService } from '@/api/services/llm';

export interface LlmModel {
  value: string;  // 内部キー
  label: string;  // 表示値
  model_name: string;  // 実際のモデル名
}

// モデル一覧をAPIから取得
let cachedModels: LlmModel[] = [];

export const getLlmModels = async (): Promise<LlmModel[]> => {
  if (cachedModels.length === 0) {
    try {
      cachedModels = await llmService.getModels();
    } catch (error) {
      console.error('LLMモデル一覧の取得に失敗しました:', error);
      return [];
    }
  }
  return cachedModels;
};

// モデル名から表示名を取得するユーティリティ関数
export const getLlmModelLabel = async (value: string): Promise<string> => {
  const models = await getLlmModels();
  const model = models.find(model => model.value === value);
  return model?.label || value;
};
