import { useState, useCallback, useMemo } from 'react';
import { Book, SortConfig, TranslateResponse } from '@/types/Book';
import { bookService, ApiError } from '@/api';
import { sortItems, toggleSortDirection } from '@/services/book/sortUtils';

/**
 * useBooksフックが返す値の型定義
 * @property {Book[]} books - 書籍データの配列
 * @property {boolean} loading - ローディング状態
 * @property {string | null} error - エラーメッセージ
 * @property {SortConfig<Book>} sortConfig - ソート設定
 * @property {Book[]} sortedBooks - ソートされた書籍データ
 * @property {() => Promise<void>} fetchBooks - 書籍データ取得関数
 * @property {(key: keyof Book) => void} handleSort - ソート処理関数
 * @property {(bookId: number) => Promise<TranslateResponse>} translateBook - 書籍翻訳関数
 * @property {(bookId: number, model: string) => Promise<TranslateResponse>} translateLLM - LLMを使用した書籍翻訳関数
 */
interface UseBooksReturn {
  books: Book[];
  setBooks: React.Dispatch<React.SetStateAction<Book[]>>;
  loading: boolean;
  error: string | null;
  sortConfig: SortConfig<Book>;
  sortedBooks: Book[];
  fetchBooks: () => Promise<void>;
  handleSort: (key: keyof Book) => void;
  translateBook: (bookId: string) => Promise<TranslateResponse>;
  translateLLM: (bookId: string, model: string) => Promise<TranslateResponse>;
}

/**
 * 書籍データ管理用のカスタムフック
 * @returns {UseBooksReturn} 書籍データと操作関数を含むオブジェクト
 */
export const useBooks = (): UseBooksReturn => {
  // 書籍データの状態管理
  const [books, setBooks] = useState<Book[]>([]);

  // ローディング状態の管理
  const [loading, setLoading] = useState(false);

  // エラーメッセージの管理
  const [error, setError] = useState<string | null>(null);

  // ソート設定の状態管理
  const [sortConfig, setSortConfig] = useState<SortConfig<Book>>({
    key: 'id',  // デフォルトのソートキー
    direction: 'desc'  // デフォルトのソート方向
  });

  /**
   * 書籍データを取得する関数
   * @async
   * @returns {Promise<void>}
   */
  const fetchBooks = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await bookService.getBooks();
      setBooks(data);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : '予期しないエラーが発生しました');
    } finally {
      setLoading(false);
    }
  }, []);

  /**
   * 書籍データのソート処理を行う関数
   * @param {keyof Book} key - ソート対象のプロパティ
   */
  const handleSort = useCallback((key: keyof Book) => {
    setSortConfig((prevConfig) => ({
      key,
      direction: toggleSortDirection(prevConfig.key, key, prevConfig.direction)
    }));
  }, []);

  /**
   * 書籍の翻訳処理を行う関数
   * @async
   * @param {number} bookId - 翻訳対象の書籍ID
   * @returns {Promise<TranslateResponse>} 翻訳結果
   */
  const translateBook = useCallback(async (bookId: string): Promise<TranslateResponse> => {
    setLoading(true);
    setError(null);
    try {
      const response = await bookService.translate({
        original_id: bookId,
        provider_id: "gutenberg",
        translation_setting_id: 1,
        model: "gpt-3.5-turbo"
      });
      await fetchBooks(); // 翻訳後に書籍リストを更新
      return response;
    } catch (err) {
      const errorMessage = err instanceof ApiError ? err.message : '翻訳処理中にエラーが発生しました';
      setError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [fetchBooks]);

  /**
   * LLMを使用して書籍の翻訳処理を行う関数
   * @async
   * @param {number} bookId - 翻訳対象の書籍ID
   * @param {string} model - 使用するLLMモデル
   * @returns {Promise<TranslateResponse>} 翻訳結果
   */
  const translateLLM = useCallback(async (bookId: string, model: string): Promise<TranslateResponse> => {
    setLoading(true);
    setError(null);
    try {
      const response = await bookService.translateLLM({
        original_id: bookId,
        provider_id: "gutenberg",
        translation_setting_id: 1,
        model: model,
        start: 1,
        limit: 1000
      });
      await fetchBooks(); // 翻訳後に書籍リストを更新
      return response;
    } catch (err) {
      const errorMessage = err instanceof ApiError ? err.message : 'LLM翻訳処理中にエラーが発生しました';
      setError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [fetchBooks]);

  /**
   * ソートされた書籍データを返す
   * @returns {Book[]} ソート済み書籍データ
   */
  const sortedBooks = useMemo(() => {
    return sortItems(books, sortConfig);
  }, [books, sortConfig]);

  return {
    books,
    setBooks,
    loading,
    error,
    sortConfig,
    sortedBooks,
    fetchBooks,
    handleSort,
    translateBook,
    translateLLM
  };
};
