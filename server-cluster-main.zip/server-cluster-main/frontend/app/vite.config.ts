import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

// https://vitejs.dev/config/
export default defineConfig(() => {
  const isDev = process.env.NODE_ENV === 'development'

  // 共通の設定
  const commonConfig = {
    plugins: [react()],
    css: {
      devSourcemap: isDev
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, './src')
      }
    }
  }

  if (isDev) {
    // 開発環境の設定
    return {
      ...commonConfig,
      server: {
        hmr: {
          overlay: true
        },
        port: 5173,
        host: true
      },
      build: {
        sourcemap: isDev,
        minify: !isDev
      }
    }
  } else {
    // 本番環境の設定
    return {
      ...commonConfig,
      server: {
        hmr: {
          overlay: true
        },
        port: 5173,
        host: true
      },
      build: {
        sourcemap: isDev,
        minify: !isDev
      }
    }
  }
})
