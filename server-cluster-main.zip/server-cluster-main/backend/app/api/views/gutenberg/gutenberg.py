"""
Project Gutenbergからの書籍スクレイピングを行うAPIビューを定義するモジュール。
"""

import logging
from typing import Any

from api.services.scraping.implementations.scraping_service_impl import (
    ScrapingServiceImpl,
)
from rest_framework import status
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.views import APIView

logger = logging.getLogger(__name__)


class GutenbergView(APIView):
    """Project Gutenbergからの書籍情報取得を管理するビュー"""

    def __init__(self, scraping_service=None, *args: Any, **kwargs: Any) -> None:
        """初期化

        Args:
            scraping_service: スクレイピングサービス（省略時はデフォルト）
        """
        super().__init__(*args, **kwargs)
        self.scraping_service = scraping_service or ScrapingServiceImpl()

    def put(self, request: Request) -> Response:
        """書籍情報のスクレイピングを実行する

        Args:
            request: HTTPリクエスト
                - start_id: スクレイピングを開始するID（オプション）

        Returns:
            Response: スクレイピング結果とステータスコード
        """
        try:
            logger.info("Received PUT data: %s", request.data)
            start_id = request.data.get("start_id", 0)

            result = self.scraping_service.scrape_gutenberg(start_id)
            return Response(
                {**result, "start_id": start_id},
                status=status.HTTP_200_OK,
            )

        except (IOError, RuntimeError, ValueError) as e:
            logger.error("Error processing request: %s", str(e))
            return Response(
                {
                    "status": "error",
                    "message": f"Request processing failed: {str(e)}",
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
