from api.models import Book
from api.models.translation_version import TranslationVersion
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView


class TranslationHistoryView(APIView):
    """書籍の翻訳履歴を取得するビュー"""

    def get(self, request, book_id):
        """書籍の翻訳履歴を取得する

        Args:
            request: リクエスト
            book_id: 書籍ID

        Returns:
            Response: レスポンス
        """
        try:
            book = Book.get_book_by_book_id(book_id)
            if not book:
                return Response(
                    {"error": "指定された書籍が見つかりません"},
                    status=status.HTTP_404_NOT_FOUND,
                )

            versions = TranslationVersion.get_version_history_by_book(book.book_id)
            history_data = []

            for version in versions:
                history_data.append(
                    {
                        "date": version.created_at.strftime("%Y/%m/%d %H:%M"),
                        "from_status": "raw" if version.version == 1 else "translated",
                        "to_status": version.status,
                        "details": version.description or "",
                        "version": version.version,
                    }
                )
            return Response(history_data)
        except Exception as e:
            return Response(
                {"error": f"エラーが発生しました: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
