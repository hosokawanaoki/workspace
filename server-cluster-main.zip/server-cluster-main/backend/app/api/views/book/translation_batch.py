"""
翻訳バッチを管理するAPIビューを定義するモジュール
"""

import logging

from api.services.book.implementations.book_batch_service_impl import (
    BookBatchServiceImpl,
)
from rest_framework import status
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.views import APIView

logger = logging.getLogger(__name__)


class TranslationBatchView(APIView):
    """翻訳バッチを管理するエンドポイント"""

    def __init__(self, book_batch_service=None, *args, **kwargs):
        """初期化

        Args:
            book_batch_service: 書籍バッチサービス（省略時はデフォルト）
        """
        super().__init__(*args, **kwargs)
        self.book_batch_service = book_batch_service or BookBatchServiceImpl()

    def post(self, request: Request) -> Response:
        """書籍のステータスをwaitingに更新し、翻訳バッチを作成する

        Args:
            request: HTTPリクエスト
                - book_id: 書籍ID
                - title_jp: 日本語タイトル
                - author: 著者名
                - summary: 要約

        Returns:
            Response: 処理結果とステータスコード
        """
        data = request.data

        # Required parameters
        book_id = data.get("book_id")
        text_type = data.get("type")
        limit = data.get("limit", 1000)
        limit = int(limit)

        # Optional parameters
        model = data.get("model", "claude")
        start = data.get("start", 1)

        try:
            self.book_batch_service.create_translation_batch(
                book_id=book_id,
                text_type=text_type,
                limit=limit,
                model=model,
                start=start,
            )
            return Response(
                {"message": "ステータスをwaitingに更新し、翻訳バッチを作成しました"},
                status=status.HTTP_200_OK,
            )

        except ValueError as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except (IOError, RuntimeError) as e:
            logger.error("Batch creation error: %s", str(e))
            return Response(
                {"error": f"エラーが発生しました: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    def delete(self, request: Request) -> Response:
        """書籍IDに基づいて翻訳バッチを削除する

        Args:
            request: HTTPリクエスト
                - book_id: 書籍ID

        Returns:
            Response: 処理結果とステータスコード
        """
        data = request.data
        book_id = data.get("book_id")
        book_id = str(book_id)

        try:
            self.book_batch_service.delete_translation_batch(book_id=book_id)
            return Response(
                {"message": "翻訳バッチを削除しました"},
                status=status.HTTP_200_OK,
            )

        except ValueError as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except Exception as e:
            logger.error("Batch deletion error: %s", str(e))
            return Response(
                {"error": f"エラーが発生しました: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
