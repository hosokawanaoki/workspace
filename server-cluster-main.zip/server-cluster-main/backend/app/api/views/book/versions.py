"""
書籍の翻訳バージョン一覧の取得と新規作成を行うビュー
"""

import logging
from typing import TypedDict

from api.models.book import Book
from api.models.translation_version import TranslationVersion
from api.services.book.implementations.correction_batch_service_impl import (
    CorrectionBatchServiceImpl,
)
from api.services.models.translation_service import TranslationService
from rest_framework import status
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.views import APIView


class VersionCreateRequest(TypedDict):
    """バージョン作成リクエストの型定義"""

    version_name: str
    correction_instruction: str
    model: str


logger = logging.getLogger(__name__)


class BookVersionsView(APIView):
    """書籍の翻訳バージョン一覧の取得と新規作成を行うビュー"""

    def __init__(self, correction_batch_service=None, *args, **kwargs):
        """初期化

        Args:
            correction_batch_service: 校正バッチサービス（省略時はデフォルト）
        """
        super().__init__(*args, **kwargs)
        self.correction_batch_service = (
            correction_batch_service or CorrectionBatchServiceImpl()
        )

    def get(self, request: Request, book_id: str) -> Response:
        """
        書籍の翻訳バージョン一覧を取得する

        Args:
            request: リクエストオブジェクト
            book_id: 書籍ID

        Returns:
            Response: レスポンスオブジェクト
        """
        try:
            book = Book.get_book_by_book_id(book_id)
            if not book:
                return Response(
                    {"error": "指定された書籍が見つかりません。"},
                    status=status.HTTP_404_NOT_FOUND,
                )

            versions = TranslationVersion.get_versions_by_book(book_id)
            versions_data = []

            for version in versions:
                versions_data.append(
                    {
                        "id": version.id,
                        "version": version.version,
                        "description": version.description,
                        "status": version.status,
                        "created_at": str(version.created_at),
                    }
                )

            return Response(versions_data)
        except Exception as e:
            return Response(
                {"error": f"エラーが発生しました: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    def post(self, request: Request, book_id: str) -> Response:
        """新しいバージョンを作成する

        Args:
            request: HTTPリクエスト (VersionCreateRequest型)
                - version_name: 新しいバージョンの名前
                - correction_instruction: 校正指示
            book_id: 書籍ID

        Returns:
            Response: 処理結果とステータスコード
                - version_id: 作成されたバージョンのID
                - batch_id: 作成されたバッチのID
                - status: バッチのステータス ("waiting")
        """
        data = request.data
        logger.info("Received version creation request: %s", data)

        # Required parameters
        version_name = data.get("version_name")
        correction_instruction = data.get("correction_instruction")
        model = data.get("model")

        if not all([version_name, correction_instruction, model]):
            return Response(
                {
                    "error": "version_name、correction_instruction、modelは必須パラメータです。"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            # 新しいバージョンとバッチの作成
            result = self.correction_batch_service.create_batch(
                book_id=book_id,
                version_name=version_name,
                correction_instruction=correction_instruction,
                model=model,
            )

            return Response(
                {
                    "version_id": result["version_id"],
                    "batch_id": result["batch_id"],
                    "status": "waiting",
                    "message": "校正バッチを作成しました。スケジューラーが1分以内に処理を開始します。",
                },
                status=status.HTTP_200_OK,
            )

        except ValueError as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except (IOError, RuntimeError) as e:
            logger.error("Batch creation error: %s", str(e))
            return Response(
                {"error": f"エラーが発生しました: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

    def delete(self, request: Request, book_id: str, version_id: int) -> Response:
        """書籍の翻訳バージョンを削除する

        Args:
            request: リクエストオブジェクト
            book_id: 書籍ID
            version_id: バージョンID

        Returns:
            Response: レスポンスオブジェクト
        """
        try:
            # 書籍の存在確認
            book = Book.get_book_by_book_id(book_id)
            if not book:
                return Response(
                    {"error": "指定された書籍が見つかりません。"},
                    status=status.HTTP_404_NOT_FOUND,
                )

            # バージョンの取得
            version = TranslationVersion.get_version_by_book_and_version(
                book, version_id
            )
            if not version:
                return Response(
                    {"error": "指定されたバージョンが見つかりません。"},
                    status=status.HTTP_404_NOT_FOUND,
                )

            # バージョンと関連データの削除
            TranslationService.delete_by_version(version)

            return Response(status=status.HTTP_204_NO_CONTENT)

        except Exception as e:
            logger.error(f"バージョン削除中にエラーが発生しました: {str(e)}")
            return Response(
                {"error": f"エラーが発生しました: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
