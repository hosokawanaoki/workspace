"""
書籍関連のビューモジュール

書籍の一覧表示、翻訳などの機能を提供するビューを含みます。
"""

from api.views.book.list import BookListView

__all__ = [
    "BookListView",
]
