"""翻訳キャンセル用APIビュー"""

import logging

from api.services.book.implementations.book_batch_service_impl import (
    BookBatchServiceImpl,
)
from rest_framework import status
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.views import APIView

logger = logging.getLogger(__name__)


class CancelTranslationView(APIView):
    """翻訳キャンセル用エンドポイント"""

    def __init__(self, book_batch_service=None, *args, **kwargs):
        """初期化

        Args:
            book_batch_service: 書籍バッチサービス（省略時はデフォルト）
        """
        super().__init__(*args, **kwargs)
        self.book_batch_service = book_batch_service or BookBatchServiceImpl()

    def post(self, request: Request, book_id: str) -> Response:
        """翻訳バッチをキャンセルする

        Args:
            request: HTTPリクエスト
            id: 翻訳バッチID

        Returns:
            Response: 処理結果とステータスコード
        """
        try:
            self.book_batch_service.cancel_translation_batch(book_id)
            return Response(
                {"message": "翻訳バッチをキャンセルしました"},
                status=status.HTTP_200_OK,
            )
        except ValueError as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except Exception as e:
            logger.error("Batch cancellation error: %s", str(e))
            return Response(
                {"error": f"エラーが発生しました: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
