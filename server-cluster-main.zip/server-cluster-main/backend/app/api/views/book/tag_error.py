from api.models import Book
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView


class TagErrorView(APIView):
    """書籍のタグエラー情報を取得・修正するビュー"""

    def get(self, request, book_id):
        """タグエラー情報を取得する

        Args:
            request: リクエスト
            book_id: 書籍ID

        Returns:
            Response: レスポンス
        """
        try:
            book = Book.objects.get(book_id=book_id)
            # TODO: 実際のタグエラー検出ロジックを実装
            # 現在はダミーデータを返す
            error_data = [
                {
                    "line": 23,
                    "position": 15,
                    "error_type": "閉じタグなし",
                    "content": "<p>このテキストは閉じタグがありません",
                    "suggestion": "<p>このテキストは閉じタグがありません</p>",
                },
                {
                    "line": 45,
                    "position": 8,
                    "error_type": "無効なタグ",
                    "content": "<invalid>無効なタグが使用されています</invalid>",
                    "suggestion": "<span>無効なタグが使用されています</span>",
                },
            ]
            return Response(error_data)
        except Book.DoesNotExist:
            return Response(
                {"error": "指定された書籍が見つかりません"},
                status=status.HTTP_404_NOT_FOUND,
            )

    def post(self, request, book_id):
        """タグエラーを修正する

        Args:
            request: リクエスト
            book_id: 書籍ID

        Returns:
            Response: レスポンス
        """
        try:
            book = Book.objects.get(book_id=book_id)
            error_index = request.data.get("error_index")

            if error_index is None:
                # すべてのエラーを自動修正
                return Response({"message": "すべてのエラーを修正しました"})
            else:
                # 特定のエラーを修正
                return Response({"message": f"エラー {error_index} を修正しました"})

        except Book.DoesNotExist:
            return Response(
                {"error": "指定された書籍が見つかりません"},
                status=status.HTTP_404_NOT_FOUND,
            )
