import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import pypandoc
from api.utils.file.directory_util import DirectoryUtil
from api.utils.file.file_util import FileUtil
from ebooklib import epub

logger = logging.getLogger(__name__)


class EPUBError(Exception):
    """EPUB操作中に発生する一般的なエラー"""

    pass


class EPUBValidationError(EPUBError):
    """EPUBファイルの検証に失敗した場合のエラー"""

    pass


class EPUBConversionError(EPUBError):
    """EPUB変換中に発生するエラー"""

    pass


@dataclass
class EPUBMetadata:
    """EPUBのメタデータ

    Attributes:
        title: タイトル
        author: 著者
        language: 言語コード
        publisher: 出版社
        rights: 著作権情報
        custom_metadata: その他のメタデータ
    """

    title: Optional[str] = None
    author: Optional[str] = None
    language: str = "ja"
    publisher: Optional[str] = None
    rights: Optional[str] = None
    custom_metadata: Dict[str, str] = field(default_factory=dict)

    def to_pandoc_args(self) -> List[str]:
        """Pandocコマンドライン引数に変換する

        Returns:
            List[str]: Pandocコマンドライン引数のリスト
        """
        args = []
        if self.title:
            args.extend(["-M", f"title={self.title}"])
        if self.author:
            args.extend(["-M", f"author={self.author}"])
        if self.publisher:
            args.extend(["-M", f"publisher={self.publisher}"])
        if self.rights:
            args.extend(["-M", f"rights={self.rights}"])

        for key, value in self.custom_metadata.items():
            args.extend(["-M", f"{key}={value}"])

        return args


@dataclass
class EPUBConfig:
    """EPUB変換の設定

    Attributes:
        language: 言語コード
        resource_paths: リソースパスのリスト
        pandoc_options: Pandocのオプション
    """

    language: str = "ja"
    resource_paths: List[str] = field(default_factory=list)
    pandoc_options: List[str] = field(default_factory=list)


class EPUBHandler:
    """EPUBファイルを操作するハンドラー

    EPUBファイルの読み書き、メタデータ管理、変換、検証などの
    機能を提供します。すべてのメソッドは静的メソッドとして提供されます。
    """

    @staticmethod
    def get_metadata(epub_path: Union[str, Path]) -> Dict[str, Any]:
        """EPUBファイルのメタデータを取得する

        Returns:
            Dict[str, Any]: メタデータの辞書

        Raises:
            ValueError: EPUBファイルが読み込まれていない場合
        """
        try:
            book = epub.read_epub(str(epub_path))
            metadata = {}
            for key in book.metadata:
                clean_key = key.split("}")[-1] if "}" in key else key
                metadata[clean_key] = book.metadata[key]

            logger.debug(f"メタデータを取得: {metadata}")
            return metadata

        except Exception as e:
            error_msg = f"メタデータの取得に失敗: {str(e)}"
            logger.error(error_msg)
            raise EPUBError(error_msg) from e

    @staticmethod
    def validate(epub_path: Union[str, Path]) -> bool:
        """EPUBファイルの妥当性を検証する

        Returns:
            bool: 検証が成功した場合はTrue

        Raises:
            EPUBValidationError: 検証に失敗した場合
            ValueError: EPUBファイルが読み込まれていない場合
        """
        try:
            book = epub.read_epub(str(epub_path))
            epub.validate(book)
            logger.info("EPUBファイルの検証に成功しました")
            return True

        except Exception as e:
            error_msg = f"EPUBファイルの検証に失敗: {str(e)}"
            logger.error(error_msg)
            raise EPUBValidationError(error_msg) from e

    @staticmethod
    def convert_to_epub(
        input_path: Union[str, Path],
        output_path: Union[str, Path],
        cover_image_path: Optional[Union[str, Path]] = None,
        metadata: Optional[EPUBMetadata] = None,
        config: Optional[EPUBConfig] = None,
    ) -> None:
        """HTMLファイルをEPUBフォーマットに変換する

        Args:
            input_path: 入力HTMLファイル
            output_path: 出力EPUBファイル
            cover_image_path: 表紙画像
            metadata: メタデータ
            config: 変換設定

        Raises:
            EPUBConversionError: 変換に失敗した場合
            FileNotFoundError: 入力ファイルが存在しない場合
        """
        try:
            input_path = Path(input_path)
            output_path = Path(output_path)
            config = config or EPUBConfig()

            EPUBHandler._validate_input_file(input_path)
            EPUBHandler._prepare_output_directory(output_path)

            extra_args = EPUBHandler._build_conversion_args(
                input_path, cover_image_path, metadata, config
            )

            EPUBHandler._execute_conversion(input_path, output_path, extra_args)
            logger.info(f"EPUBファイルを作成: {output_path}")

        except Exception as e:
            error_msg = f"EPUB変換に失敗: {str(e)}"
            logger.exception(error_msg)
            raise EPUBConversionError(error_msg) from e

    @staticmethod
    def _validate_input_file(input_path: Path) -> None:
        """入力ファイルを検証する

        Args:
            input_path: 入力ファイルパス

        Raises:
            FileNotFoundError: ファイルが存在しない場合
        """
        if not FileUtil.check_file_exists(input_path):
            raise FileNotFoundError(f"入力ファイルが見つかりません: {input_path}")

    @staticmethod
    def _prepare_output_directory(output_path: Path) -> None:
        """出力ディレクトリを準備する

        Args:
            output_path: 出力ファイルパス

        Raises:
            OSError: ディレクトリの作成に失敗した場合
        """
        DirectoryUtil.ensure_directory(output_path.parent)

    @staticmethod
    def _build_conversion_args(
        input_path: Path,
        cover_image_path: Optional[Union[str, Path]],
        metadata: Optional[EPUBMetadata],
        config: EPUBConfig,
    ) -> List[str]:
        """変換オプションを構築する

        Args:
            input_path: 入力ファイルパス
            cover_image_path: 表紙画像パス
            metadata: メタデータ
            config: 変換設定

        Returns:
            List[str]: Pandocコマンドライン引数
        """
        # 基本オプションの設定
        extra_args = [
            "--standalone",  # スタンドアロンドキュメントとして処理
            "-M",
            f"lang={config.language}",
        ]

        # リソースパスの設定
        working_dir = input_path.parent
        resource_paths = [
            str(working_dir),
            str(working_dir / "images"),
            *config.resource_paths,
        ]
        for path in resource_paths:
            extra_args.extend(["--resource-path", path])

        # カバー画像の追加
        if cover_image_path and FileUtil.check_file_exists(cover_image_path):
            extra_args.extend(["--epub-cover-image", str(cover_image_path)])

        # メタデータの追加（タイトルなどの設定）
        if metadata:
            metadata_args = metadata.to_pandoc_args()
            extra_args.extend(metadata_args)
            logger.info(f"メタデータ引数: {metadata_args}")

        # 追加のPandocオプション
        extra_args.extend(config.pandoc_options)

        return extra_args

    @staticmethod
    def _execute_conversion(
        input_path: Path, output_path: Path, extra_args: List[str]
    ) -> None:
        """変換を実行する

        Args:
            input_path: 入力ファイルパス
            output_path: 出力ファイルパス
            extra_args: Pandocコマンドライン引数

        Raises:
            EPUBConversionError: 変換に失敗した場合
        """
        try:
            pypandoc.convert_file(
                source_file=str(input_path),
                to="epub",
                outputfile=str(output_path),
                extra_args=extra_args,
            )
        except Exception as e:
            raise EPUBConversionError(f"Pandocによる変換に失敗: {str(e)}") from e
