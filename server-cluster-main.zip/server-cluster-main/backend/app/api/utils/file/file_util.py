import io
import json
import logging
import os
import shutil
import zipfile
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

from api.constants.constants import SYSTEM
from api.utils.file.directory_util import DirectoryUtil

logger = logging.getLogger(__name__)


class FileUtil:
    """基本的なファイル操作を提供するクラス

    主な機能：
    - ファイルの読み書き
    - ファイルの存在確認
    - パス操作
    - JSONファイルの読み込み
    """

    DEFAULT_ENCODING: str = SYSTEM.get("DEFAULT_ENCODING", "utf-8")

    @staticmethod
    def read_file(
        file_path: Union[str, Path],
        encoding: Optional[str] = None,
    ) -> str:
        """ファイルを読み込む

        Args:
            file_path: 読み込むファイルのパス
            encoding: エンコーディング（デフォルト: DEFAULT_ENCODING）

        Returns:
            str: ファイルの内容

        Raises:
            OSError: ファイルの読み込みに失敗した場合
        """
        enc = encoding or FileUtil.DEFAULT_ENCODING
        try:
            with open(file_path, "r", encoding=enc) as f:
                content = f.read()
                logger.debug(f"ファイルを読み込み: {file_path}")
                return content
        except OSError as e:
            error_msg = f"ファイルの読み込みに失敗: {file_path}"
            logger.error(error_msg)
            raise OSError(error_msg) from e

    @staticmethod
    def read_json_file(
        file_path: Union[str, Path],
        encoding: Optional[str] = None,
    ) -> Dict:
        """JSONファイルを読み込む

        Args:
            file_path: 読み込むファイルのパス
            encoding: エンコーディング（デフォルト: DEFAULT_ENCODING）

        Returns:
            Dict: 読み込んだJSONデータ

        Raises:
            OSError: ファイルの読み込みに失敗した場合
            json.JSONDecodeError: JSONのパースに失敗した場合
        """
        try:
            content = FileUtil.read_file(file_path, encoding)
            data = json.loads(content)
            logger.debug(f"JSONファイルを読み込み: {file_path}")
            return data
        except json.JSONDecodeError as e:
            error_msg = f"JSONのパースに失敗: {file_path}"
            logger.error(error_msg)
            raise ValueError(error_msg) from e

    @staticmethod
    def check_file_exists(path: Union[str, Path]) -> bool:
        """ファイルの存在を確認する

        Args:
            path: チェックするパス

        Returns:
            bool: ファイルが存在する場合はTrue
        """
        p = Path(path)
        exists = p.exists() and p.is_file()
        status = "存在します" if exists else "存在しません"
        logger.debug(f"ファイル {p} は{status}")
        return exists

    @staticmethod
    def join_paths(*paths: Union[str, Path]) -> str:
        """パスを安全に結合する

        Args:
            *paths: 結合するパス

        Returns:
            str: 結合されたパス
        """
        str_paths = [str(p) for p in paths]
        result = os.path.normpath(os.path.join(*str_paths))
        logger.debug(f"パスを結合: {result}")
        return result

    @staticmethod
    def remove_file(file_path: Union[str, Path]) -> None:
        """ファイルを安全に削除する

        Args:
            file_path: 削除するファイルのパス

        Note:
            - ファイルが存在しない場合は何もしない
            - ディレクトリの場合は削除しない
        """
        try:
            path = Path(file_path)
            if path.is_file():
                path.unlink()
                logger.debug(f"ファイルを削除: {path}")
        except OSError as e:
            logger.warning(f"ファイル {file_path} の削除に失敗: {e}")

    @staticmethod
    def extract_zip(
        zip_content: bytes,
        extract_dir: Union[str, Path],
        file_extensions: Optional[List[str]] = None,
    ) -> List[str]:
        """ZIPファイルを解凍し、指定された拡張子のファイルを抽出する

        Args:
            zip_content: ZIPファイルのバイトデータ
            extract_dir: 解凍先ディレクトリ
            file_extensions: 抽出するファイルの拡張子リスト（例: ['.html', '.htm']）
                           Noneの場合はすべてのファイルを抽出

        Returns:
            List[str]: 抽出されたファイルの相対パスリスト

        Raises:
            OSError: 解凍に失敗した場合
            ValueError: 指定された拡張子のファイルが見つからない場合
        """
        try:
            # 解凍先ディレクトリの作成
            os.makedirs(extract_dir, exist_ok=True)

            # ZIPファイルの解凍
            with zipfile.ZipFile(io.BytesIO(zip_content)) as zip_ref:
                # 指定された拡張子のファイルを抽出
                if file_extensions:
                    target_files = [
                        f
                        for f in zip_ref.namelist()
                        if any(f.endswith(ext) for ext in file_extensions)
                    ]
                    if not target_files:
                        raise ValueError(
                            f"ZIPファイル内に指定された拡張子 {file_extensions} "
                            "のファイルが見つかりません"
                        )
                else:
                    target_files = zip_ref.namelist()

                # ファイルの解凍
                zip_ref.extractall(extract_dir)
                logger.debug(f"ZIPファイルを {extract_dir} に解凍しました")

                return target_files

        except (zipfile.BadZipFile, OSError) as e:
            error_msg = f"ZIPファイルの解凍に失敗: {str(e)}"
            logger.error(error_msg)
            raise OSError(error_msg) from e

    @staticmethod
    def copy_files_exclude(
        src_dir: Union[str, Path],
        dest_dir: Union[str, Path],
        exclude: Tuple[str, ...],
    ) -> None:
        """指定された拡張子以外のファイルをコピーする

        Args:
            src_dir: コピー元ディレクトリ
            dest_dir: コピー先ディレクトリ
            exclude: 除外する拡張子のタプル

        Raises:
            OSError: ディレクトリ作成またはファイルコピーに失敗した場合
        """
        src_path = Path(src_dir)
        dest_path = Path(dest_dir)
        logger.debug(f"ファイルをコピー: {src_path} → {dest_path}")

        try:
            DirectoryUtil.ensure_directory(dest_path)

            for root, _, files in os.walk(src_path):
                rel_path = Path(root).relative_to(src_path)
                dest_sub_dir = dest_path / rel_path
                DirectoryUtil.ensure_directory(dest_sub_dir)

                for file in files:
                    if not any(file.lower().endswith(ext) for ext in exclude):
                        src_file = Path(root) / file
                        dest_file = dest_sub_dir / file
                        shutil.copy2(src_file, dest_file)
                        logger.debug(f"ファイルをコピー: {src_file} → {dest_file}")

        except (OSError, shutil.Error) as e:
            error_msg = f"ファイルのコピーに失敗: {str(e)}"
            logger.exception(error_msg)
            raise OSError(error_msg) from e
