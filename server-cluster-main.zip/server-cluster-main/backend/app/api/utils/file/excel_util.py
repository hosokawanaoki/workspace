import logging
import os
from typing import Any, Dict, List, Optional, Union

import pandas as pd
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from .directory_util import DirectoryUtil

logger = logging.getLogger(__name__)


class ExcelStyler:
    """Excelのスタイル設定を管理するクラス"""

    @staticmethod
    def create_header_style() -> dict:
        """ヘッダー用のスタイルを作成する

        Returns:
            dict: スタイル設定の辞書
        """
        return {
            "font": Font(bold=True, size=11),
            "fill": PatternFill(
                start_color="CCE5FF", end_color="CCE5FF", fill_type="solid"
            ),
            "alignment": Alignment(horizontal="center", vertical="center"),
            "border": Border(
                left=Side(style="thin"),
                right=Side(style="thin"),
                top=Side(style="thin"),
                bottom=Side(style="thin"),
            ),
        }

    @staticmethod
    def create_data_style() -> dict:
        """データ行用のスタイルを作成する

        Returns:
            dict: スタイル設定の辞書
        """
        return {
            "font": Font(size=10),
            "alignment": Alignment(horizontal="left", vertical="center"),
            "border": Border(
                left=Side(style="thin"),
                right=Side(style="thin"),
                top=Side(style="thin"),
                bottom=Side(style="thin"),
            ),
        }


class ExcelHandler:
    """Excelファイルを操作するためのハンドラークラス"""

    def __init__(self, file_path: Optional[str] = None):
        """
        Args:
            file_path: Excelファイルのパス（オプション）
        """
        self.file_path = file_path
        self.workbook = None
        if file_path and DirectoryUtil.check_path_exists(file_path):
            self.workbook = load_workbook(file_path)

    def create_new_workbook(self) -> None:
        """新しいワークブックを作成する"""
        self.workbook = Workbook()

    def save(self, file_path: Optional[str] = None) -> None:
        """ワークブックを保存する

        Args:
            file_path: 保存先のファイルパス（指定がない場合は初期化時のパスを使用）

        Raises:
            ValueError: ワークブックが存在しない場合
            OSError: ファイルの保存に失敗した場合
        """
        if not self.workbook:
            raise ValueError("No workbook exists")

        save_path = file_path or self.file_path
        if not save_path:
            raise ValueError("No file path specified")

        DirectoryUtil.ensure_directory(os.path.dirname(save_path))
        self.workbook.save(save_path)
        logger.info(f"Excelファイル保存完了: {save_path}")

    def apply_style_to_sheet(
        self,
        sheet_name: str,
        header_style: Optional[dict] = None,
        data_style: Optional[dict] = None,
    ) -> None:
        """シートにスタイルを適用する

        Args:
            sheet_name: スタイルを適用するシート名
            header_style: ヘッダー行のスタイル設定
            data_style: データ行のスタイル設定

        Raises:
            ValueError: 指定したシートが存在しない場合
        """
        if not self.workbook or sheet_name not in self.workbook.sheetnames:
            raise ValueError(f"Sheet '{sheet_name}' not found")

        sheet = self.workbook[sheet_name]
        header_style = header_style or ExcelStyler.create_header_style()
        data_style = data_style or ExcelStyler.create_data_style()

        # ヘッダー行にスタイルを適用
        for cell in sheet[1]:
            for key, style in header_style.items():
                setattr(cell, key, style)

        # データ行にスタイルを適用
        for row in sheet.iter_rows(min_row=2):
            for cell in row:
                for key, style in data_style.items():
                    setattr(cell, key, style)


def read_excel_to_df(
    excel_file_path: str,
    sheet_name: Union[int, str] = 0,
    header: int = 0,
    usecols: Optional[Union[str, List[str]]] = None,
    skiprows: Optional[Union[int, List[int]]] = None,
    dtype: Optional[Dict[str, Any]] = None,
    engine: str = "openpyxl",
) -> pd.DataFrame:
    """指定したExcelファイルを読み込み、DataFrameを返す

    Args:
        excel_file_path: 読み込むExcelファイルのパス
        sheet_name: 読み込むシート名または番号 (デフォルト=0: 最初のシート)
        header: ヘッダとして扱う行番号 (デフォルト=0: 最初の行をヘッダとする)
        usecols: 読み込む列を指定 (例: "A:C" や ["列名1", "列名2"] など)
        skiprows: スキップする行
        dtype: 列の型を指定
        engine: 読み込みに使うエンジン (デフォルト="openpyxl")

    Returns:
        pd.DataFrame: 読み込んだデータを格納したDataFrame

    Raises:
        FileNotFoundError: ファイルが存在しない場合
        pd.errors.EmptyDataError: データが空の場合
        ValueError: 読み込めない形式の場合
    """
    if not DirectoryUtil.check_path_exists(excel_file_path):
        raise FileNotFoundError(f"Excel file not found: {excel_file_path}")

    df = pd.read_excel(  # type: ignore
        excel_file_path,
        sheet_name=sheet_name,
        header=header,
        usecols=usecols,
        skiprows=skiprows,
        dtype=dtype,
        engine=engine,
    )

    logger.info(f"読み込んだDataFrameの列: {df.columns.tolist()}")
    logger.info(f"データ件数: {len(df)}")
    return df


def write_df_to_excel(
    df: pd.DataFrame,
    excel_file_path: str,
    sheet_name: str = "Sheet1",
    index: bool = False,
    apply_style: bool = True,
) -> None:
    """DataFrameをExcelファイルに書き込む

    Args:
        df: 書き込むDataFrame
        excel_file_path: 出力先のExcelファイルパス
        sheet_name: シート名 (デフォルト="Sheet1")
        index: インデックスを出力するかどうか (デフォルト=False)
        apply_style: スタイルを適用するかどうか (デフォルト=True)

    Raises:
        OSError: ファイルの書き込みに失敗した場合
    """
    try:
        # 出力ディレクトリの作成
        DirectoryUtil.ensure_directory(os.path.dirname(excel_file_path))

        # DataFrameをExcelに出力
        df.to_excel(
            excel_file_path,
            sheet_name=sheet_name,
            index=index,
            engine="openpyxl",
        )

        # スタイルの適用
        if apply_style:
            handler = ExcelHandler(excel_file_path)
            handler.apply_style_to_sheet(sheet_name)
            handler.save()

        logger.info(f"Excelファイル出力完了: {excel_file_path}")

    except Exception as e:
        error_msg = f"Excelファイルの出力に失敗: {str(e)}"
        logger.exception(error_msg)
        raise


def read_excel_row_by_key(
    excel_file_path: str,
    key_column: str,
    key_value: str,
    sheet_name: Union[int, str] = 0,
    header: int = 0,
    usecols: Optional[Union[str, List[str]]] = None,
    skiprows: Optional[Union[int, List[int]]] = None,
    dtype: Optional[Dict[str, Any]] = None,
    engine: str = "openpyxl",
) -> Optional[pd.Series]:
    """Excelファイルから指定したキーカラムと値に該当する行を取得する
    複数行が該当する場合は、最初の行を返す

    Args:
        excel_file_path: 読み込むExcelファイルのパス
        key_column: 検索に使用するキーカラム名
        key_value: 検索するキー値
        sheet_name: 読み込むシート名または番号 (デフォルト=0: 最初のシート)
        header: ヘッダとして扱う行番号 (デフォルト=0: 最初の行をヘッダとする)
        usecols: 読み込む列を指定 (例: "A:C" や ["列名1", "列名2"] など)
        skiprows: スキップする行
        dtype: 列の型を指定
        engine: 読み込みに使うエンジン (デフォルト="openpyxl")

    Returns:
        Optional[pd.Series]:
            - pd.Series: キー値に一致する行データ（複数行ある場合は最初の行）
            - None: キー値に一致するデータが存在しない場合

    Raises:
        ValueError: 指定したキーカラムが存在しない場合
        FileNotFoundError: ファイルが存在しない場合
        pd.errors.EmptyDataError: データが空の場合
    """
    # まずExcelを読み込み
    df = read_excel_to_df(
        excel_file_path,
        sheet_name=sheet_name,
        header=header,
        usecols=usecols,
        skiprows=skiprows,
        dtype=dtype,
        engine=engine,
    )

    # キーカラムをインデックスに設定
    if key_column not in df.columns:
        logger.error(f"指定のExcelに '{key_column}' カラムが存在しません。")
        logger.error(f"利用可能なカラム: {df.columns.tolist()}")
        raise ValueError(f"指定のExcelに '{key_column}' カラムが存在しません。")

    df.set_index(key_column, inplace=True)

    try:
        # 指定したキー値に該当する行を取得
        # key_valueを適切な型で扱う
        try:
            # 数値として変換を試みる
            numeric_key = int(key_value)
            row_data = df.loc[numeric_key]
        except ValueError:
            # 数値に変換できない場合は文字列として扱う
            row_data = df.loc[str(key_value)]

        # DataFrameの場合（複数行）は最初の行を返す
        if isinstance(row_data, pd.DataFrame):
            row_data = row_data.iloc[0]

        return row_data
    except KeyError:
        # 該当するキー値が見つからない場合はNoneを返す
        logger.info(
            f"{key_column} {key_value} に該当するデータが見つかりませんでした。"
        )
        return None
