import logging
from typing import List

import spacy

logger = logging.getLogger(__name__)


class TextChunkUtil:
    """テキストをチャンクに分割するユーティリティ"""

    # SpaCyモデルの初期化
    nlp = spacy.load("en_core_web_sm")

    @staticmethod
    def split_text(text: str, max_length: int) -> List[str]:
        """テキストを適切な長さのチャンクに分割する

        Args:
            text (str): 分割対象のテキスト
            max_length (int): チャンクの最大長

        Returns:
            List[str]: 分割されたチャンクのリスト
        """
        if not text:
            return []

        text = text.strip()
        if len(text) <= max_length:
            return [text]

        # まず文単位で分割を試みる
        segments = TextChunkUtil._split_by_sentences(text, max_length)

        # 必要に応じてトークン単位での分割
        result = []
        for segment in segments:
            if len(segment) > max_length:
                result.extend(TextChunkUtil._split_by_tokens(segment, max_length))
            else:
                result.append(segment)

        return TextChunkUtil._merge_segments(result, max_length)

    @staticmethod
    def split_text_lines(text_lines: List[str], max_length: int) -> List[str]:
        """テキスト行のリストをチャンクに分割する

        Args:
            text_lines (List[str]): 分割対象のテキスト行のリスト
            max_length (int): チャンクの最大長

        Returns:
            List[str]: 分割されたチャンクのリスト
        """
        chunks = []
        current_text = ""

        for line in text_lines:
            stripped_line = line.strip()
            if not stripped_line:
                continue

            # 一行が最大長を超える場合は個別に分割
            if len(stripped_line) > max_length:
                # 現在のテキストがある場合は、チャンクとして追加
                if current_text:
                    chunks.append(current_text)
                    current_text = ""

                # 長い行を分割して処理
                chunks.extend(TextChunkUtil.split_text(stripped_line, max_length))
            else:
                # 最大長以下の行は連結を試みる
                if current_text:
                    # 連結後のサイズをチェック
                    combined = current_text + "\n" + stripped_line
                    if len(combined) > max_length:
                        chunks.append(current_text)
                        current_text = stripped_line
                    else:
                        current_text = combined
                else:
                    current_text = stripped_line

        # 残りのテキストがある場合は、最後のチャンクとして追加
        if current_text:
            chunks.append(current_text)

        return chunks

    @staticmethod
    def _split_by_sentences(text: str, max_length: int) -> List[str]:
        """文単位での分割

        Args:
            text: 分割対象のテキスト
            max_length: 最大長

        Returns:
            List[str]: 分割された文のリスト
        """
        doc = TextChunkUtil.nlp(text)
        segments = []

        for sent in doc.sents:
            sent_text = sent.text.strip()
            if not sent_text:
                continue

            if len(sent_text) <= max_length:
                segments.append(sent_text)
            else:
                segments.extend(TextChunkUtil._split_by_tokens(sent_text, max_length))

        return segments

    @staticmethod
    def _split_by_tokens(text: str, max_length: int) -> List[str]:
        """トークン単位での分割

        Args:
            text: 分割対象のテキスト
            max_length: 最大長

        Returns:
            List[str]: 分割されたトークンのリスト
        """
        try:
            doc = TextChunkUtil.nlp(text)
            result = []
            current = ""

            for token in doc:
                token_text = token.text_with_ws
                if len(current) + len(token_text) <= max_length:
                    current += token_text
                else:
                    if current:
                        result.append(current.rstrip())
                    current = token_text

            if current.strip():
                result.append(current.strip())

            return result
        except Exception as e:
            logger.error(f"トークン分割でエラー: {str(e)}")
            return TextChunkUtil._fallback_split(text, max_length)

    @staticmethod
    def _merge_segments(segments: List[str], max_length: int) -> List[str]:
        """短いセグメントを結合する

        Args:
            segments: 結合対象のセグメント
            max_length: 最大長

        Returns:
            List[str]: 結合されたセグメント
        """
        result = []
        current = ""

        for segment in segments:
            combined = f"{current} {segment}".strip() if current else segment

            if len(combined) <= max_length:
                current = combined
            else:
                if current:
                    result.append(current)
                current = segment

        if current:
            result.append(current)

        return result

    @staticmethod
    def _fallback_split(text: str, max_length: int) -> List[str]:
        """フォールバックの分割処理

        Args:
            text: 分割対象のテキスト
            max_length: 最大長

        Returns:
            List[str]: 分割されたテキスト
        """
        result = []
        remaining = text

        while remaining:
            if len(remaining) <= max_length:
                result.append(remaining)
                break

            # 最大長で切り取り、最後の空白で分割
            part = remaining[:max_length]
            last_space = part.rfind(" ")

            if last_space == -1:
                # 空白が見つからない場合は強制的に分割
                result.append(part)
                remaining = remaining[max_length:]
            else:
                # 空白で分割
                result.append(part[:last_space])
                remaining = remaining[last_space + 1 :]

        return [r.strip() for r in result if r.strip()]
