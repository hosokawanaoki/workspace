import logging
from pathlib import Path
from typing import Callable, Dict, Optional, Union

import pandas as pd

logger = logging.getLogger(__name__)


def get_latest_file(
    directory: str | Path,
    pattern: str,
    sort_key: Callable[[Path], float] = lambda x: x.stat().st_mtime,
) -> Optional[Path]:
    """指定されたディレクトリから最新のファイルを取得する

    Args:
        directory: 検索対象のディレクトリパス
        pattern: ファイル名のパターン（例: "*.xlsx", "*.json"）
        sort_key: ファイルのソートキー関数（デフォルトは更新日時）

    Returns:
        Path: 最新のファイルパス、もしくはNone

    Examples:
        >>> # 更新日時で最新のExcelファイルを取得
        >>> latest_excel = get_latest_file("data", "*.xlsx")
        >>>
        >>> # 作成日時で最新のJSONファイルを取得
        >>> latest_json = get_latest_file("data", "*.json", lambda x: x.stat().st_ctime)
        >>>
        >>> # ファイルサイズで最大のCSVファイルを取得
        >>> largest_csv = get_latest_file("data", "*.csv", lambda x: x.stat().st_size)
    """
    try:
        directory_path = Path(directory)
        if not directory_path.exists():
            logger.warning(f"Directory not found: {directory}")
            return None

        files = list(directory_path.glob(pattern))
        if not files:
            logger.info(f"No files matching pattern '{pattern}' found in {directory}")
            return None

        return max(files, key=sort_key)

    except Exception as e:
        logger.error(f"Error finding latest file: {e}")
        return None


def get_latest_excel_file(
    directory: str | Path, pattern: str = "*.xlsx"
) -> Optional[Path]:
    """指定されたディレクトリから最新のExcelファイルを取得する

    Args:
        directory: 検索対象のディレクトリパス
        pattern: Excelファイル名のパターン（デフォルト: "*.xlsx"）

    Returns:
        Path: 最新のExcelファイルパス、もしくはNone
    """
    return get_latest_file(directory, pattern)


def get_latest_pref_excel_file(directory: Path, pref: str) -> Optional[Path]:
    """指定されたディレクトリからプレフィクスのある最新のExcelファイルを取得する

    Args:
        directory: 検索対象のディレクトリパス
        pref: ファイル名のプレフィクス（例: "book_"）

    Returns:
        Path: プレフィクスに一致する最新のExcelファイルパス、もしくはNone

    Examples:
        >>> # "book_"で始まる最新のExcelファイルを取得
        >>> latest_book = get_latest_pref_excel_file(Path("data"), "book_")
        >>> # "report_"で始まる最新のExcelファイルを取得
        >>> latest_report = get_latest_pref_excel_file(Path("reports"), "report_")
    """
    excel_files = list(directory.glob(pref + "*.xlsx"))
    return max(excel_files, default=None)


def write_dataframes_to_excel(
    sheets: Dict[str, pd.DataFrame], file_path: Union[str, Path], index: bool = False
) -> bool:
    """複数のDataFrameをExcelファイルの複数のシートに書き込む

    Args:
        sheets: シート名をキー、DataFrameを値とする辞書
        file_path: 保存先ファイルパス
        index: インデックスを書き込むかどうか (デフォルト: False)

    Returns:
        bool: 書き込みが成功したかどうか

    Examples:
        >>> # 2つのDataFrameを異なるシートに書き込む
        >>> df1 = pd.DataFrame({'A': [1, 2], 'B': [3, 4]})
        >>> df2 = pd.DataFrame({'X': [5, 6], 'Y': [7, 8]})
        >>> sheets = [
        ...     {'sheet_name': 'Sheet1', 'data': df1},
        ...     {'sheet_name': 'Sheet2', 'data': df2}
        ... ]
        >>> success = write_dataframes_to_excel(sheets, 'output.xlsx')
    """
    try:
        file_path = Path(file_path)
        file_path.parent.mkdir(parents=True, exist_ok=True)

        with pd.ExcelWriter(file_path, engine="openpyxl") as writer:
            for sheet_name, df in sheets.items():
                df.to_excel(writer, sheet_name=sheet_name, index=index)

        logger.info(f"Successfully wrote DataFrames to Excel file: {file_path}")
        return True

    except Exception as e:
        logger.error(f"Failed to write DataFrames to Excel: {e}")
        return False
