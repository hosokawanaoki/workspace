from datetime import datetime
from typing import Any, Dict, List

from langchain_community.chat_models.litellm import ChatLiteLLM
from langchain_core.messages import HumanMessage
from langchain_core.messages.base import BaseMessage
from litellm.exceptions import AuthenticationError, InvalidRequestError, RateLimitError

from ..exceptions.exceptions import LLMAuthenticationError, LLMValidationError
from ..interfaces.llm_chat_client import LLMChatClient
from ..interfaces.llm_config import LLMConfig
from ..models.llm_response import LLMResponse


class LiteLLMChatClient(LLMChatClient):
    """LiteLLMを使用したチャットクライアントの実装"""

    def __init__(self):
        """
        Note:
            APIキーは環境変数から自動的に取得されます：
            - Anthropicモデル → ANTHROPIC_API_KEY
            - Deepseekモデル → DEEPSEEK_API_KEY
            - OpenRouterモデル → OPENROUTER_API_KEY
        """
        self._chat_model = None

    def get_chat_response(
        self,
        messages: List[BaseMessage],
        config: LLMConfig,
        **kwargs: Dict[str, Any],
    ) -> LLMResponse:
        """チャット形式でLLMと対話する

        Args:
            messages: langchainのBaseMessageのリスト
            config: LLM設定
            **kwargs: その他のパラメータ

        Returns:
            LLMResponse: LLMからのレスポンス

        Raises:
            LLMAuthenticationError: 認証エラー（APIキー不正など）
            LLMRateLimitError: レート制限エラー
            LLMAPIError: API呼び出しエラー
            LLMTimeoutError: タイムアウトエラー
            LLMValidationError: 入力バリデーションエラー
        """
        if not config.model:
            raise LLMValidationError("モデルが設定されていません")

        try:
            # ChatLiteLLMを初期化（必要に応じて再利用）
            if (
                self._chat_model is None
                or self._chat_model.model_name != config.get_model_name()
            ):
                chat_params = {
                    "model": config.get_model_name(),
                    "temperature": config.get_temperature(),
                }

                # APIベースURLが設定されている場合は追加
                api_base = config.get_api_base()
                if api_base:
                    chat_params["api_base"] = api_base

                self._chat_model = ChatLiteLLM(**chat_params)

            # LangChainのインターフェースを使用してメッセージを送信
            response = self._chat_model.invoke(messages)

            return LLMResponse(
                content=response.content,
                model=config.get_model_name(),  # 実際のモデル名を使用
                created_at=datetime.now(),  # LangChainのレスポンスにはcreated_atがないため現在時刻を使用
                usage={},  # LangChainのレスポンスにはusage情報がないため空のdictを使用
            )

        except RateLimitError as e:
            raise LLMValidationError(f"APIのレートリミットに達しました: {str(e)}")
        except AuthenticationError as e:
            raise LLMAuthenticationError(f"APIキーが無効です: {str(e)}")
        except Exception as e:
            raise LLMValidationError(f"LLMとの通信に失敗しました: {str(e)}")

    def validate_api_key(self, config: LLMConfig) -> bool:
        """APIキーの有効性を検証します

        Args:
            config: LLMの設定

        Returns:
            bool: APIキーが有効な場合はTrue

        Raises:
            LLMAuthenticationError: 認証エラー
            LLMValidationError: APIキーが無効な場合
        """
        try:
            # テスト用のメッセージを作成
            test_messages = [HumanMessage(content="test")]
            chat_params = {"model": config.get_model_name()}
            api_base = config.get_api_base()
            if api_base:
                chat_params["api_base"] = api_base
            chat_model = ChatLiteLLM(**chat_params)
            chat_model.invoke(test_messages)
            return True
        except AuthenticationError as e:
            raise LLMAuthenticationError(f"APIキーが無効です: {str(e)}")
        except InvalidRequestError as e:
            raise LLMValidationError(f"APIキーの検証中にエラーが発生: {str(e)}")
        except Exception:
            return False
