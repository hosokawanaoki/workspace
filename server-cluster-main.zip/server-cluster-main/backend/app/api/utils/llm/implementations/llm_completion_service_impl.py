"""LLM Completion Serviceの実装"""

import logging

from api.utils.llm.exceptions.exceptions import LLMValidationError
from api.utils.llm.implementations.llm_config_impl import LLMConfigImpl
from api.utils.llm.interfaces.llm_completion_service import LLMCompletionService

logger = logging.getLogger(__name__)


class LLMCompletionServiceImpl(LLMCompletionService):
    """LLM Completion Serviceの実装クラス

    LLMの設定検証、プロンプトのフォーマット、モデルパラメータの取得を行う実装
    """

    def validate_config(self, config: LLMConfigImpl) -> None:
        """LLM設定の妥当性を検証する

        Args:
            config: 検証するLLM設定

        Raises:
            LLMValidationError: 設定が不正な場合
        """

        if not config.get_model_name():
            raise LLMValidationError("モデル名が設定されていません")

    def format_prompt(self, template: str, variables: list[dict[str, str]]) -> str:
        """プロンプトをフォーマットする

        Args:
            template: プロンプトテンプレート
            variables: 置換する変数の辞書のリスト

        Returns:
            str: フォーマットされたプロンプト

        Raises:
            LLMValidationError: プロンプトのフォーマットに失敗した場合
        """
        try:
            # 単純な文字列置換のみを行う
            result = template
            for var_dict in variables:
                if not isinstance(var_dict, dict):
                    continue
                for key, value in var_dict.items():
                    placeholder = "{" + key + "}"
                    result = result.replace(placeholder, str(value))
            return result
        except Exception as e:
            raise LLMValidationError(f"プロンプトのフォーマットに失敗: {e}")
