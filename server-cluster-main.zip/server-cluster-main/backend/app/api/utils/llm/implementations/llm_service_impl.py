import logging
from typing import List

from api.utils.llm.exceptions.exceptions import (
    LLMAPIError,
    LLMAuthenticationError,
    LLMRateLimitError,
    LLMTimeoutError,
    LLMValidationError,
)
from api.utils.llm.implementations.llm_chat_client_impl import LiteLLMChatClient
from api.utils.llm.implementations.llm_config_impl import LLMConfigImpl as LLMConfig
from api.utils.llm.interfaces.llm_completion_service import LLMCompletionService
from api.utils.llm.interfaces.llm_service import LLMService
from api.utils.llm.models.llm_response import LLMResponse
from api.utils.llm.models.prompt_type import PromptType
from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage

logger = logging.getLogger(__name__)


class LLMServiceImpl(LLMService):
    """LLMサービスの実装

    LLMクライアントを使用してメッセージの送信とレスポンスの取得を行います。
    エラーハンドリング、リトライ機能、メッセージのバリデーションを提供します。

    Attributes:
        config (LLMConfig): LLM設定
        completion_service (LLMCompletionService): Completion Service
        client (LiteLLMChatClient): LLMクライアント
    """

    def __init__(
        self,
        config: LLMConfig,
        completion_service: LLMCompletionService,
        client: LiteLLMChatClient,
    ):
        """初期化

        Args:
            config: LLM設定
            completion_service: Completion Service
            client: LLMクライアントインスタンス
        """
        self.config = config
        self.completion_service = completion_service
        self.client = client

    def update_config(self, model_name: str) -> None:
        """モデル名に基づいてLLM設定を更新する

        Args:
            model_name: 使用するモデル名（例: "claude-3-5-sonnet-20241022"）

        Raises:
            LLMValidationError: 設定が不正な場合
        """
        self.config.update_from_model_name(model_name)
        # 設定更新後にAPIキーの検証を行う
        self.completion_service.validate_config(self.config)

    def send_message(
        self,
        prompt_type: PromptType,
        variables: list[dict[str, str]] = [],
        model: str | None = None,
    ) -> LLMResponse:
        """指定されたプロンプトタイプに基づいてメッセージを送信し、レスポンスを取得する

        プロンプトのフォーマット、メッセージのバリデーション、エラーハンドリング、
        リトライ処理を行います。

        Args:
            prompt_type: プロンプトタイプ
            **kwargs: プロンプトテンプレートの変数値

        Returns:
            LLMResponse: LLMからのレスポンス

        Raises:
            LLMAuthenticationError: 認証エラー（APIキー不正など）
            LLMRateLimitError: レート制限エラー
            LLMAPIError: API呼び出しエラー
            LLMTimeoutError: タイムアウトエラー
            LLMValidationError: 入力バリデーションエラー
        """
        # モデルが指定されている場合は設定を更新
        if model:
            self.update_config(model)

        # 使用するモデル名をログ出力
        logger.info(f"使用モデル: {self.config.get_model_name()}")

        # テンプレートを取得
        template = self.config.get_prompt_template(prompt_type)
        if not template:
            raise LLMValidationError(
                f"プロンプトタイプ {prompt_type} のテンプレートが見つかりません"
            )

        # プロンプトのフォーマット
        formatted_prompt = self.completion_service.format_prompt(
            template=template.template, variables=variables
        )

        # フォーマット後のプロンプトをログ出力
        logger.debug(f"LLMに送信するプロンプト内容:\n{formatted_prompt}")

        # システムメッセージとユーザーメッセージを作成
        messages = [
            SystemMessage(content=template.system),
            HumanMessage(content=formatted_prompt),
        ]
        self._validate_messages(messages)

        return self._send_with_retry(messages)

    def _validate_messages(self, messages: List[BaseMessage]) -> None:
        """メッセージの妥当性を検証する

        Args:
            messages: 検証するメッセージのリスト

        Raises:
            LLMValidationError: メッセージが不正な場合
        """
        if not messages:
            raise LLMValidationError("メッセージリストが空です")

        for msg in messages:
            if not msg.content:
                raise LLMValidationError("メッセージの内容が空です")

            # メッセージ長の制限チェックを削除
            pass

    def _send_with_retry(self, messages: List[BaseMessage]) -> LLMResponse:
        """リトライ機能付きでメッセージを送信する

        Args:
            messages: メッセージのリスト

        Returns:
            LLMResponse: LLMからのレスポンス

        Raises:
            LLMAuthenticationError: 認証エラー
            LLMRateLimitError: レート制限エラー
            LLMAPIError: API呼び出しエラー
            LLMTimeoutError: タイムアウトエラー
        """
        retry_count = self.config.retry_count or 3
        last_error = None
        for attempt in range(retry_count):
            try:
                logger.debug(f"メッセージ送信試行 {attempt + 1}/{retry_count}")
                return self.client.get_chat_response(
                    messages=messages,
                    config=self.config,
                )

            except LLMRateLimitError as e:
                last_error = e
                logger.warning(f"レート制限エラー: {str(e)} - リトライします")

            except (LLMAPIError, LLMTimeoutError) as e:
                last_error = e
                logger.warning(f"一時的なエラー: {str(e)} - リトライします")

            except LLMAuthenticationError:
                # 認証エラーはリトライしない
                raise

            except Exception as e:
                logger.error(f"予期せぬエラー: {str(e)}")
                raise LLMAPIError(f"メッセージの送信に失敗: {str(e)}") from e

        # 全てのリトライが失敗
        logger.error(f"リトライ回数上限に到達: {str(last_error)}")
        raise last_error
