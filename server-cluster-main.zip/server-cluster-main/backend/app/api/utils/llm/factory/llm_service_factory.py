"""LLMServiceのファクトリモジュール"""

from api.utils.llm.implementations.llm_chat_client_impl import LiteLLMChatClient
from api.utils.llm.implementations.llm_completion_service_impl import (
    LLMCompletionServiceImpl,
)
from api.utils.llm.implementations.llm_config_impl import LLMConfigImpl
from api.utils.llm.implementations.llm_service_impl import LLMServiceImpl
from api.utils.llm.interfaces.llm_service import LLMService


class LLMServiceFactory:
    """LLMServiceを生成するファクトリクラス"""

    @staticmethod
    def create() -> LLMService:
        """LLMServiceのインスタンスを生成する

        Args:
            config: LLMの設定。指定がない場合はデフォルト設定を使用

        Returns:
            LLMService: 生成されたインスタンス
        """
        config = LLMConfigImpl()
        completion_service = LLMCompletionServiceImpl()
        chat_client = LiteLLMChatClient()
        return LLMServiceImpl(
            config=config,
            completion_service=completion_service,
            client=chat_client,
        )
