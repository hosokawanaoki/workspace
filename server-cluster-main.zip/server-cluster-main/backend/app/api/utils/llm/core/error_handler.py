import logging
from typing import Optional

from pydantic import BaseModel

logger = logging.getLogger(__name__)


class LLMErrorHandler(BaseModel):
    """LLMのエラー処理を担当するクラス"""

    def handle_llm_error(self, error: Exception) -> str:
        """LLMエラーを処理し、適切なエラーステータスを返す

        Args:
            error: 発生したエラー

        Returns:
            str: エラーステータス
        """
        error_message = str(error)
        logger.error(f"LLM error occurred: {error_message}", exc_info=error)

        # エラーの種類に応じたステータスを返す
        if "rate limit" in error_message.lower():
            return "rate-limit-error"
        elif "timeout" in error_message.lower():
            return "timeout-error"
        elif "token" in error_message.lower():
            return "token-error"
        else:
            return "llm-error"

    def format_error_message(
        self, error: Exception, request_id: Optional[str] = None
    ) -> str:
        """エラーメッセージを整形

        Args:
            error: 発生したエラー
            request_id: リクエストID

        Returns:
            str: 整形されたエラーメッセージ
        """
        error_message = str(error)
        if request_id:
            return f"LLM処理エラー (ID: {request_id}): {error_message}"
        return f"LLM処理エラー: {error_message}"
