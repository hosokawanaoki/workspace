import logging
from typing import Any, Dict, Optional

from langchain.memory import ConversationBufferWindowMemory
from pydantic import BaseModel

logger = logging.getLogger(__name__)


class LLMMemoryHandler(BaseModel):
    """LLMの会話履歴管理を担当するクラス"""

    window_size: int = 3
    _memory: Optional[ConversationBufferWindowMemory] = None

    def __init__(self, window_size: Optional[int] = None, **data: Any):
        """初期化処理

        Args:
            window_size: メモリウィンドウサイズ
            **data: その他のパラメータ
        """
        super().__init__(**data)
        if window_size is not None:
            self.window_size = window_size

        self._memory = ConversationBufferWindowMemory(
            k=self.window_size,
            memory_key="history",
            return_messages=True,
            input_key="input",
            output_key="output",
        )

    def save_context(self, inputs: Dict[str, Any], outputs: Dict[str, Any]) -> None:
        """コンテキストを保存

        Args:
            inputs: 入力データ
            outputs: 出力データ
        """
        if self._memory:
            self._memory.save_context(inputs, outputs)
            logger.debug("Saved context to memory")

    def load_memory_variables(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """メモリ変数を読み込む

        Args:
            inputs: 入力データ

        Returns:
            Dict[str, Any]: メモリ変数
        """
        if self._memory:
            return self._memory.load_memory_variables(inputs)
        return {}

    def clear(self) -> None:
        """メモリをクリア"""
        if self._memory:
            self._memory.clear()
            logger.debug("Cleared memory")
