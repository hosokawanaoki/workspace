"""
LLMに関する定数を定義するモジュール
"""

# LLMモデル関連
LLM = {
    "DEFAULT_MODEL": "claude",
    # モデルの定義（内部キー、表示名、実際のモデル名）
    "MODEL_MAPPINGS": {
        "claude": {
            "label": "Claude 3.5 Sonnet (In: $3/M, Out: $15/M)",
            "model_name": "claude-3-5-sonnet-20241022",
            "pattern_name": "claude",
        },
        "deepseek-chat": {
            "label": "deepseek (In: $0.2/M, Out: $0.4/M)",
            "model_name": "deepseek/deepseek-chat",
            "pattern_name": "deepseek",
        },
        "deepseek-reasoner": {
            "label": "deepseek-R1 (In: $0.55/M, Out: $2.1/M)",
            "model_name": "deepseek/deepseek-reasoner",
            "pattern_name": "deepseek",
        },
        "openai": {
            "label": "o3-mini (In: $1.1/M, Out: $4.4/M)",
            "model_name": "openai/o3-mini",
            "pattern_name": "openai",
        },
        "deepseek-or-chat": {
            "label": "DeepSeek V3(openrouter経由) (In: $0.5/M, Out: $0.9/M)",
            "model_name": "openrouter/deepseek/deepseek-chat",
            "pattern_name": "deepseek",
            "api_base": "https://openrouter.ai/api/v1",
        },
        "gemini": {
            "label": "Gemini Flash (In: $0.1/M, Out: $0.4/M)",
            "model_name": "gemini/gemini-2.0-flash",
            "pattern_name": "gemini",
        },
    },
}

# MODEL_MAPPINGSのキー一覧を利用可能なモデルとして設定
LLM["AVAILABLE_MODELS"] = list(LLM["MODEL_MAPPINGS"].keys())
