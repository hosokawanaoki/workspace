from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, Optional


@dataclass
class LLMResponse:
    """LLMレスポンスの構造体"""

    content: str
    model: str
    created_at: datetime
    usage: Optional[Dict[str, int]] = None
    metadata: Optional[Dict[str, Any]] = None
