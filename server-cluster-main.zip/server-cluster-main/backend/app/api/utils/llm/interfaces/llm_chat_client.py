"""LLMChatClient インターフェース"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List

from langchain_core.messages.base import BaseMessage

from api.utils.llm.interfaces.llm_config import LLMConfig
from api.utils.llm.models.llm_response import LLMResponse


class LLMChatClient(ABC):
    """LLMチャットクライアントのインターフェース"""

    @abstractmethod
    def get_chat_response(
        self,
        messages: List[BaseMessage],
        config: LLMConfig,
        **kwargs: Dict[str, Any],
    ) -> LLMResponse:
        """LLMとチャット形式で対話する

        Args:
            messages: langchainのBaseMessageのリスト
            config: LLMの設定
            **kwargs: その他のパラメータ

        Returns:
            LLMResponse: LLMからのレスポンス

        Raises:
            LLMAuthenticationError: 認証エラー（APIキー不正など）
            LLMRateLimitError: レート制限エラー
            LLMAPIError: API呼び出しエラー
            LLMTimeoutError: タイムアウトエラー
            LLMValidationError: 入力バリデーションエラー
        """
        pass

    @abstractmethod
    def validate_api_key(self, config: LLMConfig) -> bool:
        """APIキーの有効性を検証します

        Args:
            config: LLMの設定

        Returns:
            bool: APIキーが有効な場合はTrue

        Raises:
            LLMAuthenticationError: 認証エラー
            LLMValidationError: APIキーが無効な場合
        """
        pass
