"""LLM Completion Serviceのインターフェース"""

from abc import ABC, abstractmethod

from api.utils.llm.implementations.llm_config_impl import LLMConfigImpl


class LLMCompletionService(ABC):
    """LLM Completion Serviceのインターフェース

    LLMの設定検証とプロンプトのフォーマットを行うインターフェース
    """

    @abstractmethod
    def validate_config(self, config: LLMConfigImpl) -> None:
        """LLM設定の妥当性を検証する

        Args:
            config: 検証するLLM設定

        Raises:
            LLMValidationError: 設定が不正な場合
        """
        pass

    @abstractmethod
    def format_prompt(self, template: str, variables: list[dict[str, str]]) -> str:
        """プロンプトをフォーマットする

        Args:
            template: プロンプトテンプレート
            variables: 置換する変数の辞書のリスト

        Returns:
            str: フォーマットされたプロンプト

        Raises:
            LLMValidationError: プロンプトのフォーマットに失敗した場合
        """
        pass
