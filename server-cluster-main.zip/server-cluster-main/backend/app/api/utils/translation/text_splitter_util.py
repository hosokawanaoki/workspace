"""テキスト分割に関するユーティリティクラス"""

import logging
from datetime import datetime
from typing import List

from api.services.models.translation_target import TranslationTarget
from api.services.types.translator import (
    TranslationInfos,
    Translations,
    TranslationsData,
)
from api.utils.chunk.text_chunk_util import TextChunkUtil
from api.utils.llm.consts import LLM
from api.utils.llm.factory.llm_service_factory import LLMServiceFactory

logger = logging.getLogger(__name__)


class TextSplitterUtil:
    """テキスト分割に関するユーティリティクラス

    TextChunkUtilを使用してテキストの分割処理を行い、翻訳用のデータ構造を
    静的メソッドとして提供します。
    """

    @staticmethod
    def create_translations_from_chunks(
        chunks: List[str], target: TranslationTarget
    ) -> List[Translations]:
        """チャンクからTranslationsオブジェクトのリストを生成する

        Args:
            chunks (List[str]): 分割されたテキストチャンクのリスト
            target (TranslationTarget): 翻訳対象

        Returns:
            List[Translations]: 生成されたTranslationsオブジェクトのリスト
        """
        return [
            Translations(
                id=i + 1,
                source_text=chunk,
                line_number=i + 1,
                chunk_count=i + 1,
                chunk_max=len(chunks),
            )
            for i, chunk in enumerate(chunks)
        ]

    @staticmethod
    def create_chunks(
        lines: List[str], target: TranslationTarget
    ) -> tuple[List[Translations], int]:
        """テキストを翻訳可能な単位に分割する

        Args:
            lines (List[str]): 分割対象のテキスト行のリスト
            target (TranslationTarget): 翻訳対象

        Returns:
            tuple[List[Translations], int]: 分割されたテキストのリストとmax_length
        """
        # LLMServiceFactoryから設定を取得
        config = LLMServiceFactory.create().config
        model_list = config.get_model_list()

        # モデル名からパターン名を取得
        pattern_name = LLM["MODEL_MAPPINGS"][target.model]["pattern_name"]

        # パターン名を使って設定を取得
        pattern_config = model_list.get("model_patterns", {}).get(pattern_name)
        if not pattern_config:
            raise ValueError(f"パターン {pattern_name} の設定が見つかりません")

        max_length = pattern_config.get(
            "max_length", 2000
        )  # デフォルト値として2000を設定

        # テキスト行をチャンクに分割
        chunks = TextChunkUtil.split_text_lines(lines, max_length)

        # チャンクをTranslationsオブジェクトに変換
        translations = TextSplitterUtil.create_translations_from_chunks(chunks, target)
        return translations

    @staticmethod
    def prepare_chunks(lines: List[str], target: TranslationTarget) -> TranslationsData:
        """チャンク分割してTranslationsDataを作成する

        Args:
            lines: 分割対象のテキスト行のリスト
            target: 翻訳対象

        Returns:
            TranslationsData: チャンク分割されたデータ
        """
        logger.debug("テキスト分割開始")

        # チャンクの作成
        translations = TextSplitterUtil.create_chunks(lines, target)

        # TranslationInfosの作成
        translation_info = TranslationInfos(
            timestamp=datetime.now().isoformat(),
            model=target.model,
            book_id=target.book_id,
            batch_id=target.batch.id,
            id=target.book.id,
            total_chunks=len(translations),
            version=target.translation_version.version,
        )

        return TranslationsData(
            translation_info=translation_info,
            translations=translations,
        )
