import logging
from datetime import datetime
from typing import Optional

from api.models import Translation, TranslationVersion
from api.models.book import Book
from api.models.translation_version import TranslationVersionStatus
from api.services.common.logging_utils import (
    log_error_with_book_id,
    log_info_with_book_id,
)
from api.services.models.translation_target import TranslationTarget
from api.services.types.translator import (
    TranslationInfos,
    Translations,
    TranslationsData,
)
from django.db import transaction

logger = logging.getLogger(__name__)


class TranslationDataUtil:
    """翻訳データのDB操作を行うユーティリティクラス"""

    @staticmethod
    def load_existing_translations(
        target: TranslationTarget,
    ) -> Optional[TranslationsData]:
        """既存の翻訳データを読み込む

        Args:
            target: 翻訳対象

        Returns:
            Optional[TranslationsData]: 既存の翻訳データ
        """
        try:
            # targetから必要な情報を取得
            book = target.book
            version = target.translation_version

            # Translationを取得（line_idでソート）
            translations = (
                Translation.objects.filter(translation_version=version)
                .order_by("line_id")
                .all()
            )
            if not translations:
                return None

            # TranslationsDataを構築
            translations_list = [
                Translations(
                    id=t.id,
                    line_number=t.line_number,
                    chunk_count=t.chunk_count,
                    chunk_max=t.chunk_max,
                    source_text=t.source_text,
                    translated_text=t.translated_text,
                    tag_recoveried=t.tag_recoveried,
                    source_tags=t.source_tags,
                    translated_tags=t.translated_tags,
                    missing_tags=t.missing_tags,
                    extra_tags=t.extra_tags,
                    duplicate_tags=t.duplicate_tags,
                    error_count=0,
                    tag_error_count={},
                    status=t.status,
                )
                for t in translations
            ]

            translation_info = TranslationInfos(
                timestamp=datetime.now().isoformat(),
                model=target.batch.get_model,
                book_id=target.book_id,
                batch_id=target.batch.id,
                id=book.id,
                total_chunks=len(translations_list),
                version=version.version,
            )

            log_info_with_book_id(target.book_id, "既存の翻訳データを使用します")
            return TranslationsData(
                translation_info=translation_info,
                translations=translations_list,
            )

        except Exception as e:
            log_error_with_book_id(
                target.book_id, f"既存の翻訳データの読み込みに失敗: {str(e)}", e
            )
            return None

    @staticmethod
    def save_to_db(translation_data: TranslationsData) -> None:
        """翻訳結果をDBに保存

        Args:
            translation_data: 保存する翻訳データ
        """
        with transaction.atomic():
            # TranslationsDataからbook_idを使用してBookを取得
            book = Book.get(id=translation_data.translation_info.id)
            if not book:
                raise ValueError(
                    f"Book not found for database ID: {translation_data.translation_info.id}"
                )

            # TranslationInfosのversionを使用してレコードを取得または作成し、ステータスを更新
            version = TranslationVersion.get_or_create_version(
                book=book,
                version_number=translation_data.translation_info.version,
            )
            version.status = TranslationVersionStatus.TRANSLATED
            version.save()

            # 各翻訳データを更新または作成
            for trans in translation_data.translations:
                # 既存のTranslationを検索
                existing_translation = Translation.objects.filter(
                    translation_version=version,
                    line_id=trans.line_number,
                    target_language=translation_data.translation_info.target_language,
                ).first()

                if existing_translation:
                    # 既存のレコードがある場合は更新
                    existing_translation.line_number = trans.line_number
                    existing_translation.chunk_count = trans.chunk_count
                    existing_translation.chunk_max = trans.chunk_max
                    existing_translation.translated_text = trans.translated_text
                    existing_translation.tag_recoveried = trans.tag_recoveried
                    existing_translation.source_tags = trans.source_tags
                    existing_translation.translated_tags = trans.translated_tags
                    existing_translation.missing_tags = trans.missing_tags
                    existing_translation.extra_tags = trans.extra_tags
                    existing_translation.duplicate_tags = trans.duplicate_tags
                    existing_translation.status = trans.status
                    existing_translation.save()
                else:
                    # 新規レコードを作成
                    Translation.objects.create(
                        translation_version=version,
                        line_id=trans.line_number,  # line_numberをline_idとして使用
                        target_language=translation_data.translation_info.target_language,
                        line_number=trans.line_number,
                        chunk_count=trans.chunk_count,
                        chunk_max=trans.chunk_max,
                        source_text=trans.source_text,
                        translated_text=trans.translated_text,
                        tag_recoveried=trans.tag_recoveried,
                        source_tags=trans.source_tags,
                        translated_tags=trans.translated_tags,
                        missing_tags=trans.missing_tags,
                        extra_tags=trans.extra_tags,
                        duplicate_tags=trans.duplicate_tags,
                        status=trans.status,
                    )
