import logging
from datetime import timedelta
from typing import List

from api.constants.constants import STALL_THRESHOLD_MINUTES
from api.models.book import Book
from api.models.translation_version import TranslationVersion
from api.services.models.translation_target import TranslationTarget
from api.services.types.stalled_batch import StalledBatchInfo
from django.utils import timezone

logger = logging.getLogger(__name__)


class StalledBatchUtil:
    """停止したバッチの処理を管理するユーティリティクラス"""

    @classmethod
    def detect_stalled_batches(cls) -> List[StalledBatchInfo]:
        """停止している可能性のあるバッチを検出する

        Returns:
            List[StalledBatchInfo]: 停止している可能性のあるバッチのリスト
        """
        current_time = timezone.now()
        stall_threshold = current_time - timedelta(minutes=STALL_THRESHOLD_MINUTES)

        # AI実行中のステータスで、一定時間以上更新がないものを検出
        stalled_books = (
            Book.objects.filter(
                status=Book.get_status_type("ai-execution"),
                translationbatch__updated_at__lt=stall_threshold,
            )
            .prefetch_related("translationbatch_set", "translationversion_set")
            .distinct()
        )

        stalled_batches = []
        for book in stalled_books:
            latest_batch = book.translationbatch_set.latest("updated_at")
            if latest_batch:
                version = TranslationVersion.get_versions_by_book(book.book_id)[0]
                stalled_batches.append(
                    {
                        "book": book,
                        "batch": latest_batch,
                        "version": version,
                    }
                )

        return stalled_batches

    @classmethod
    def process_stalled_batch(cls, stalled_batch: StalledBatchInfo) -> None:
        """停止したバッチを処理する

        Args:
            stalled_batch (StalledBatchInfo): 停止したバッチの情報
        """
        try:
            target = TranslationTarget(stalled_batch["book"], stalled_batch["batch"])
            if not target.has_reached_max_retries():
                target.update_retry_count()
            else:
                target.mark_as_error()

        except Exception as e:
            logger.error(
                f"書籍 {stalled_batch['book'].book_id} のステータス更新に失敗: {str(e)}"
            )
