import logging

from api.models.translation import Translation
from api.services.common.file_path_util.translation_paths import TranslationPaths
from api.services.models.translation_target import TranslationTarget
from api.utils.file.file_util import FileUtil

logger = logging.getLogger(__name__)


class TranslationProcessUtil:
    """翻訳プロセスに関連するユーティリティクラス"""

    @staticmethod
    def validate_translation_result(
        target: TranslationTarget, process_type: str
    ) -> None:
        """翻訳/校正結果の検証

        Args:
            target (TranslationTarget): 翻訳対象
            process_type (str): 処理タイプ（'翻訳'または'校正'）

        Raises:
            ValueError: 結果ファイルが見つからない場合
        """
        json_path = TranslationPaths.get_translation_json_path(target.book_id)
        if not FileUtil.check_file_exists(json_path):
            error_msg = f"{process_type}結果ファイルが見つかりません: {json_path}"
            logger.error(error_msg)
            target.batch.status_message = f"エラー: {error_msg}"
            target.batch.save(update_fields=["status_message"])
            raise ValueError(error_msg)

    @staticmethod
    def handle_process_error(
        target: TranslationTarget, process_type: str, error: Exception
    ) -> None:
        """エラーハンドリングとステータス更新

        Args:
            target (TranslationTarget): 翻訳対象
            process_type (str): 処理タイプ（'翻訳'または'校正'）
            error (Exception): 発生したエラー
        """
        error_msg = f"{process_type}実行中にエラーが発生: {str(error)}"
        logger.error(error_msg)
        target.batch.status_message = f"エラー: {error_msg}"
        target.batch.save(update_fields=["status_message"])

    @staticmethod
    def update_translation_status(target: TranslationTarget) -> None:
        """翻訳ステータスの更新

        Args:
            target (TranslationTarget): 翻訳対象
        """
        # 翻訳の統計情報を取得
        tag_error_count, untranslated_count, error_line_count, total_count = (
            Translation.get_translation_stats_by_version(target.translation_version)
        )

        # 未翻訳の有無を確認
        if untranslated_count > 0:
            target.book.set_status("translating")
            target.batch.status_message = (
                f"{total_count - untranslated_count}/{total_count} 翻訳済み"
            )
            target.batch.set_status("completed")
            target.batch.save(update_fields=["status_message"])
            logger.info("ステータスを'translating'に更新")
            return

        # タグエラーの有無に基づいてステータスを更新
        if tag_error_count == 0:
            target.book.set_status("translated")
            target.batch.status_message = ""
            logger.info("ステータスを'translated'に更新")
        else:
            target.book.set_status("tag-error")
            target.batch.status_message = f"{error_line_count} タグエラー"
            logger.info("ステータスを'tag-error'に更新")

        target.batch.set_status("completed")
        target.batch.save(update_fields=["status_message"])
