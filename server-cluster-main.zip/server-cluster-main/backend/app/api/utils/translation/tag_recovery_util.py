"""タグ復元に関するユーティリティ関数"""

import logging
import re
from typing import List, Optional, Tuple

from api.constants.constants import TRANSLATION
from api.services.common.text_util.tag_validator_util import TagValidatorUtil
from api.services.models.translation_target import TranslationTarget
from api.services.types.translator import Translations, TranslationStatus
from api.utils.llm.factory.llm_service_factory import LLMServiceFactory
from api.utils.llm.interfaces.llm_service import LLMService
from api.utils.llm.models.prompt_type import PromptType

logger = logging.getLogger(__name__)


def get_duplicate_tag_instruction(duplicate_tags: List[str]) -> str:
    """重複タグ修正のための指示文を生成する"""
    tags_text = " ".join(duplicate_tags)
    return """
    - 以下の重複タグを修正してください：
        {tags_text}
    - 重複しているタグを削除し、適切な位置に1つのタグを残してください
    - タグの順序を維持してください
    """.format(tags_text=tags_text)


def get_missing_tag_instruction(missing_tags: List[str]) -> str:
    """欠損タグ修正のための指示文を生成する"""
    tags_text = " ".join(missing_tags)
    return """
    - 以下の欠損タグを適切な位置に追加してください：
        {tags_text}
    - 既に存在する文章から、タグにする部分を選んでください。
    """.format(tags_text=tags_text)


def remove_extra_tags(
    text: Optional[str], extra_tags: Optional[List[str]], book_id: str
) -> str:
    """余分なタグを削除する"""
    if not text or not extra_tags:
        return text or ""

    logger.info(f"書籍ID {book_id}: 以下のタグを削除：{' '.join(extra_tags)}")

    for tag in extra_tags:
        text = re.sub(re.escape(tag), "", text)

    return text


def get_tag_instructions(recovery: Translations, book_id: str) -> Tuple[str, bool]:
    """タグの修正指示を取得する"""
    instructions = []
    modified = False

    if recovery.duplicate_tags:
        logger.info(
            f"書籍ID {book_id}: 以下の重複タグを修正：{' '.join(recovery.duplicate_tags)}"
        )
        instructions.append(get_duplicate_tag_instruction(recovery.duplicate_tags))
        modified = True

    if recovery.missing_tags:
        logger.info(
            f"書籍ID {book_id}: 以下のタグを修復：{' '.join(recovery.missing_tags)}"
        )
        instructions.append(get_missing_tag_instruction(recovery.missing_tags))
        modified = True

    return "\n".join(instructions), modified


def log_tag_recovery_result(
    book_id: str,
    attempt: int,
    current_score: int,
    best_score: int,
    recovery: Translations,
    combined_instruction: str,
    is_changed: bool,
) -> None:
    """タグ修復の結果をログ出力する"""
    logger.debug(
        f"タグ修復の結果:\n"
        f"修正後: {recovery.tag_recoveried}\n"
        f"指示内容: {combined_instruction}\n"
        f"欠損タグ: {recovery.missing_tags}\n"
        f"余分タグ: {recovery.extra_tags}\n"
        f"重複タグ: {recovery.duplicate_tags}"
    )

    logger.info(
        f"書籍ID {book_id}: スコアの比較: 新スコア {current_score} vs 最良スコア {best_score}\n"
        f"テキストの変更: {'変更あり' if is_changed else '変更なし'}"
    )


def attempt_tag_recovery(
    recovery: Translations,
    target: TranslationTarget,
    tag_recoveried: str,
    attempt: int,
    llm_service: LLMService,
) -> Tuple[str, int, bool]:
    """1回分のタグ修復を試行する"""
    # プロンプト送信前の余分なタグ削除
    tag_recoveried = remove_extra_tags(
        tag_recoveried, recovery.extra_tags, target.book_id
    )

    # タグの修正指示を取得
    combined_instruction, _ = get_tag_instructions(recovery, target.book_id)

    # タグ修復パラメータの準備
    recovery_params = {
        "source_text": recovery.source_text,
        "translated_text": tag_recoveried,
        "instruction": combined_instruction,
    }

    # タグ修復APIを呼び出す
    logger.info(f"書籍ID {target.book_id}: タグ修復API実行（試行回数: {attempt + 1}）")

    response = llm_service.send_message(
        prompt_type=PromptType.TAG_RECOVERY,
        variables=[recovery_params],  # 辞書をリストとして渡す
        model=target.batch.get_model,
    )
    recovery.tag_recoveried = response.content

    # APIレスポンス後の余分なタグ削除
    recovery.tag_recoveried = remove_extra_tags(
        recovery.tag_recoveried, recovery.extra_tags, target.book_id
    )

    # APIレスポンス後のタグ状態を評価
    TagValidatorUtil.validate_translation_tags(recovery)
    current_score = TagValidatorUtil.evaluate_tag_state(recovery)

    return recovery.tag_recoveried, current_score, combined_instruction


def update_best_result(
    recovery: Translations,
    target: TranslationTarget,
    current_score: int,
    best_score: int,
    attempt: int,
) -> Tuple[str, int]:
    """最良の結果を更新する"""
    if current_score == 0:
        logger.info(
            f"書籍ID {target.book_id}: タグの修復が完了しました（試行回数: {attempt + 1}）"
        )
        return recovery.tag_recoveried, current_score

    if current_score < best_score:
        logger.info(
            f"書籍ID {target.book_id}: タグの不一致が残っています（試行回数: {attempt + 1}）\n"
            f"- 欠損タグ: {recovery.missing_tags}\n"
            f"- 余分タグ: {recovery.extra_tags}\n"
            f"- 重複タグ: {recovery.duplicate_tags}\n"
            f"- 現在のスコア: {current_score}（最良スコア: {best_score}）"
        )
        return recovery.tag_recoveried, current_score
    else:
        logger.info(
            f"書籍ID {target.book_id}: タグの状態が改善されませんでした（試行回数: {attempt + 1}）"
        )
        return None, best_score


def recover_tags(
    recovery: Translations,
    target: TranslationTarget,
) -> Translations:
    """タグを修復する

    Args:
        recovery: 修復対象の翻訳データ
        target: 翻訳対象

    Returns:
        Translations: タグ修復後の翻訳データ
    """
    if recovery.status != TranslationStatus.PROCESSED:
        return recovery

    # LLMServiceを作成（ループ外で1回だけ）
    llm_service = LLMServiceFactory.create()

    tag_recoveried = recovery.translated_text
    best_result = tag_recoveried
    recovery.tag_recoveried = tag_recoveried

    # 初回のタグ状態チェック
    has_no_tag_errors = TagValidatorUtil.validate_translation_tags(recovery)
    if has_no_tag_errors:
        logger.debug(f"書籍ID {target.book_id}: タグの修復は不要です（タグエラーなし）")
        recovery.status = TranslationStatus.TAG_RECOVERED
        return recovery

    best_score = TagValidatorUtil.evaluate_tag_state(recovery)
    max_attempts = TRANSLATION["MAX_ATTEMPTS"]

    for attempt in range(max_attempts):
        # キャンセル状態をチェック
        target.handle_cancellation()

        # タグ修復を試行
        new_text, current_score, instruction = attempt_tag_recovery(
            recovery,
            target,
            tag_recoveried,
            attempt,
            llm_service,
        )

        # 結果をログ出力
        log_tag_recovery_result(
            target.book_id,
            attempt,
            current_score,
            best_score,
            recovery,
            instruction,
            new_text != tag_recoveried,
        )

        # 最良の結果を更新
        result, new_score = update_best_result(
            recovery, target, current_score, best_score, attempt
        )
        if result:
            best_result = result
            best_score = new_score
            if best_score == 0:
                break
        tag_recoveried = best_result

    logger.info(
        f"書籍ID {target.book_id}: タグ修復を終了します（最終試行回数: {attempt + 1}）"
    )

    # 最終的な結果を設定
    recovery.tag_recoveried = best_result
    recovery.status = TranslationStatus.TAG_RECOVERED

    # 最終的なタグの状態をチェック
    has_no_tag_errors = TagValidatorUtil.validate_translation_tags(recovery)
    final_score = TagValidatorUtil.evaluate_tag_state(recovery)

    logger.info(
        f"書籍ID {target.book_id}: 最終的なタグの状態: スコア {final_score} {'(エラーなし)' if has_no_tag_errors else '(エラーあり)'}"
    )

    return recovery
