"""校正バッチサービスのインターフェース"""

from abc import ABC, abstractmethod
from typing import TypedDict


class BatchCreationResult(TypedDict):
    """バッチ作成結果の型定義"""

    version_id: str
    batch_id: str


class CorrectionBatchService(ABC):
    """校正バッチサービスのインターフェース"""

    @abstractmethod
    def create_batch(
        self,
        book_id: str,
        version_name: str,
        correction_instruction: str,
        model: str,
    ) -> BatchCreationResult:
        """新しい校正バッチを作成する

        Args:
            book_id: 書籍ID
            version_name: バージョン名
            correction_instruction: 校正指示
            model: 使用するモデル

        Returns:
            BatchCreationResult: 作成されたバッチの情報

        Raises:
            ValueError: パラメータが不正な場合
            RuntimeError: バッチ作成に失敗した場合
        """
        pass
