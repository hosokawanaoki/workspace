"""書籍バッチサービスのインターフェース"""

from abc import ABC, abstractmethod
from typing import List, Optional, TypedDict

from api.models.book import Book


class BatchCreationResult(TypedDict):
    """バッチ作成結果の型定義"""

    batch_id: str
    version_id: str


class BookBatchService(ABC):
    """書籍バッチサービスのインターフェース"""

    @abstractmethod
    def create_batch(
        self,
        book_id: str,
        version_name: str,
        model: str,
        limit: Optional[int] = None,
    ) -> BatchCreationResult:
        """翻訳バッチを作成する

        Args:
            book_id: 書籍ID
            version_name: バージョン名
            model: 使用するモデル
            limit: 翻訳制限数（オプション）

        Returns:
            BatchCreationResult: 作成されたバッチの情報

        Raises:
            ValueError: パラメータが不正な場合
            RuntimeError: バッチ作成に失敗した場合
        """
        pass

    @abstractmethod
    def cancel_translation(self, book_id: str) -> None:
        """翻訳をキャンセルする

        Args:
            book_id: 書籍ID

        Raises:
            ValueError: パラメータが不正な場合
            RuntimeError: キャンセルに失敗した場合
        """
        pass

    @abstractmethod
    def repair_translation(self, book_id: str) -> None:
        """翻訳を修復する

        Args:
            book_id: 書籍ID

        Raises:
            ValueError: パラメータが不正な場合
            RuntimeError: 修復に失敗した場合
        """
        pass

    @abstractmethod
    def get_all_books_with_batch(self) -> List[Book]:
        """バッチ情報付きの全書籍を取得する

        Returns:
            List[Book]: バッチ情報付きの書籍リスト
        """
        pass
