"""書籍リポジトリの実装"""

import logging

from api.models.book import Book
from api.services.book.interfaces.book_repository import BookRepository
from django.db.models import QuerySet

logger = logging.getLogger(__name__)


class BookRepositoryImpl(BookRepository):
    """書籍リポジトリの実装クラス

    Bookモデルとの相互作用を行います。
    """

    def __init__(self):
        """初期化"""
        pass

    def has_executing_books(self) -> bool:
        """AI実行中の書籍が存在するかチェックする

        AI翻訳の実行状態をチェックし、現在実行中の書籍が存在するかどうかを判定します。
        これは新しい翻訳タスクを開始する前の事前チェックとして使用されます。

        Returns:
            bool: AI実行中の書籍が存在する場合はTrue、存在しない場合はFalse
        """
        executing_status = Book.get_status_type("ai-execution")
        executing_exists = Book.exists_by_status(executing_status)
        if executing_exists:
            logger.info("AI実行中の書籍が存在します")
        return executing_exists

    def get_waiting_books(self) -> QuerySet:
        """翻訳待ちの書籍を取得する

        翻訳待ち状態の書籍を、関連する翻訳バッチ情報と共に取得します。
        取得された書籍は翻訳キューに追加される候補となります。

        Returns:
            QuerySet: 翻訳待ち状態の書籍のクエリセット
                     - status="waiting"の書籍のみ
                     - translationbatch_setが事前に結合済み
                     - 論理削除された書籍は除外
        """
        waiting_status = Book.get_status_type("waiting")
        waiting_books = Book.filter(
            prefetch_fields=["translationbatch_set"],
            status=waiting_status,
        )
        logger.debug(f"翻訳待ちの書籍数: {waiting_books.count()}")
        return waiting_books

    def update_book_status(self, book_id: str, status: str) -> None:
        """書籍のステータスを更新する

        Args:
            book_id: 更新対象の書籍ID
            status: 設定する新しいステータス

        Raises:
            Book.DoesNotExist: 指定されたIDの書籍が存在しない場合
            ValueError: 不正なステータスが指定された場合
        """
        try:
            validated_status = Book.get_status_type(status)
            Book.update_status(book_id, validated_status)
            logger.info(f"書籍 {book_id} のステータスを {status} に更新しました")
        except Exception as e:
            logger.error(f"書籍 {book_id} のステータス更新に失敗しました: {str(e)}")
            raise
