from typing import TypedDict


class GutenbergBookInfo(TypedDict):
    """Gutenbergから取得する書籍情報の型定義"""

    title: str
    author: str
    language: str
    downloads: int
    copyright_status: str
    subject: str
    summary: str
    url: str
    original_id: str


class LLMBookInfo(TypedDict):
    """LLMから取得する書籍情報の型定義"""

    title_jp: str


class CombinedBookInfo(TypedDict):
    """スクレイピングとLLMの情報を結合した書籍情報の型定義"""

    title: str
    title_jp: str
    author: str
    language: str
    downloads: int
    copyright_status: str
    subject: str
    summary: str
    url: str
    original_id: str
