from typing import TypedDict

from api.models.book import Book
from api.models.translation_batch import TranslationBatch
from api.models.translation_version import TranslationVersion


class StalledBatchInfo(TypedDict):
    """停止したバッチの情報を表す型"""

    book_id: str
    title: str
    batch_time: str
    elapsed_time: int
    book: Book
    batch: TranslationBatch
    version: TranslationVersion
