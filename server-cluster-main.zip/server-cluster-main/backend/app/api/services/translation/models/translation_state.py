from dataclasses import dataclass
from typing import List, Optional, Tuple

from api.services.common.logging_utils import log_debug_with_book_id
from api.services.translation.models.translator_config import TranslatorConfig
from api.services.types.translator import Translations, TranslationStatus


@dataclass
class TranslationState:
    """翻訳状態を管理するクラス

    チャンクの管理と進捗の管理を一元的に行います。

    Attributes:
        chunks (List[Translations]): 翻訳対象のチャンクリスト
        config (TranslatorConfig): 翻訳設定
        current_index (int): 現在処理中のインデックス
    """

    chunks: List[Translations]
    config: TranslatorConfig
    current_index: int = -1

    def validate(self) -> None:
        """状態のバリデーションを行う

        Raises:
            ValueError: 状態が不正な場合
        """
        if not self.chunks:
            raise ValueError("翻訳対象のチャンクが空です")
        if not self.config:
            raise ValueError("翻訳設定が不正です")

    def get_next_chunk(self) -> Optional[Translations]:
        """次の未翻訳チャンクを取得する

        Returns:
            Optional[Translations]: 次のチャンク。なければNone
        """
        for i, chunk in enumerate(self.chunks):
            if chunk.status < TranslationStatus.PROCESSED:
                self.current_index = i
                log_debug_with_book_id(
                    str(chunk.id),
                    f"次の翻訳対象: チャンク {i}（ステータス: {chunk.status}）",
                )
                return chunk
            log_debug_with_book_id(
                str(chunk.id),
                f"チャンク {i} は既に翻訳済み（ステータス: {chunk.status}）のためスキップします",
            )
        return None

    def mark_chunk_complete(self, index: int) -> None:
        """チャンクを完了としてマーク

        Args:
            index (int): 完了したチャンクのインデックス
        """
        self.chunks[index].status = TranslationStatus.PROCESSED

    def get_surrounding_chunks(self) -> Tuple[Optional[str], Optional[str]]:
        """現在のチャンクの前後のテキストを取得

        Returns:
            Tuple[Optional[str], Optional[str]]: (前のチャンク, 次のチャンク)
        """
        prev_text = None
        next_text = None

        if self.current_index > 0:
            prev_chunk = self.chunks[self.current_index - 1]
            # 翻訳済みの場合は翻訳テキスト、そうでない場合はソーステキストを使用
            prev_text = (
                prev_chunk.translated_text
                if prev_chunk.status >= TranslationStatus.PROCESSED
                else prev_chunk.source_text
            )

        if self.current_index < len(self.chunks) - 1:
            next_chunk = self.chunks[self.current_index + 1]
            next_text = next_chunk.source_text

        return prev_text, next_text

    def get_progress(self) -> Tuple[int, int]:
        """進捗状況を取得

        Returns:
            Tuple[int, int]: (処理済み数, 全体数)
        """
        processed_count = len(
            [
                chunk
                for chunk in self.chunks
                if chunk.status >= TranslationStatus.PROCESSED
            ]
        )
        return processed_count, len(self.chunks)

    def is_complete(self) -> bool:
        """翻訳が完了しているか確認

        Returns:
            bool: すべてのチャンクが翻訳済みの場合True
        """
        return all(chunk.status >= TranslationStatus.PROCESSED for chunk in self.chunks)
