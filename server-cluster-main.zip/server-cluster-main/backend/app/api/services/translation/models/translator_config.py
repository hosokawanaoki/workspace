from dataclasses import dataclass

from api.models.translation_setting import TranslationSetting


@dataclass
class TranslatorConfig:
    """翻訳の設定を管理するクラス"""

    text_type: int = 1  # デフォルトの翻訳パターン
    restrictions: str = ""
    sample: str = ""
    correction_instruction: str = ""  # 校正指示

    @staticmethod
    def generate_prompt_from_setting(setting: TranslationSetting) -> tuple[str, str]:
        """翻訳設定からプロンプトを生成する

        Args:
            setting (TranslationSetting): 翻訳設定

        Returns:
            tuple[str, str]: (制約テキスト, サンプルテキスト)
        """
        # 制約を設定
        constraints = setting.constraints if setting.constraints else ""

        # サンプルを設定
        if setting.examples:
            sample_texts = []
            for i, example in enumerate(setting.examples, 1):
                sample_texts.extend(
                    [
                        f"例{i}:",
                        "翻訳前例:",
                        f"　{example['before']}",
                        "翻訳後例:",
                        f"　{example['after']}",
                        "",  # 空行を追加
                    ]
                )
            sample = "\n".join(sample_texts).rstrip()  # 最後の空行を削除
        else:
            sample = ""

        return constraints, sample
