class TranslationError(Exception):
    """翻訳処理に関連するエラーの基底クラス"""

    pass


class FileProcessingError(TranslationError):
    """ファイル処理に関連するエラー"""

    pass
