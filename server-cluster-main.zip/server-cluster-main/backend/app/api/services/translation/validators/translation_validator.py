import logging

from api.services.common.logging_utils import (
    log_error_with_book_id,
    measure_performance,
)
from api.services.models.translation_target import TranslationTarget

# ロガーの設定
logger = logging.getLogger(__name__)


class TranslationValidator:
    """翻訳設定のバリデーションを行うクラス"""

    @staticmethod
    @measure_performance
    def validate_config(target: TranslationTarget) -> None:
        """翻訳設定のバリデーション

        Args:
            config: 翻訳設定

        Raises:
            ValueError: 翻訳設定が不正な場合
        """
        if not target:
            log_error_with_book_id(0, "翻訳設定がNoneです")
            raise ValueError("翻訳設定がNoneです")

        book_id = target.book_id or 0

        if not target.book.book_id:
            log_error_with_book_id(book_id, "book_idが設定されていません")
            raise ValueError("book_idが設定されていません")

        if not target.batch.model:
            log_error_with_book_id(book_id, "modelが設定されていません")
            raise ValueError("modelが設定されていません")

        if target.batch.limit <= 0:
            log_error_with_book_id(book_id, "limitは1以上の値を設定してください")
            raise ValueError("limitは1以上の値を設定してください")
