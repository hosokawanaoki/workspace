"""TagReplacerインターフェース"""

from abc import ABC, abstractmethod


class TagReplacer(ABC):
    """タグ置換処理のインターフェース"""

    @abstractmethod
    def replace_tags(self, text: str) -> tuple[str, dict[str, str]]:
        """テキスト内のタグを一時的なプレースホルダーに置換する

        Args:
            text (str): 処理対象のテキスト

        Returns:
            tuple[str, dict[str, str]]:
                - 置換後のテキスト
                - タグとプレースホルダーのマッピング
        """
        pass

    @abstractmethod
    def restore_tags(self, text: str, tag_map: dict[str, str]) -> str:
        """プレースホルダーを元のタグに戻す

        Args:
            text (str): 処理対象のテキスト
            tag_map (dict[str, str]): タグとプレースホルダーのマッピング

        Returns:
            str: 復元後のテキスト
        """
        pass
