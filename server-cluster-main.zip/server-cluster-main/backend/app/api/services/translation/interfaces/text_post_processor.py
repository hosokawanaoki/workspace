from abc import ABC, abstractmethod
from typing import Tuple

from api.services.models.translation_target import TranslationTarget


class TextPostProcessor(ABC):
    """テキスト後処理のインターフェース"""

    @abstractmethod
    def process(self, target: TranslationTarget) -> Tuple[str, str]:
        """テキストの後処理を実行する

        Args:
            target (TranslationTarget): 翻訳対象

        Returns:
            Tuple[str, str]: 処理結果のURL、ファイルパス

        Raises:
            Exception: 処理中にエラーが発生した場合
        """
        pass
