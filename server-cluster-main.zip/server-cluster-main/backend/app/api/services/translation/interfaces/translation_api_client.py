"""翻訳APIクライアントのインターフェースを定義するモジュール"""

from abc import ABC, abstractmethod

from api.utils.llm.interfaces.llm_service import LLMService


class TranslationApiClient(ABC):
    """翻訳APIクライアントのインターフェース"""

    @abstractmethod
    def __init__(self, llm_service: LLMService, model: str) -> None:
        """初期化

        Args:
            llm_service: LLMサービス
            model: 使用するモデル
        """
        pass

    @abstractmethod
    def translate_chunk(self, chunk: str, *args, **kwargs) -> None:
        """チャンクを翻訳する

        Args:
            chunk: 翻訳対象のチャンク
        """
        pass
