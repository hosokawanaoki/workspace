"""TranslationStateManager インターフェース"""

from abc import ABC, abstractmethod
from typing import Dict, Optional


class TranslationStateManager(ABC):
    """翻訳状態管理のインターフェース"""

    @abstractmethod
    def get_translation_state(self, book_id: str) -> Dict[str, any]:
        """翻訳状態を取得する

        Args:
            book_id (str): 書籍ID

        Returns:
            Dict[str, any]: 翻訳状態の情報
        """
        pass

    @abstractmethod
    def update_translation_state(self, book_id: str, state: Dict[str, any]) -> None:
        """翻訳状態を更新する

        Args:
            book_id (str): 書籍ID
            state (Dict[str, any]): 更新する状態情報
        """
        pass

    @abstractmethod
    def get_last_processed_line(self, book_id: str) -> Optional[int]:
        """最後に処理した行番号を取得する

        Args:
            book_id (str): 書籍ID

        Returns:
            Optional[int]: 最後に処理した行番号。未処理の場合はNone
        """
        pass

    @abstractmethod
    def set_last_processed_line(self, book_id: str, line_number: int) -> None:
        """最後に処理した行番号を設定する

        Args:
            book_id (str): 書籍ID
            line_number (int): 行番号
        """
        pass

    @abstractmethod
    def clear_state(self, book_id: str) -> None:
        """翻訳状態をクリアする

        Args:
            book_id (str): 書籍ID
        """
        pass
