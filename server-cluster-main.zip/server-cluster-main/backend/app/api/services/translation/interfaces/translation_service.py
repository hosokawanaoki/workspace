from abc import ABC, abstractmethod

from api.models.book import Book
from api.services.models.translation_target import TranslationTarget


class TranslationService(ABC):
    """翻訳サービスのインターフェース"""

    @abstractmethod
    def prepare_translation(self, book: Book) -> None:
        """翻訳前の処理を実行する

        Args:
            book (Book): 書籍オブジェクト

        Raises:
            Exception: 処理中にエラーが発生した場合
        """
        pass

    @abstractmethod
    def translate(self, target: TranslationTarget) -> None:
        """翻訳を実行する

        Args:
            target (TranslationTarget): 翻訳対象（翻訳設定を含む）

        Raises:
            ValueError: 設定が不正な場合
            Exception: その他のエラーが発生した場合
        """
        pass

    @abstractmethod
    def start_correction(self, target: TranslationTarget) -> None:
        """校正を実行する

        Args:
            target (TranslationTarget): 校正対象（校正設定を含む）

        Raises:
            ValueError: 設定が不正な場合
            Exception: その他のエラーが発生した場合
        """
        pass
