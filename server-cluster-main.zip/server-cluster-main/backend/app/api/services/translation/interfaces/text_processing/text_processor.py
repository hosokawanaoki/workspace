from abc import ABC, abstractmethod
from typing import List

from api.models.book import Book
from api.services.models.translation_target import TranslationTarget
from api.services.types.translator import TranslationsData


class TextPreProcessor(ABC):
    """テキスト前処理のインターフェース"""

    @abstractmethod
    def process(self, book: Book) -> str:
        """テキストの前処理を行う

        Args:
            book (Book): 処理対象の書籍

        Returns:
            str: 処理後のテキスト
        """
        pass


class TagRecoveryService(ABC):
    """タグ復元処理のインターフェース"""

    @abstractmethod
    def recover_tags(
        self, data: TranslationsData, target: TranslationTarget
    ) -> TranslationsData:
        """タグを復元する

        Args:
            data (TranslationsData): タグ復元前のデータ
            target (TranslationTarget): 翻訳対象

        Returns:
            TranslationsData: タグ復元後のデータ
        """
        pass

    @abstractmethod
    def recover_tags_with_validation(
        self, translation_data: TranslationsData, target: TranslationTarget
    ) -> TranslationsData:
        """タグを修復して検証を行う

        Args:
            translation_data: 翻訳済みのデータ
            target: 翻訳対象

        Returns:
            TranslationsData: 修復後のデータ
        """
        pass

    @abstractmethod
    def recover_and_save(self, target: TranslationTarget) -> str:
        """タグを修復してJSONとHTMLを保存する

        Args:
            target: 翻訳対象

        Returns:
            str: 保存したJSONファイルのパス
        """
        pass


class TextSplitterService(ABC):
    """テキスト分割処理のインターフェース"""

    @abstractmethod
    def split(self, text: str) -> List[str]:
        """テキストを分割する

        Args:
            text (str): 分割前のテキスト

        Returns:
            List[str]: 分割後のテキストリスト
        """
        pass


class TranslatorControlService(ABC):
    """翻訳制御のインターフェース"""

    @abstractmethod
    def translate(self, text: str) -> str:
        """翻訳を制御する

        Args:
            text (str): 翻訳前のテキスト

        Returns:
            str: 翻訳後のテキスト
        """
        pass
