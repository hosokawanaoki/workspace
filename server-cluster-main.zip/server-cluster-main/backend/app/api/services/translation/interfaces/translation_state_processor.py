"""翻訳状態プロセッサのインターフェースを定義するモジュール"""

from abc import ABC, abstractmethod
from typing import Optional

from api.services.models.translation_target import TranslationTarget
from api.services.translation.interfaces.translation_api_client import (
    TranslationApiClient,
)
from api.services.types.translator import TranslationsData


class TranslationStateProcessor(ABC):
    """翻訳状態プロセッサのインターフェース"""

    @abstractmethod
    def __init__(
        self,
        api_client: TranslationApiClient,
        target: TranslationTarget,
    ) -> None:
        """初期化

        Args:
            api_client: APIクライアント
            target: 翻訳対象
        """
        pass

    @abstractmethod
    def initialize_state(self, translations_data: TranslationsData) -> None:
        """状態を初期化する

        Args:
            translations_data: 翻訳データ
        """
        pass

    @abstractmethod
    def check_status(self) -> Optional[str]:
        """状態をチェックする

        Returns:
            Optional[str]: エラーメッセージ（問題がない場合はNone）
        """
        pass

    @abstractmethod
    def process_chunk(self, sample_text: str = "", restrictions: str = "") -> bool:
        """チャンクを処理する

        Args:
            sample_text: サンプルテキスト
            restrictions: 制約条件

        Returns:
            bool: 処理を継続するかどうか
        """
        pass

    @abstractmethod
    def save_state(self, model: str, force_save: bool = False) -> None:
        """状態を保存する

        Args:
            model: モデル名
            force_save: 強制保存フラグ
        """
        pass
