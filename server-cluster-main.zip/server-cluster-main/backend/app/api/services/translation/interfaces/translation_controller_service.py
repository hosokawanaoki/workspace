from abc import ABC, abstractmethod


class TranslationControllerService(ABC):
    """翻訳制御サービスのインターフェース"""

    @abstractmethod
    def translate_file(self) -> None:
        """ファイルの翻訳を実行する

        Raises:
            ValueError: 設定が不正な場合
            Exception: その他のエラーが発生した場合
        """
        pass
