from abc import ABC, abstractmethod
from typing import Tuple

from api.models.book import Book
from api.models.translation_batch import TranslationBatch


class TranslationBatchService(ABC):
    """翻訳バッチサービスのインターフェース

    書籍の翻訳バッチを作成・管理するためのインターフェースを定義します。
    """

    @abstractmethod
    def create_batch(self, book_id: str) -> Tuple[Book, TranslationBatch]:
        """翻訳バッチを作成する

        Args:
            book_id (str): 書籍ID

        Returns:
            Tuple[Book, TranslationBatch]: 書籍と作成された翻訳バッチ

        Raises:
            ValueError: パラメータが不正な場合
            Exception: その他のエラーが発生した場合
        """
        pass
