"""翻訳ファイルサービスの実装"""

import logging
from typing import List, Tuple

from api.constants.constants import SYSTEM
from api.services.common.file_handlers.translation_html_handler import (
    TranslationHtmlHandler,
)
from api.services.common.file_path_util.translation_paths import TranslationPaths
from api.services.models.translation_target import TranslationTarget
from api.services.types.translator import TranslationsData, TranslationStatus
from api.utils.file.file_util import FileUtil
from api.utils.file.file_writer_util import FileWriterUtil

logger = logging.getLogger(__name__)


class TranslationFileUtil:
    """翻訳関連のファイル操作を行うユーティリティクラス

    FileUtilを使用して翻訳特有のファイル操作（翻訳データの読み書き、タグ置換ファイルの処理など）を
    静的メソッドとして提供します。
    """

    @staticmethod
    def load_tag_replace_file(
        book_id: str, encoding: str = SYSTEM["DEFAULT_ENCODING"]
    ) -> List[str]:
        """タグ置き換え済みのファイルを読み込む

        Args:
            book_id: 書籍ID

        Returns:
            List[str]: 行のリスト

        Raises:
            FileNotFoundError: ファイルが存在しない場合
            OSError: ファイルの読み込みに失敗した場合
        """
        try:
            file_path = TranslationPaths.get_tag_replace_file_path(book_id)

            if not FileUtil.check_file_exists(file_path):
                raise FileNotFoundError(
                    f"タグ置換ファイルが見つかりません: {file_path}"
                )

            content = FileUtil.read_file(file_path, encoding=encoding)
            lines = content.splitlines(keepends=True)

            logger.debug(f"タグ置換ファイルを読み込み: {file_path}")
            return lines

        except OSError as e:
            error_msg = f"タグ置換ファイルの読み込みに失敗: {book_id}"
            logger.error(error_msg)
            raise OSError(error_msg) from e

    @staticmethod
    def save_recoveried_content(
        recover_tags: TranslationsData, target: TranslationTarget
    ) -> Tuple[str, str]:
        """修復したコンテンツを保存する

        Args:
            recover_tags: 修復後のTranslationsData
            target: 翻訳対象

        Returns:
            tuple[str, str]:
                - json_path: 保存したJSONファイルのパス
                - html_path: 保存したHTMLファイルのパス

        Raises:
            OSError: ファイルの保存に失敗した場合
            IOError: ファイルの書き込みに失敗した場合
        """
        try:
            # JSONファイルの保存（バージョン番号付き）
            json_path = TranslationPaths.get_translation_json_path(
                target.book_id,
                target.translation_version.version if target.translation_version else 1,
            )
            FileWriterUtil.save_json_file(json_path, recover_tags.model_dump())

            # HTMLファイルの保存
            content = "".join(
                translation.tag_recoveried
                for translation in recover_tags.translations
                if translation.status == TranslationStatus.TAG_RECOVERED
            )
            html_path = TranslationHtmlHandler.write(
                target.book_id,
                content,
                version=target.translation_version.version
                if target.translation_version
                else 1,
            )

            logger.debug(f"タグ修復結果を保存しました：{json_path}")
            logger.debug(f"翻訳結果を保存しました：{html_path}")

            return json_path, html_path

        except Exception as e:
            error_msg = f"タグ修復結果の保存に失敗: {target.book_id}"
            logger.error(error_msg)
            raise OSError(error_msg) from e
