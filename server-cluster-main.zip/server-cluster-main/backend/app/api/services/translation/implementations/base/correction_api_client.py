"""校正APIとの通信を行うクラス"""

from typing import Optional

from api.services.common.text_util.tag_replacer_util import TagReplacerUtil
from api.services.translation.implementations.base.base_api_client import BaseApiClient
from api.services.types.translator import Translations
from api.utils.llm.interfaces.llm_service import LLMService
from api.utils.llm.models.prompt_type import PromptType


class CorrectionApiClient(BaseApiClient):
    """校正APIとの通信を行うクラス"""

    def __init__(
        self,
        llm_service: LLMService,
        model: str = "",
    ):
        """初期化処理

        Args:
            llm_service: LLMサービス
            model: 使用するモデル名
        """
        super().__init__(llm_service)
        if model:
            self.llm_service.update_config(model)

    def correct_chunk(
        self,
        chunk: Translations,
        next_chunk: Optional[str],
        correction_instruction: str,
        model: str = "",
    ) -> None:
        """チャンクを校正APIに送信する

        Args:
            chunk: 校正対象のチャンク
            next_chunk: 次のチャンクの内容
            correction_instruction: 校正指示
            model: 使用するモデル

        Raises:
            FileProcessingError: 校正に失敗した場合
        """
        # パラメータの準備
        params = {
            "chunk": TagReplacerUtil.convert_tags_to_entities(chunk.translated_text),
            "instruction": correction_instruction,
            "next_chunk": TagReplacerUtil.convert_tags_to_entities(next_chunk),
        }

        # 基底クラスの処理メソッドを呼び出し
        self._process_chunk(chunk, PromptType.CORRECTION, params, model)
