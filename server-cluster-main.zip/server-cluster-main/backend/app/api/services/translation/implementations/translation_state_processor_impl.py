"""翻訳状態プロセッサの実装を提供するモジュール"""

from datetime import datetime
from typing import Optional, cast

from api.services.common.logging_utils import (
    log_error_with_book_id,
    log_info_with_book_id,
)
from api.services.models.translation_target import TranslationTarget
from api.services.translation.interfaces.translation_api_client import (
    TranslationApiClient,
)
from api.services.translation.interfaces.translation_state_processor import (
    TranslationStateProcessor,
)
from api.services.translation.models.translation_state import TranslationState
from api.services.types.translator import TranslationsData
from api.utils.translation.translation_data_util import TranslationDataUtil
from api.utils.translation.translation_file_util import TranslationFileUtil


class TranslationStateProcessorImpl(TranslationStateProcessor):
    """翻訳状態プロセッサの実装クラス"""

    def __init__(
        self,
        api_client: TranslationApiClient,
        target: TranslationTarget,
    ) -> None:
        """初期化

        Args:
            api_client: APIクライアント
            target: 翻訳対象
        """
        self.api_client = api_client
        self.target = target
        self.state: Optional[TranslationState] = None
        self.translation_info = None

    def initialize_state(self, translations_data: TranslationsData) -> None:
        """状態を初期化する

        Args:
            translations_data: 翻訳データ
        """
        log_info_with_book_id(self.target.book_id, "翻訳状態を初期化します")
        self.translation_info = translations_data.translation_info
        if not self.target.config:
            raise ValueError("翻訳設定が初期化されていません")

        self.state = TranslationState(
            chunks=translations_data.translations,
            config=self.target.config,
        )
        self.state.validate()
        TranslationDataUtil.save_to_db(translations_data)
        log_info_with_book_id(
            self.target.book_id,
            f"翻訳状態を初期化しました。チャンク数: {len(translations_data.translations)}",
        )

    def check_status(self) -> Optional[str]:
        """状態をチェックする

        Returns:
            Optional[str]: エラーメッセージ（問題がない場合はNone）
        """
        if not self.state:
            log_info_with_book_id(self.target.book_id, "翻訳状態が初期化されていません")
            return "状態が初期化されていません"

        current_status = self.target.book.get_latest_status()
        if not self._is_valid_translation_status(current_status):
            message = f"現在のステータス '{current_status}' では翻訳を実行できません"
            log_info_with_book_id(self.target.book_id, message)
            return message

        log_info_with_book_id(
            self.target.book_id, f"ステータスチェック完了: {current_status}"
        )
        return None

    def process_chunk(self, sample_text: str = "", restrictions: str = "") -> bool:
        """チャンクを処理する

        Args:
            sample_text: サンプルテキスト
            restrictions: 制約条件

        Returns:
            bool: 処理を継続するかどうか
        """
        if not self.state:
            raise ValueError("Translation state is not initialized")

        try:
            chunk = cast(str, self.state.get_next_chunk())
            if not chunk:
                log_info_with_book_id(
                    self.target.book_id, "全てのチャンクの処理が完了しました"
                )
                self.save_state(self.target.batch.model, force_save=True)
                return False

            self.api_client.translate_chunk(
                chunk,
                *self.state.get_surrounding_chunks(),
                sample_text=sample_text,
                restrictions=restrictions,
                model=self.target.batch.get_model,
            )

            self.state.mark_chunk_complete(self.state.current_index)
            return True

        except Exception as e:
            error_message = "チャンクの翻訳処理に失敗"
            log_error_with_book_id(self.target.book_id, f"{error_message}: {str(e)}", e)
            raise

    def save_state(self, model: str, force_save: bool = False) -> None:
        """状態を保存する

        Args:
            model: モデル名
            force_save: 強制保存フラグ
        """
        if not self.state:
            raise ValueError("Translation state is not initialized")

        processed_count, total_count = self.state.get_progress()

        if not force_save and not self._should_save_state(processed_count):
            return

        try:
            log_info_with_book_id(
                self.target.book_id,
                f"状態を保存します（{processed_count}/{total_count}）",
            )

            if self.translation_info:
                self.translation_info.timestamp = datetime.now().isoformat()
                self.translation_info.model = model

            if not self.translation_info:
                raise ValueError("翻訳情報が初期化されていません")

            translations_data = TranslationsData(
                translation_info=self.translation_info,
                translations=self.state.chunks,
            )

            TranslationDataUtil.save_to_db(translations_data)
            TranslationFileUtil.save_recoveried_content(translations_data, self.target)

            self.target.update_translation_progress(
                self.state.current_index,
                self.state.chunks,
            )

            log_info_with_book_id(
                self.target.book_id,
                f"状態を保存しました。進捗: {processed_count}/{total_count}, "
                f"バッチ時間: {self.target.batch.batch_time}",
            )

        except Exception as e:
            error_message = "状態の保存に失敗"
            log_error_with_book_id(self.target.book_id, f"{error_message}: {str(e)}", e)
            raise

    def _is_valid_translation_status(self, status: str) -> bool:
        """翻訳実行可能なステータスかを確認"""
        return status in ["ai-execution", "translating"]

    def _should_save_state(self, processed_count: int) -> bool:
        """中間状態を保存すべきかを判定"""
        return processed_count % 10 == 0  # 10件ごとに中間保存
