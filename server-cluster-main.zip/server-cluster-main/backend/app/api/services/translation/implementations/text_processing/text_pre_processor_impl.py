import logging

from api.models.book import Book
from api.services.book.implementations.book_info_updater import BookInfoUpdater
from api.services.common.file_handlers.tag_replace_file_handler import (
    TagReplaceFileHandler,
)
from api.services.common.file_path_util.translation_paths import TranslationPaths
from api.services.common.html_util.gutenberg_html_util import GutenbergHtmlUtil
from api.services.common.text_util.tag_replacer_util import (
    TagReplacerUtil,
)
from api.services.scraping.exceptions.scraping_exceptions import (
    GutenbergProcessingError,
)
from api.services.scraping.implementations.gutenberg_downloader_service import (
    GutenbergDownloaderService,
)
from api.services.translation.interfaces.text_processing.text_processor import (
    TextPreProcessor,
)
from api.services.translation.interfaces.text_processing.zip_downloader_interface import (
    FileDownloaderInterface,
)
from api.utils.file.directory_util import DirectoryUtil
from api.utils.file.file_util import FileUtil

logger = logging.getLogger(__name__)


class TextPreProcessorImpl(TextPreProcessor):
    """翻訳前処理を実行するクラス

    テキストの前処理を行い、翻訳に適した形式に変換します。
    主な処理：
    1. 書籍情報の生成AI更新
    2. ZIPファイルのダウンロードと解凍
    3. HTMLコンテンツの整形
    4. タグの置換処理
    5. 処理済みファイルの保存
    """

    def __init__(
        self,
        file_downloader: FileDownloaderInterface,
        book_info_updater: BookInfoUpdater,
        gutenberg_downloader: GutenbergDownloaderService,
    ):
        """初期化

        Args:
            file_downloader: ファイルダウンロード
            book_info_updater: 書籍情報更新
            gutenberg_downloader: Gutenbergダウンローダー
        """
        self.file_downloader = file_downloader
        self.book_info_updater = book_info_updater
        self.gutenberg_downloader = gutenberg_downloader

    def process(self, book: Book) -> str:
        """翻訳前の処理を実行する

        Args:
            book: 書籍オブジェクト

        Returns:
            str: 処理済みのテキスト

        Raises:
            GutenbergProcessingError: 処理中にエラーが発生した場合
        """
        logger.info(f"書籍ID {book.book_id} の前処理を開始")

        try:
            # クリティカルな処理
            # 1. ZIPファイルのダウンロードと解凍
            html_file_path = self.gutenberg_downloader.download_book(book.book_id)
            logger.info(f"書籍 {book.book_id} のファイル取得完了: {html_file_path}")

            # 2. HTMLの整形
            processed_path = GutenbergHtmlUtil.process_html_content(
                html_file_path, book.book_id
            )
            logger.info(f"書籍 {book.book_id} のHTML整形完了: {processed_path}")

            # 3. タグの処理
            modified_html, tag_info_list = (
                TagReplacerUtil.replace_tags_with_placeholders(processed_path)
            )
            final_path = TagReplaceFileHandler.save_all(
                book.book_id, modified_html, tag_info_list
            )
            logger.info(f"書籍 {book.book_id} のタグ処理完了: {final_path}")
            book_dir = TranslationPaths.get_book_dir(book.book_id)
            DirectoryUtil.change_permissions_recursively(book_dir)
            logger.info(f"書籍 {book.book_id} のファイル権限を更新しました")

            return FileUtil.read_file(final_path)

        except Exception as e:
            error_msg = f"書籍ID {book.book_id} の前処理でエラー: {str(e)}"
            logger.exception(error_msg)
            raise GutenbergProcessingError(error_msg) from e
