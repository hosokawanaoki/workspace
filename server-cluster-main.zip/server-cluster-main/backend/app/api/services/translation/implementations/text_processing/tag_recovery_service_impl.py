"""タグ復元処理を実行するクラス"""

import logging

from api.constants.constants import TRANSLATION
from api.services.common.logging_utils import (
    log_error_with_book_id,
    log_info_with_book_id,
)
from api.services.common.text_util.tag_validator_util import TagValidatorUtil
from api.services.models.translation_target import TranslationTarget
from api.services.translation.exceptions.translation_error import (
    FileProcessingError,
)
from api.services.translation.implementations.translation_state_repository import (
    TranslationStateRepository,
)
from api.services.translation.interfaces.text_processing.text_processor import (
    TagRecoveryService,
)
from api.services.translation.translation_file_util import TranslationFileUtil
from api.services.types.translator import (
    TranslationsData,
    TranslationStatus,
)
from api.utils.translation.tag_recovery_util import recover_tags
from api.utils.translation.translation_data_util import TranslationDataUtil

# ロガーの設定
logger = logging.getLogger(__name__)


class TagRecoveryServiceImpl(TagRecoveryService):
    """タグ復元処理を実行するクラス"""

    def recover_tags(
        self, data: TranslationsData, target: TranslationTarget
    ) -> TranslationsData:
        """タグを復元する

        Args:
            data (TranslationsData): タグ復元前のデータ
            target (TranslationTarget): 翻訳対象

        Returns:
            TranslationsData: タグ復元後のデータ
        """

        try:
            # キャンセル状態をチェックして、キャンセル状態時処理
            target.handle_cancellation(
                "翻訳処理がキャンセルされたため、バッチ処理を終了します"
            )

            # 全チャンクの処理
            processed_count = 0
            total_count = sum(
                1 for t in data.translations if t.status == TranslationStatus.PROCESSED
            )

            for translation in data.translations:
                # 翻訳/校正済みのチャンクのみを処理
                if translation.status != TranslationStatus.PROCESSED:
                    continue

                processed_count += 1

                # タグ修復処理を実行
                translation = recover_tags(translation, target)

                # ステータスメッセージを更新
                if (
                    processed_count % TRANSLATION["UPDATE_INTERVAL"] == 0
                    or processed_count == total_count
                ):
                    target.batch.status_message = (
                        f"タグ修正中..{processed_count}/{total_count}"
                    )
                    target.batch.save(update_fields=["status_message"])
                    log_info_with_book_id(
                        target.book_id,
                        f"進捗: {processed_count}/{total_count}",
                    )

                    # TranslationStateRepositoryを使用してDBに保存
                    repository = TranslationStateRepository(
                        target=target,
                    )
                    repository.save_translation_state(data)

            return data
        except Exception as e:
            error_message = "タグ復元処理中にエラーが発生しました"
            log_error_with_book_id(target.book_id, f"{error_message}: {str(e)}", e)
            raise FileProcessingError(f"{error_message}: {str(e)}") from e

    def recover_tags_with_validation(
        self, translation_data: TranslationsData, target: TranslationTarget
    ) -> TranslationsData:
        """タグを修復して検証を行う

        Args:
            translation_data: 翻訳済みのデータ
            target: 翻訳対象

        Returns:
            TranslationsData
        """
        recovered_data = self.recover_tags(translation_data, target)

        # タグの検証を行う
        total_count = len(recovered_data.translations)
        success_count = 0
        is_recovery_success = True

        for translation in recovered_data.translations:
            has_no_tag_errors = TagValidatorUtil.validate_translation_tags(translation)
            if has_no_tag_errors:
                translation.status = TranslationStatus.TAG_RECOVERED
                success_count += 1
            else:
                is_recovery_success = False

        # 全体のタグ修復結果をログ出力
        if is_recovery_success:
            log_info_with_book_id(
                target.book_id,
                f"全体のタグ修復が正常に完了しました。タグの不一致はありません。成功件数: {success_count}/{total_count}",
            )
        else:
            # タグ修復が行われたものの中で不一致のあるタグを集計
            missing_tags = set()
            extra_tags = set()
            duplicate_tags = set()

            for translation in recovered_data.translations:
                # タグ修復が失敗した場合のみ集計
                if translation.status != TranslationStatus.TAG_RECOVERED:
                    if translation.missing_tags:
                        missing_tags.update(translation.missing_tags)
                    if translation.extra_tags:
                        extra_tags.update(translation.extra_tags)
                    if translation.duplicate_tags:
                        duplicate_tags.update(translation.duplicate_tags)

            log_info_with_book_id(
                target.book_id,
                f"タグ修復が完了しましたが、一部不一致があります。成功件数: {success_count}/{total_count}\n"
                f"- 欠損タグ: {missing_tags}\n"
                f"- 余分タグ: {extra_tags}\n"
                f"- 重複タグ: {duplicate_tags}",
            )

        return recovered_data

    def recover_and_save(self, target: TranslationTarget) -> str:
        """タグを修復してJSONとHTMLを保存する

        Args:
            target: 翻訳対象

        Returns:
            str: 保存したJSONファイルのパス

        Raises:
            OSError: ファイルの保存に失敗した場合
            IOError: ファイルの書き込みに失敗した場合
        """

        try:
            # DBから翻訳データを取得
            translated_data = TranslationDataUtil.load_existing_translations(target)
            if translated_data is None:
                error_message = "翻訳データの取得に失敗しました"
                log_error_with_book_id(target.book_id, error_message)
                raise FileProcessingError(error_message)

            # タグ修復処理を実行（途中保存あり）
            recovered_data = self.recover_tags(translated_data, target)

            # 検証を実行
            recovered_data_with_validation = self.recover_tags_with_validation(
                recovered_data, target
            )

            # 最終結果を保存
            repository = TranslationStateRepository(target=target)
            repository.save_translation_state(recovered_data_with_validation)

            # JSONとHTMLファイルを生成
            json_path, _ = TranslationFileUtil.save_recoveried_content(
                recovered_data_with_validation, target
            )

            return json_path
        except Exception as e:
            error_message = "タグ修復結果の保存中にエラーが発生しました"
            log_error_with_book_id(target.book_id, f"{error_message}: {str(e)}", e)
            raise FileProcessingError(f"{error_message}: {str(e)}") from e
