import logging
from typing import List

from api.services.common.file_path_util.translation_paths import TranslationPaths
from api.services.common.logging_utils import (
    log_error_with_book_id,
    log_info_with_book_id,
)
from api.services.models.translation_target import TranslationTarget
from api.services.translation.exceptions.translation_error import FileProcessingError
from api.services.translation.translation_file_util import TranslationFileUtil
from api.services.types.translator import (
    TranslationsData,
)
from api.utils.translation.translation_data_util import TranslationDataUtil

# ロガーの設定
logger = logging.getLogger(__name__)


class TranslationStateRepository:
    """翻訳状態の保存と読み込みを行うクラス"""

    def __init__(
        self,
        target: TranslationTarget,
    ):
        """初期化処理

        Args:
            target: 翻訳対象
        """
        self.target = target
        self.batch = target.batch

    def load_tag_replace_file(self, book_id: str) -> List[str]:
        """タグ置換済みファイルを読み込む

        Args:
            book_id: 書籍ID

        Returns:
            List[str]: 読み込んだファイルの行リスト

        Raises:
            FileNotFoundError: ファイルが存在しない場合
            IOError: ファイル読み込みに失敗した場合
        """

        try:
            log_info_with_book_id(book_id, "タグ置換済みファイルの読み込み開始")
            return TranslationFileUtil.load_tag_replace_file(book_id)
        except Exception as e:
            error_message = "タグ置換済みファイルの読み込みに失敗"
            log_error_with_book_id(book_id, f"{error_message}: {str(e)}", e)
            raise FileProcessingError(f"{error_message}: {str(e)}") from e

    def save_translation_state(
        self,
        translations_data: TranslationsData,
    ) -> None:
        """現在の翻訳状態を保存する

        Args:
            translations_data: 保存する翻訳データ

        Raises:
            ValueError: 翻訳データの生成に失敗した場合
        """
        try:
            if not translations_data or not translations_data.translations:
                log_error_with_book_id(
                    translations_data.translation_info.book_id,
                    "翻訳データの生成に失敗しました",
                )
                raise ValueError("翻訳データの生成に失敗しました")
            self._save_translation(translations_data)
        except Exception as e:
            log_error_with_book_id(
                translations_data.translation_info.book_id,
                f"翻訳状態の保存に失敗: {str(e)}",
                e,
            )
            raise

    def _save_translation(self, translation_data: TranslationsData) -> None:
        """翻訳結果をJSONファイルとDBに保存

        Args:
            translation_data: 保存する翻訳データ

        Raises:
            ValueError: 翻訳データがNoneまたは不正な場合
        """
        try:
            # 保存前の検証
            if not translation_data:
                raise ValueError("翻訳データがNoneです")
            if not translation_data.translations:
                raise ValueError("翻訳データの内容が空です")
            if not translation_data.translation_info:
                raise ValueError("翻訳情報が不正です")

            try:
                book_id = translation_data.translation_info.book_id
                json_path = TranslationPaths.get_translation_json_path(book_id)

                # JSONファイルに保存
                TranslationFileUtil.save_recoveried_content(
                    translation_data,
                    self.target,
                )
                log_info_with_book_id(
                    book_id,
                    f"翻訳結果をJSONに保存しました：{json_path}",
                )

                # DBにも保存
                TranslationDataUtil.save_to_db(translation_data)
                log_info_with_book_id(
                    book_id,
                    "翻訳結果をDBに保存しました",
                )

            except Exception as e:
                log_error_with_book_id(
                    book_id,
                    f"翻訳結果の保存中にエラーが発生: {str(e)}",
                    e,
                )
                raise

        except Exception as e:
            error_message = "翻訳結果の保存に失敗"
            log_error_with_book_id(
                translation_data.translation_info.book_id,
                f"{error_message}: {str(e)}",
                e,
            )
            raise FileProcessingError(f"{error_message}: {str(e)}") from e
