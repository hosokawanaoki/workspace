import logging

from api.services.common.logging_utils import (
    log_error_with_book_id,
)
from api.services.models.translation_target import TranslationTarget
from api.utils.llm.interfaces.llm_service import LLMService

logger = logging.getLogger(__name__)


class BaseBookBatchController:
    """本のバッチ処理の基底クラス"""

    def __init__(
        self,
        target: TranslationTarget,
        llm_service: LLMService,
    ):
        """初期化処理

        Args:
            target: 処理対象
            llm_service: LLMサービス
        """
        self.target = target
        self.llm_service = llm_service

    def _handle_chunk_error(
        self, chunk_number: int, error: Exception, total_chunks: int
    ) -> None:
        """チャンクエラーを処理する

        Args:
            chunk_number (int): エラーが発生したチャンク番号
            error (Exception): 発生したエラー
            total_chunks (int): 全チャンク数
        """
        error_message = f"チャンク {chunk_number}/{total_chunks} の処理中にエラーが発生: {str(error)}"
        log_error_with_book_id(self.target.book_id, error_message, error)
