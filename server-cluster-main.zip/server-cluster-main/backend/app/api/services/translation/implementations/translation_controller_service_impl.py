from typing import Optional

from api.services.common.logging_utils import (
    log_error_with_book_id,
    log_info_with_book_id,
)
from api.services.models.translation_target import TranslationTarget
from api.services.translation.exceptions.translation_error import FileProcessingError
from api.services.translation.implementations.base.translation_api_client import (
    TranslationApiClient,
)
from api.services.translation.implementations.base_book_batch_controller import (
    BaseBookBatchController,
)
from api.services.translation.implementations.translation_state.translation_state_processor import (
    TranslationStateProcessor,
)
from api.services.translation.interfaces.translation_controller_service import (
    TranslationControllerService,
)
from api.services.translation.validators.translation_validator import (
    TranslationValidator,
)
from api.services.types.translator import TranslationsData, TranslationStatus
from api.utils.llm.interfaces.llm_service import LLMService
from api.utils.translation.text_splitter_util import TextSplitterUtil
from api.utils.translation.translation_data_util import TranslationDataUtil
from api.utils.translation.translation_file_util import TranslationFileUtil


class TranslationControllerServiceImpl(
    BaseBookBatchController, TranslationControllerService
):
    """翻訳制御サービスの実装クラス"""

    def __init__(
        self,
        target: TranslationTarget,
        llm_service: LLMService,
        api_client_factory=None,
        state_processor_factory=None,
    ):
        """初期化処理

        Args:
            target: 翻訳対象
            llm_service: LLMサービス
            api_client_factory: APIクライアントファクトリ
            state_processor_factory: 状態プロセッサファクトリ
        """
        super().__init__(target, llm_service)
        self._api_client_factory = api_client_factory or (
            lambda llm, model: TranslationApiClient(llm_service=llm, model=model)
        )
        self._state_processor_factory = state_processor_factory or (
            lambda client, target: TranslationStateProcessor(
                api_client=client, target=target
            )
        )

    def translate_file(self) -> None:
        """ファイルの翻訳を実行

        Raises:
            ValueError: 翻訳設定が不正な場合
            Exception: 翻訳処理中にエラーが発生した場合
        """
        try:
            TranslationValidator.validate_config(self.target)
            log_info_with_book_id(
                str(self.target.book_id), "翻訳設定のバリデーション完了"
            )
            translations_data = self._get_or_create_chunks()
            self._process_translation(translations_data)
        except Exception as e:
            error_message = "ファイルの翻訳に失敗"
            log_error_with_book_id(self.target.book_id, f"{error_message}: {str(e)}", e)
            raise FileProcessingError(f"{error_message}: {str(e)}") from e

    def _get_or_create_chunks(self) -> TranslationsData:
        """既存の翻訳データを取得、または新規チャンクを作成

        Returns:
            TranslationsData: 翻訳データ

        Raises:
            ValueError: チャンクの生成に失敗した場合
        """
        translations_data: Optional[TranslationsData] = (
            TranslationDataUtil.load_existing_translations(self.target)
        )
        if translations_data:
            remaining_count = sum(
                1
                for chunk in translations_data.translations
                if chunk.status < TranslationStatus.PROCESSED
            )
            log_info_with_book_id(
                str(self.target.book_id),
                f"既存の翻訳データを読み込みました（未翻訳: {remaining_count}件）",
            )
            # 進捗状況を更新（未翻訳件数/全件数）
            self.target.update_translation_progress(
                len(translations_data.translations) - remaining_count - 1,
                translations_data.translations,
            )
            return translations_data

        translations_data = self._prepare_chunks()
        if not translations_data:
            raise ValueError("チャンクの生成に失敗しました")

        log_info_with_book_id(
            str(self.target.book_id),
            f"全チャンク数：{len(translations_data.translations)}",
        )
        return translations_data

    def _initialize_state_processor(self) -> TranslationStateProcessor:
        """状態処理クラスを初期化する

        Returns:
            TranslationStateProcessor: 初期化された状態処理クラス
        """
        api_client = self._api_client_factory(
            self.llm_service,
            self.target.batch.get_model,
        )

        return self._state_processor_factory(
            api_client,
            self.target,
        )

    def _edit_send_sample(self, iteration: int):
        """サンプルテキストを送信すべきかを判定

        Args:
            iteration (int): 現在の反復回数

        Returns:
            bool: サンプルテキストを送信すべきか
        """
        if iteration == 0 or iteration % 3 == 0:
            return self.target.config.sample
        else:
            return ""

    def _process_translation(self, translations_data: TranslationsData) -> None:
        """翻訳処理の実装"""
        state_processor = self._initialize_state_processor()
        state_processor.initialize_state(translations_data)

        total_iterations = self.target.batch.limit
        log_info_with_book_id(
            self.target.book_id,
            f"翻訳処理を開始します。予定反復回数: {total_iterations}",
        )

        for iteration in range(total_iterations):
            if state_processor.check_status():
                log_info_with_book_id(
                    self.target.book_id, "翻訳を一時保存して停止します"
                )
                break

            sample_text = self._edit_send_sample(iteration)

            continue_processing = state_processor.process_chunk(
                sample_text=sample_text,
                restrictions=self.target.config.restrictions,
            )

            # 中間状態を保存
            state_processor.save_state(self.target.model)

            if not continue_processing:
                log_info_with_book_id(self.target.book_id, "チャンク処理が完了しました")
                break

            log_info_with_book_id(
                self.target.book_id,
                f"{iteration + 1}/{total_iterations} が完了しました",
            )

        # for文を抜けた時点での最新状態を保存
        state_processor.save_state(self.target.model, force_save=True)
        log_info_with_book_id(self.target.book_id, "翻訳結果を保存しました")

    def _prepare_chunks(self) -> TranslationsData:
        """チャンクの準備を行う

        Returns:
            TranslationsData: 翻訳データ

        Raises:
            ValueError: ソースファイルの読み込みに失敗した場合
        """
        log_info_with_book_id(self.target.book_id, "翻訳チャンクの準備を開始")

        try:
            lines = TranslationFileUtil.load_tag_replace_file(self.target.book_id)
            if not lines:
                raise ValueError("ソースファイルが空です")

            translations_data = TextSplitterUtil.prepare_chunks(lines, self.target)
            chunk_count = len(translations_data.translations)
            log_info_with_book_id(
                str(self.target.book_id), f"チャンク分割完了: {chunk_count}チャンク"
            )
            return translations_data

        except Exception as e:
            log_error_with_book_id(
                str(self.target.book_id), f"チャンク準備中にエラーが発生: {str(e)}", e
            )
            raise ValueError("チャンクの準備に失敗しました") from e
