"""HTTPレスポンスの実装クラス"""

import logging

from api.services.scraping.interfaces.http_response import HttpResponse

logger = logging.getLogger(__name__)


class HttpResponseImpl(HttpResponse):
    """HTTPレスポンスの実装クラス"""

    def __init__(self, status_code: int, text: str):
        """HttpResponseImplの初期化

        Args:
            status_code (int): ステータスコード
            text (str): レスポンスボディ
        """
        self._status_code = status_code
        self._text = text
        logger.debug(f"HTTPレスポンスを作成: status_code={status_code}")

    def get_status_code(self) -> int:
        """ステータスコードを取得する

        Returns:
            int: ステータスコード
        """
        return self._status_code

    def get_text(self) -> str:
        """レスポンスボディを取得する

        Returns:
            str: レスポンスボディ
        """
        return self._text
