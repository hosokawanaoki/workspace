"""Excelファイル操作を管理するモジュール

GutenbergプロジェクトのカタログデータをExcel形式で保存・読み込みする機能を提供します。
"""

import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd
from api.utils.excel.excel_util import write_dataframes_to_excel
from api.utils.file.directory_util import DirectoryUtil

logger = logging.getLogger(__name__)


class ExcelFileHandler:
    """Excelファイルを使用してカタログデータを管理するクラス"""

    def __init__(self, catalog_dir: str):
        """ExcelFileHandlerの初期化

        Args:
            catalog_dir (str): カタログファイルを保存するディレクトリパス
        """
        self.catalog_dir = catalog_dir
        # ディレクトリが存在しない場合は作成
        DirectoryUtil.ensure_directory(self.catalog_dir)

    def save_catalog(
        self, catalog: List[Dict], failed_ids: List[int], last_checked_id: int
    ) -> None:
        """カタログデータをExcelファイルに保存する

        Args:
            catalog (List[Dict]): 保存するカタログデータ
            failed_ids (List[int]): 取得に失敗したIDのリスト
            last_checked_id (int): 最後にチェックしたID

        処理内容:
            1. タイムスタンプ付きのExcelファイル名を生成
            2. カタログデータをDataFrameに変換
            3. 統計情報を計算
            4. Excelファイルに保存
            5. 失敗したIDを別ファイルに保存
        """
        # ファイル名に使用するタイムスタンプを生成
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        excel_file = str(
            Path(self.catalog_dir).joinpath(f"gutenberg_catalog_{timestamp}.xlsx")
        )

        if catalog:
            df = pd.DataFrame(catalog)
            stats = self._save_statistics(df, last_checked_id)
            stats = pd.DataFrame(stats)

            if write_dataframes_to_excel(
                [
                    {"sheet_name": "Catalog", "data": df},
                    {"sheet_name": "Statistics", "data": stats},
                ],
                excel_file,
            ):
                logger.info(f"Excel file saved: {excel_file}")
            else:
                logger.error(f"Failed to save Excel file: {excel_file}")

        if failed_ids:
            failed_file = str(
                Path(self.catalog_dir).joinpath(f"failed_ids_{timestamp}.json")
            )
            FileWriterUtil.save_json_file(failed_file, failed_ids)
            logger.info(f"Failed IDs saved: {failed_file}")

    def load_catalog(self) -> tuple[List[Dict], int]:
        """最新のExcelファイルからカタログデータを読み込む

        Returns:
            tuple[List[Dict], int]: (カタログデータ, 最後にチェックしたID)

        処理内容:
            1. 最新のExcelファイルを取得
            2. カタログデータを読み込み
            3. 統計情報から最後にチェックしたIDを取得
        """
        catalog_path = Path(self.catalog_dir)
        latest_file = self._get_latest_excel_file(catalog_path)

        if not latest_file:
            logger.info("No existing catalog found. Starting fresh.")
            return [], 0

        with pd.ExcelFile(latest_file) as xl:
            df = pd.read_excel(xl, sheet_name="Catalog")
            catalog = df.to_dict("records")

            stats_df = pd.read_excel(xl, sheet_name="Statistics")
            last_checked_row = stats_df[stats_df["Metric"] == "Last Checked ID"]
            last_checked_id = (
                int(last_checked_row["Value"].iloc[0])
                if not last_checked_row.empty
                else 0
            )

            logger.info(
                f"Loaded {len(catalog)} books. Last checked ID: {last_checked_id}"
            )
            return catalog, last_checked_id

    def _get_latest_excel_file(self, directory: Path) -> Optional[str]:
        """ディレクトリ内の最新のExcelファイルを取得する

        Args:
            directory (Path): 検索するディレクトリ

        Returns:
            Optional[str]: 最新のExcelファイルパス（存在しない場合はNone）
        """
        excel_files = list(directory.glob("gutenberg_catalog_*.xlsx"))
        if not excel_files:
            return None
        # 更新日時が最新のファイルを返す
        return str(max(excel_files, key=lambda p: p.stat().st_mtime))

    def _save_statistics(self, df: pd.DataFrame, last_checked_id: int) -> dict:
        """統計情報を生成して返す

        Args:
            df (pd.DataFrame): カタログデータのDataFrame
            last_checked_id (int): 最後にチェックしたID

        Returns:
            dict: 統計情報を含む辞書

        統計項目:
            - 総書籍数
            - 言語数
            - 著者数
            - 最古のリリース日
            - 最新のリリース日
            - 最後の書籍ID
            - 最後にチェックしたID
        """
        stats = {
            "Metric": [
                "Total Books",
                "Languages",
                "Authors",
                "Earliest Release",
                "Latest Release",
                "Last Book ID",
                "Last Checked ID",
            ],
            "Value": [
                len(df),
                df["language"].nunique(),
                df["author"].nunique(),
                df["release_date"].min(),
                df["release_date"].max(),
                df["book_id"].max(),
                last_checked_id,
            ],
        }
        return stats
