"""Gutenbergプロジェクトの書籍カタログをスクレイピングするモジュール"""

import logging
from dataclasses import dataclass
from typing import Optional

from api.services.scraping.book_parser import BookParser
from api.services.scraping.interfaces.http_client import HttpClient
from api.services.scraping.progress_manager import ProgressManager
from api.services.scraping.rate_limiter import RateLimiter
from api.services.types.book_info import GutenbergBookInfo

# ロガーの設定
logger = logging.getLogger(__name__)


@dataclass
class ScraperConfig:
    """スクレイピングの設定を管理するクラス"""

    START_ID: int = 1  # スクレイピングを開始する書籍ID
    END_ID: int = 74980  # スクレイピングを終了する書籍ID
    RATE_LIMIT: float = 1.0  # リクエスト間の遅延時間（秒）
    BATCH_SIZE: int = 100  # 進捗を保存する間隔（書籍数）
    BASE_URL: str = "https://www.gutenberg.org/ebooks/{}"  # 書籍情報のベースURL
    USER_AGENT: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/91.0.4472.124 Safari/537.36"
    )


class GutenbergScraper:
    """Gutenbergプロジェクトの書籍情報をスクレイピングするクラス"""

    def __init__(
        self,
        config: ScraperConfig,
        http_client: HttpClient,
        progress_manager: ProgressManager,
        book_parser: BookParser,
        rate_limiter: Optional[RateLimiter] = None,
    ):
        """GutenbergScraperの初期化

        Args:
            config (ScraperConfig): スクレイピング設定
            http_client (HttpClientProtocol): HTTPクライアント
            progress_manager (ProgressManager): 進捗管理
            book_parser (BookParser): 書籍情報パーサー
            rate_limiter (Optional[RateLimiter]): レート制限管理
        """
        self.config = config
        self.http_client = http_client
        self.progress_manager = progress_manager
        self.book_parser = book_parser
        self.rate_limiter = rate_limiter or RateLimiter(config.RATE_LIMIT)

        # ユーザーエージェントを設定
        self.http_client.set_headers({"User-Agent": self.config.USER_AGENT})

        # 進捗情報を読み込む
        self.progress = self.progress_manager.load_progress()
        if self.progress.last_checked_id > 0:
            # 前回の続きから開始
            self.config.START_ID = self.progress.last_checked_id + 1

    def get_single_book(self, original_id: int) -> Optional[GutenbergBookInfo]:
        """単一の書籍情報を取得する

        Args:
            original_id (int): 取得するGutenberg書籍ID

        Returns:
            Optional[Dict]: 書籍情報（取得失敗時はNone）
        """
        book_info = self._get_book_info(original_id)
        if book_info:
            self.progress.catalog = [book_info]  # 1冊のみ保持
            self.progress.last_checked_id = original_id
            return book_info
        return None

    def scrape_catalog(self, start_id: Optional[int] = None) -> None:
        """カタログをスクレイピングする

        Args:
            start_id (Optional[int]): 開始する書籍ID（指定しない場合は設定値を使用）

        処理内容:
            1. 指定されたID範囲で書籍情報を順次取得
            2. 取得した情報をカタログに追加
            3. バッチサイズごとに進捗を保存
            4. スクレイピング完了後に最終結果を保存
        """
        current_id = start_id or self.config.START_ID

        try:
            while current_id <= self.config.END_ID:
                book_info = self._get_book_info(current_id)
                self.progress.last_checked_id = current_id

                if book_info:
                    self.progress.catalog.append(book_info)
                    logger.info(
                        f"Progress: Total books collected: {len(self.progress.catalog)}"
                    )

                # バッチサイズごとに進捗を保存
                if current_id % self.config.BATCH_SIZE == 0:
                    self._save_progress()
                    logger.info(f"Progress saved at book ID: {current_id}")

                current_id += 1
                # レート制限を適用
                self.rate_limiter.wait()

        except Exception as e:
            logger.error(f"Error during scraping: {str(e)}")
            self._save_progress()  # エラー時も進捗を保存
            raise

        # 最終結果を保存
        self._save_progress()
        logger.info(
            f"Scraping completed. Total books collected: {len(self.progress.catalog)}"
        )

    def _get_book_info(self, original_id: int) -> Optional[GutenbergBookInfo]:
        """指定された書籍IDの情報を取得する

        Args:
            original_id (int): 取得するGutenberg書籍ID

        Returns:
            Optional[Dict]: 書籍情報（取得失敗時はNone）

        処理内容:
            1. 書籍ページにHTTPリクエストを送信
            2. レスポンスを解析
            3. 書籍情報を抽出して返す
        """
        url = self.config.BASE_URL.format(original_id)
        try:
            response = self.http_client.get(url)
            status_code = response.get_status_code()

            if status_code == 404:
                logger.info(f"Book ID {original_id} does not exist")
                return None

            if status_code != 200:
                logger.error(
                    f"Failed to fetch book ID {original_id}: Status code {status_code}"
                )
                self.progress.failed_ids.append(original_id)
                return None

            return self.book_parser.parse_book_info(
                response.get_text(), original_id, url
            )

        except Exception as e:
            logger.error(f"Error processing book ID {original_id}: {str(e)}")
            self.progress.failed_ids.append(original_id)
            return None

    def _save_progress(self) -> None:
        """現在の進捗を保存する"""
        self.progress_manager.save_progress(self.progress)
