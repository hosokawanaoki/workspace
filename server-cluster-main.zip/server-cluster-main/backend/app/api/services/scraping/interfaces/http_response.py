"""HTTPレスポンスのインターフェースを定義するモジュール"""

from abc import ABC, abstractmethod


class HttpResponse(ABC):
    """HTTPレスポンスのインターフェース"""

    @abstractmethod
    def get_status_code(self) -> int:
        """ステータスコードを取得する

        Returns:
            int: ステータスコード
        """
        pass

    @abstractmethod
    def get_text(self) -> str:
        """レスポンスボディを取得する

        Returns:
            str: レスポンスボディ
        """
        pass
