"""エグゼキューターファクトリーのインターフェース"""

from abc import ABC, abstractmethod

from api.services.book.implementations.book_info_updater import BookInfoUpdater
from api.services.scheduler.implementations.translation_executor import (
    TranslationExecutor,
)
from api.services.translation.interfaces.translation_service import TranslationService


class ExecutorFactory(ABC):
    """エグゼキューター生成のインターフェース"""

    @abstractmethod
    def create_executor(
        self,
        translator_service: TranslationService,
        book_info_updater: BookInfoUpdater,
    ) -> TranslationExecutor:
        """エグゼキューターを生成する

        Args:
            translator_service: 翻訳サービス
            book_info_updater: 書籍情報更新

        Returns:
            TranslationExecutor: 生成されたエグゼキューターインスタンス
        """
        pass
