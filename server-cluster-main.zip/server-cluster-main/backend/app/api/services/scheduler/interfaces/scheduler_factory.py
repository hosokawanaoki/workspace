"""スケジューラーファクトリーのインターフェース"""

from abc import ABC, abstractmethod

from api.services.scheduler.implementations.task_scheduler import TaskScheduler


class SchedulerFactory(ABC):
    """スケジューラー生成のインターフェース"""

    @abstractmethod
    def create_scheduler(self) -> TaskScheduler:
        """スケジューラーを生成する

        Returns:
            BookScheduler: 生成されたスケジューラーインスタンス
        """
        pass
