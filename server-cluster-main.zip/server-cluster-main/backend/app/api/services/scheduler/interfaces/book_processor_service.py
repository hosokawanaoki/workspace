from abc import ABC, abstractmethod


class BookProcessorService(ABC):
    @abstractmethod
    def process_books(self) -> None:
        pass

    @abstractmethod
    def start_scheduler(self, interval_minutes: int) -> None:
        pass
