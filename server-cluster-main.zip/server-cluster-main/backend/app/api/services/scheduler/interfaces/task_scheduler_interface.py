from abc import ABC, abstractmethod
from typing import Callable


class TaskSchedulerInterface(ABC):
    """書籍処理のスケジューリングを管理するインターフェース"""

    @abstractmethod
    def is_running(self) -> bool:
        """スケジューラーが実行中かどうかを確認する

        Returns:
            bool: スケジューラーが実行中の場合はTrue
        """
        pass

    @abstractmethod
    def initialize(self, interval_minutes: int) -> None:
        """スケジューラーを初期化する

        Args:
            interval_minutes (int): 実行間隔（分）
        """
        pass

    @abstractmethod
    def configure_and_start(
        self, process_books_func: Callable[[], None], interval_minutes: int
    ) -> None:
        """スケジューラーを設定して開始する

        Args:
            process_books_func: 実行する関数
            interval_minutes (int): 実行間隔（分）
        """
        pass
