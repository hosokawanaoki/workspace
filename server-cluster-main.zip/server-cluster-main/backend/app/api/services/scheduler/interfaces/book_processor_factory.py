from abc import ABC, abstractmethod

from api.services.book.implementations.book_info_updater import BookInfoUpdater
from api.services.scheduler.interfaces.book_processor_service import (
    BookProcessorService,
)
from api.services.translation.interfaces.translation_service import TranslationService


class BookProcessorServiceFactory(ABC):
    """BookProcessorServiceのファクトリーインターフェース"""

    @abstractmethod
    def create(
        self,
        translator_service: TranslationService,
        book_info_updater: BookInfoUpdater,
    ) -> BookProcessorService:
        """BookProcessorServiceのインスタンスを作成する

        Args:
            translator_service: 翻訳サービス
            stalled_batch_detector: 停止バッチ検出サービス
            book_info_updater: 書籍情報更新

        Returns:
            作成されたBookProcessorServiceインスタンス
        """
        pass
