from abc import ABC, abstractmethod

from api.models.book import Book
from api.services.models.translation_target import TranslationTarget


class TranslationExecutorInterface(ABC):
    """翻訳実行を管理するインターフェース"""

    @abstractmethod
    def _process_waiting_books(self, waiting_books: list[Book]) -> None:
        """待機中の書籍を処理する
        最も古いバッチ1件のみを処理する

        Args:
            waiting_books (list[Book]): 待機中の書籍のリスト
        """
        pass

    @abstractmethod
    def _execute_translation(
        self,
        target: TranslationTarget,
    ) -> None:
        """翻訳処理を実行する

        Args:
            target (TranslationTarget): 翻訳対象のターゲット
        """
        pass
