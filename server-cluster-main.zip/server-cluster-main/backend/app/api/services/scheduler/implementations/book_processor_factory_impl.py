from typing import Optional

from api.services.book.implementations.book_info_updater import BookInfoUpdater
from api.services.scheduler.implementations.book_processor_service_impl import (
    BookProcessorServiceImpl,
)
from api.services.scheduler.implementations.default_executor_factory import (
    DefaultExecutorFactory,
)
from api.services.scheduler.implementations.default_scheduler_factory import (
    DefaultSchedulerFactory,
)
from api.services.scheduler.interfaces.book_processor_factory import (
    BookProcessorServiceFactory,
)
from api.services.scheduler.interfaces.book_processor_service import (
    BookProcessorService,
)
from api.services.scheduler.interfaces.executor_factory import ExecutorFactory
from api.services.scheduler.interfaces.scheduler_factory import SchedulerFactory
from api.services.translation.interfaces.translation_service import TranslationService


class BookProcessorServiceFactoryImpl(BookProcessorServiceFactory):
    """BookProcessorServiceのファクトリー実装クラス"""

    def __init__(
        self,
        scheduler_factory: Optional[SchedulerFactory] = None,
        executor_factory: Optional[ExecutorFactory] = None,
    ):
        """初期化

        Args:
            scheduler_factory: スケジューラーファクトリー（省略時はデフォルト）
            executor_factory: エグゼキューターファクトリー（省略時はデフォルト）
        """
        self.scheduler_factory = scheduler_factory or DefaultSchedulerFactory()
        self.executor_factory = executor_factory or DefaultExecutorFactory()

    def create(
        self,
        translator_service: TranslationService,
        book_info_updater: BookInfoUpdater,
    ) -> BookProcessorService:
        """BookProcessorServiceのインスタンスを作成する

        Args:
            translator_service: 翻訳サービス
            book_info_updater: 書籍情報更新

        Returns:
            作成されたBookProcessorServiceインスタンス
        """
        book_scheduler = self.scheduler_factory.create_scheduler()
        translation_executor = self.executor_factory.create_executor(
            translator_service=translator_service,
            book_info_updater=book_info_updater,
        )

        return BookProcessorServiceImpl(book_scheduler, translation_executor)
