import logging
from typing import Optional

from api.services.scheduler.interfaces.book_processor_service import (
    BookProcessorService,
)
from api.services.scheduler.interfaces.task_scheduler_interface import (
    TaskSchedulerInterface,
)
from api.services.scheduler.interfaces.translation_executor_interface import (
    TranslationExecutorInterface,
)

logger = logging.getLogger(__name__)


class BookProcessorServiceImpl(BookProcessorService):
    """書籍の翻訳処理を管理するサービスクラス

    翻訳待ちの書籍を定期的に処理するスケジューラーを提供します。
    書籍の翻訳処理のライフサイクルを管理し、エラーハンドリングと
    ログ出力を適切に行います。

    Attributes:
        book_scheduler (BookSchedulerInterface): スケジューラー管理
        translation_executor (TranslationExecutorInterface): 翻訳実行
    """

    MIN_INTERVAL_MINUTES = 0.5  # 最小実行間隔（30秒）

    def __init__(
        self,
        book_scheduler: TaskSchedulerInterface,
        translation_executor: TranslationExecutorInterface,
    ):
        """初期化

        Args:
            book_scheduler: スケジューラー管理インターフェース
            translation_executor: 翻訳実行インターフェース
        """
        self.book_scheduler = book_scheduler
        self.translation_executor = translation_executor
        self._processing_status: Optional[str] = None

    def process_books(self) -> None:
        """翻訳待ちの書籍を処理する

        翻訳待ち状態の書籍を取得し、それぞれに対して翻訳処理を実行します。
        エラーが発生した場合も、スケジューラーは継続して動作します。

        Note:
            - AI翻訳中の書籍が存在する場合、新規の翻訳処理は開始しません
            - AI翻訳中の書籍が30分以上更新されていない場合は、エラー状態に設定
            - APSchedulerのmax_instances=1により、同時実行は制御
        """
        if self._is_currently_processing():
            logger.warning("前回の処理が完了していないため、スキップします")
            return

        try:
            self._set_processing_status("processing")
            self._execute_processing_cycle()
        except Exception as e:
            logger.error(f"書籍処理中にエラーが発生しました: {str(e)}")
            logger.exception("詳細なエラー情報:")
        finally:
            self._set_processing_status(None)
            logger.info("書籍処理プロセスを終了しました")

    def start_scheduler(self, interval_minutes: int = 1) -> None:
        """定期実行スケジューラーを開始する

        Args:
            interval_minutes: 実行間隔（分）。デフォルトは1分。

        Raises:
            ValueError: 実行間隔が最小値未満の場合
            RuntimeError: スケジューラーの初期化または開始に失敗した場合
        """
        if interval_minutes < self.MIN_INTERVAL_MINUTES:
            raise ValueError(
                f"実行間隔は{self.MIN_INTERVAL_MINUTES}分以上である必要があります"
            )

        try:
            if self.book_scheduler.is_running():
                logger.info("スケジューラーは既に実行中です")
                return

            self._initialize_and_start_scheduler(interval_minutes)
            logger.info(
                f"スケジューラーを開始しました（実行間隔: {interval_minutes}分）"
            )

        except Exception as e:
            error_msg = f"スケジューラーの開始に失敗しました: {str(e)}"
            logger.error(error_msg)
            raise RuntimeError(error_msg) from e

    def _is_currently_processing(self) -> bool:
        """現在処理中かどうかを確認する"""
        return self._processing_status == "processing"

    def _set_processing_status(self, status: Optional[str]) -> None:
        """処理状態を設定する"""
        self._processing_status = status

    def _execute_processing_cycle(self) -> None:
        """書籍処理サイクルを実行する"""
        logger.debug("書籍処理サイクルを開始します")

        from api.utils.translation.stalled_batch_util import StalledBatchUtil

        stalled_batches = StalledBatchUtil.detect_stalled_batches()
        if stalled_batches:
            logger.debug("処理中の書籍があるため、新規処理をスキップします")
            for batch in stalled_batches:
                StalledBatchUtil.process_stalled_batch(batch)
            return

        self.translation_executor.process_new_translations()
        logger.debug("新規翻訳処理を完了しました")

    def _initialize_and_start_scheduler(self, interval_minutes: int) -> None:
        """スケジューラーを初期化して開始する"""
        self.book_scheduler.initialize(interval_minutes)
        self.book_scheduler.configure_and_start(self.process_books, interval_minutes)
