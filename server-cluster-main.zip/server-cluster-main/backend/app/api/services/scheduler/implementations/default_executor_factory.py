"""デフォルトのエグゼキューターファクトリー実装"""

from api.services.book.implementations.book_info_updater import BookInfoUpdater
from api.services.scheduler.implementations.translation_executor import (
    TranslationExecutor,
)
from api.services.scheduler.interfaces.executor_factory import ExecutorFactory
from api.services.translation.interfaces.translation_service import TranslationService


class DefaultExecutorFactory(ExecutorFactory):
    """デフォルトのエグゼキューター生成実装"""

    def create_executor(
        self,
        translator_service: TranslationService,
        book_info_updater: BookInfoUpdater,
    ) -> TranslationExecutor:
        """エグゼキューターを生成する

        Args:
            translator_service: 翻訳サービス
            book_info_updater: 書籍情報更新

        Returns:
            TranslationExecutor: 生成されたエグゼキューターインスタンス
        """
        return TranslationExecutor(
            translator_service=translator_service,
            book_info_updater=book_info_updater,
        )
