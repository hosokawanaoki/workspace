import logging
from datetime import datetime
from typing import Callable, Optional

from api.services.scheduler.interfaces.task_scheduler_interface import (
    TaskSchedulerInterface,
)
from apscheduler.jobstores.base import JobLookupError
from apscheduler.schedulers.background import BackgroundScheduler

logger = logging.getLogger(__name__)


class TaskScheduler(TaskSchedulerInterface):
    """書籍処理のスケジューリングを管理するクラス

    APSchedulerを使用して、書籍処理タスクの定期実行を管理します。
    スケジューラーの状態管理、ジョブの設定、エラーハンドリングを提供します。

    Attributes:
        scheduler (Optional[BackgroundScheduler]): APSchedulerインスタンス
        JOB_ID (str): スケジューラーのジョブID
    """

    JOB_ID = "book_processing_job"
    DEFAULT_MAX_INSTANCES = 1
    DEFAULT_COALESCE = True

    def __init__(self):
        """BookSchedulerを初期化する

        スケジューラーの初期状態をNoneに設定します。
        実際のスケジューラーはinitialize()メソッドで作成されます。
        """
        self.scheduler: Optional[BackgroundScheduler] = None

    def is_running(self) -> bool:
        """スケジューラーが実行中かどうかを確認する

        スケジューラーのインスタンスが存在し、実行中かどうかを確認します。

        Returns:
            bool: スケジューラーが実行中の場合はTrue
        """
        if self.scheduler is not None and self.scheduler.running:
            logger.debug("スケジューラーは実行中です")
            return True
        return False

    def initialize(self, interval_minutes: int) -> None:
        """スケジューラーを初期化する

        新しいBackgroundSchedulerインスタンスを作成し、
        ログレベルを設定します。

        Args:
            interval_minutes (int): 実行間隔（分）

        Raises:
            RuntimeError: スケジューラーの初期化に失敗した場合
        """
        try:
            if self.is_running():
                logger.warning("既存のスケジューラーを停止します")
                self.scheduler.shutdown()

            logger.info(
                f"スケジューラーを初期化します（実行間隔: {interval_minutes}分）"
            )
            self.scheduler = BackgroundScheduler()
            logging.getLogger("apscheduler").setLevel(logging.INFO)

        except Exception as e:
            error_msg = f"スケジューラーの初期化に失敗しました: {str(e)}"
            logger.error(error_msg)
            raise RuntimeError(error_msg) from e

    def configure_and_start(
        self, process_books_func: Callable, interval_minutes: int
    ) -> None:
        """スケジューラーを設定して開始する

        指定された関数を定期実行するようにスケジューラーを設定し、
        実行を開始します。

        Args:
            process_books_func (Callable): 実行する関数
            interval_minutes (int): 実行間隔（分）

        Raises:
            ValueError: スケジューラーが初期化されていない場合
            RuntimeError: ジョブの追加または開始に失敗した場合
        """
        if self.scheduler is None:
            raise ValueError("スケジューラーが初期化されていません")

        try:
            # 既存のジョブを削除
            try:
                self.scheduler.remove_job(self.JOB_ID)
            except JobLookupError:
                pass

            # 新しいジョブを追加
            self.scheduler.add_job(
                process_books_func,
                "interval",
                minutes=interval_minutes,
                next_run_time=datetime.now(),
                id=self.JOB_ID,
                max_instances=self.DEFAULT_MAX_INSTANCES,
                coalesce=self.DEFAULT_COALESCE,
                misfire_grace_time=None,  # 遅延実行を許可しない
            )

            # スケジューラーを開始
            self.scheduler.start()
            logger.info(
                f"スケジューラーを開始しました（ジョブID: {self.JOB_ID}, "
                f"実行間隔: {interval_minutes}分）"
            )

        except Exception as e:
            error_msg = f"スケジューラーの設定と開始に失敗しました: {str(e)}"
            logger.error(error_msg)
            raise RuntimeError(error_msg) from e
