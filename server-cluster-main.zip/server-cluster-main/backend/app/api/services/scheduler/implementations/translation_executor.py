import logging
from typing import Literal

from api.models.book import Book
from api.services.book.implementations.book_info_updater import BookInfoUpdater
from api.services.models.translation_batch_service import TranslationBatchService
from api.services.models.translation_target import TranslationTarget
from api.services.scheduler.interfaces.translation_executor_interface import (
    TranslationExecutorInterface,
)
from api.services.translation.interfaces.translation_service import TranslationService
from api.services.translation.models.translator_config import TranslatorConfig
from api.utils.translation.translation_process_util import TranslationProcessUtil

logger = logging.getLogger(__name__)


class TranslationExecutor(TranslationExecutorInterface):
    """翻訳実行を管理するクラス

    書籍の翻訳処理を実行し、各段階（前処理、翻訳、後処理）を
    適切に管理します。エラーハンドリングとログ出力を提供します。
    """

    def __init__(
        self,
        translator_service: TranslationService,
        book_info_updater: BookInfoUpdater,
    ):
        """初期化

        Args:
            translator_service: 翻訳サービス
            book_info_updater: 書籍情報更新
        """
        self.translator_service = translator_service
        self.book_info_updater = book_info_updater

    def process_new_translations(self) -> None:
        """新規の翻訳処理を開始する

        待機中の書籍を取得し、最も古いバッチから処理を開始します。
        """
        waiting_books = Book.get_waiting_books()
        if not waiting_books:
            logger.info("待機中の書籍はありません")
            return

        logger.info(f"待機中の書籍が{len(waiting_books)}件見つかりました")
        self._process_waiting_books(waiting_books)

    def _process_waiting_books(self, waiting_books: list[Book]) -> None:
        """待機中の書籍を処理する

        最も古いバッチ1件のみを処理します。

        Args:
            waiting_books: 待機中の書籍のリスト
        """
        if not waiting_books:
            logger.info("待機中の書籍がありません")
            return

        # 最も古いバッチを持つ書籍を取得
        book, batch = TranslationBatchService.find_oldest_batch_book(waiting_books)
        if not book or not batch:
            return

        # 翻訳設定を生成
        config = TranslatorConfig()
        if batch.translation_setting:
            config.restrictions, config.sample = (
                TranslatorConfig.generate_prompt_from_setting(batch.translation_setting)
            )

        # TranslationTargetを生成
        target = TranslationTarget(book, batch, config)
        if not target.book_id:
            return

        logger.info(f"書籍（ID: {target.book_id}）の処理を開始します")
        self._process_translation_target(target)

    def _process_translation_target(self, target: TranslationTarget) -> None:
        """翻訳対象の処理を実行する

        Args:
            target: 翻訳対象
        """
        try:
            logger.info(f"書籍 {target.book_id} の処理を開始します")
            status: Literal["cancel"] | str = target.book.status
            logger.info(f"書籍 {target.book_id} のステータス: {status}")

            if target.needs_info_update:
                logger.info(f"書籍 {target.book_id} の情報更新が必要です")
                self.book_info_updater.update_book_info_from_llm(target.book)

            if target.is_waiting:
                logger.info(f"書籍 {target.book_id} は待機状態です")
                self._execute_translation(target)
            else:
                logger.info(f"書籍 {target.book_id} は待機状態ではありません")

        except Exception as e:
            logger.error(f"翻訳対象の処理でエラーが発生: {str(e)}")
            target.mark_as_error()

    def _execute_translation(self, target: TranslationTarget) -> None:
        """翻訳/校正処理を実行する

        Args:
            target: 翻訳対象
        """
        if target.batch.mode == "correction":
            self._execute_correction(target)
        else:
            self._execute_normal_translation(target)

    def _execute_normal_translation(self, target: TranslationTarget) -> None:
        """通常の翻訳処理を実行する

        Args:
            target: 翻訳対象（翻訳設定を含む）
        """
        logger.info(f"書籍 {target.book_id} の翻訳実行を開始します")

        try:
            # 翻訳開始
            target.start_translation()
            logger.info(f"書籍 {target.book_id} の翻訳を開始しました")

            # 前処理
            self.translator_service.prepare_translation(target.book)
            logger.info(f"書籍 {target.book_id} の前処理が完了しました")

            # キャンセル状態をチェック
            target.handle_cancellation()

            # 翻訳実行
            self.translator_service.translate(target)

            # 後処理
            logger.info(f"書籍 {target.book_id} のステータス更新を開始します")
            TranslationProcessUtil.update_translation_status(target)
            logger.info(
                f"書籍 {target.book_id} の翻訳処理が完了しました。最終ステータス: {target.book.status}"
            )
        except Exception as e:
            logger.error(f"翻訳処理でエラーが発生: {str(e)}")
            target.mark_as_error()

    def _execute_correction(self, target: TranslationTarget) -> None:
        """校正処理を実行する

        Args:
            target: 翻訳対象
        """
        logger.info(f"書籍 {target.book_id} の校正実行を開始します")

        try:
            # 校正開始
            target.start_translation()
            logger.info(f"書籍 {target.book_id} の校正を開始しました")

            # キャンセル状態をチェック
            target.handle_cancellation()

            # 校正実行
            self.translator_service.start_correction(target)

            # 後処理
            logger.info(f"書籍 {target.book_id} のステータス更新を開始します")
            TranslationProcessUtil.update_translation_status(target)
            logger.info(
                f"書籍 {target.book_id} の校正処理が完了しました。最終ステータス: {target.book.status}"
            )
        except Exception as e:
            logger.error(f"校正処理でエラーが発生: {str(e)}")
            target.mark_as_error()
