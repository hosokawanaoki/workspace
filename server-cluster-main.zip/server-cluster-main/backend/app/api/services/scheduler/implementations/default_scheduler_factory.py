"""デフォルトのスケジューラーファクトリー実装"""

from api.services.scheduler.implementations.task_scheduler import TaskScheduler
from api.services.scheduler.interfaces.scheduler_factory import SchedulerFactory


class DefaultSchedulerFactory(SchedulerFactory):
    """デフォルトのスケジューラー生成実装"""

    def create_scheduler(self) -> TaskScheduler:
        """スケジューラーを生成する

        Returns:
            BookScheduler: 生成されたスケジューラーインスタンス
        """
        return TaskScheduler()
