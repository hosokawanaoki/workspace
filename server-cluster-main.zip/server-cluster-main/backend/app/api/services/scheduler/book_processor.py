"""BookProcessorService初期化モジュール"""

from api.services.scheduler.implementations.book_processor_factory_impl import (
    BookProcessorServiceFactoryImpl,
)
from api.services.translation.interfaces.text_processing.text_processor import (
    TagRecoveryService,
    TextPreProcessor,
)
from api.services.translation.interfaces.translation_service import TranslationService


def start_book_processor_service() -> None:
    """BookProcessorServiceを初期化して開始する"""
    import logging

    logger = logging.getLogger(__name__)
    logger.info("BookProcessorServiceの初期化を開始します")

    # バッチ処理では、実行時に必要なモジュールを動的にインポートします。
    # これにより、バッチ起動時の初期ロード時間を最適化し、
    # 必要なモジュールのみを実行時にロードすることができます。

    # Book関連のインポート
    from api.services.book.implementations.book_info_updater import BookInfoUpdater
    from api.services.scraping.book_parser import BookParser
    from api.services.scraping.gutenberg_scraper import GutenbergScraper, ScraperConfig
    from api.services.scraping.implementations.gutenberg_downloader_service import (
        GutenbergDownloaderService,
    )
    from api.services.scraping.implementations.http_client_impl import HttpClientImpl
    from api.services.scraping.progress_manager import ProgressManager

    # Translation関連のインポート - テキスト処理
    from api.services.translation.implementations.text_processing.file_downloader_impl import (
        FileDownloaderImpl,
    )

    # Translation関連のインポート - タグ復元
    from api.services.translation.implementations.text_processing.tag_recovery_service_impl import (
        TagRecoveryServiceImpl,
    )
    from api.services.translation.implementations.text_processing.text_pre_processor_impl import (
        TextPreProcessorImpl,
    )
    from api.services.translation.implementations.translation_service_impl import (
        TranslationServiceImpl,
    )

    # TextPreProcessorImplの依存関係を初期化
    file_downloader = FileDownloaderImpl()

    # Gutenberg関連のコンポーネントを初期化
    http_client = HttpClientImpl()
    progress_manager = ProgressManager()
    book_parser = BookParser()
    scraper = GutenbergScraper(
        config=ScraperConfig(),
        http_client=http_client,
        progress_manager=progress_manager,
        book_parser=book_parser,
    )
    gutenberg_downloader = GutenbergDownloaderService(
        file_downloader=file_downloader,
    )

    # BookInfoUpdaterの初期化
    book_info_updater = BookInfoUpdater(
        scraper=scraper,
    )

    # TextPreProcessorImplのインスタンス化
    text_pre_processor: TextPreProcessor = TextPreProcessorImpl(
        file_downloader=file_downloader,
        book_info_updater=book_info_updater,
        gutenberg_downloader=gutenberg_downloader,
    )

    # タグ復元関連のコンポーネントを初期化
    tag_recovery_service: TagRecoveryService = TagRecoveryServiceImpl()

    translator_service: TranslationService = TranslationServiceImpl(
        text_pre_processor=text_pre_processor,
        tag_recovery_service=tag_recovery_service,
    )

    # BookProcessorServiceの作成
    book_processor_factory = BookProcessorServiceFactoryImpl()
    book_processor_service = book_processor_factory.create(
        translator_service=translator_service,
        book_info_updater=book_info_updater,
    )

    try:
        book_processor_service.start_scheduler(interval_minutes=1)
        logger.info("BookProcessorServiceのスケジューラーを開始しました")
    except Exception as e:
        logger.error(f"BookProcessorServiceの起動に失敗しました: {str(e)}")
        raise
