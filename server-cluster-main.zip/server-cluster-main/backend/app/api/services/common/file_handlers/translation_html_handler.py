from api.services.common.file_path_util.translation_paths import TranslationPaths
from api.utils.file.directory_util import DirectoryUtil
from api.utils.file.file_util import FileUtil
from api.utils.file.file_writer_util import FileWriterUtil


class TranslationHtmlHandler:
    """翻訳HTMLファイルの読み書きを管理するクラス"""

    @staticmethod
    def read(book_id: str, version: int = None) -> str:
        """HTMLファイルを読み込む

        Args:
            book_id: 書籍ID
            version: バージョン番号（オプション）

        Returns:
            str: 読み込んだHTMLデータ

        Raises:
            FileNotFoundError: HTMLファイルが存在しない場合
            OSError: ファイルの読み込みに失敗した場合
        """
        html_path = TranslationPaths.get_translated_html_path(book_id, version)
        return FileUtil.read_file(html_path)

    @staticmethod
    def write(book_id: str, content: str, version: int = None) -> str:
        """HTMLファイルに書き込む

        Args:
            book_id: 書籍ID
            content: 書き込むデータ
            version: バージョン番号（オプション）

        Returns:
            str: 保存したHTMLファイルのパス

        Note:
            - 必要なディレクトリが存在しない場合は自動的に作成します
            - 翻訳ディレクトリも同時に作成します
        """
        # 翻訳ディレクトリを作成
        translated_dir = TranslationPaths.get_translated_dir(book_id)
        DirectoryUtil.ensure_directory(translated_dir)

        # HTMLファイルを保存
        html_path = TranslationPaths.get_translated_html_path(book_id, version)
        FileWriterUtil.save_file_with_permission(html_path, content)
        return html_path

    @staticmethod
    def exists(book_id: str, version: int = None) -> bool:
        """HTMLファイルが存在するかチェック

        Args:
            book_id: 書籍ID
            version: バージョン番号（オプション）

        Returns:
            bool: ファイルが存在する場合True
        """
        html_path = TranslationPaths.get_translated_html_path(book_id, version)
        return FileWriterUtil.check_path_exists(html_path)

    @staticmethod
    def delete(book_id: str, version: int = None) -> None:
        """HTMLファイルを削除

        Args:
            book_id: 書籍ID
            version: バージョン番号（オプション）

        Note:
            ファイルが存在しない場合は何もしない
        """
        if TranslationHtmlHandler.exists(book_id, version):
            html_path = TranslationPaths.get_translated_html_path(book_id, version)
            FileUtil.remove_file(html_path)
