import logging

from api.constants.constants import FILES
from api.services.common.file_path_util.translation_paths import TranslationPaths
from api.services.scraping.exceptions.scraping_exceptions import (
    GutenbergProcessingError,
)
from api.utils.file.directory_util import DirectoryUtil
from api.utils.file.file_util import FileUtil

logger = logging.getLogger(__name__)


class GutenbergFileUtil:
    """Project Gutenbergのファイル操作ユーティリティ"""

    @staticmethod
    def extract_html_from_zip(zip_content: bytes, book_id: str) -> str:
        """ZIPファイルからHTMLファイルを抽出する

        Args:
            zip_content (bytes): ZIPファイルのバイナリデータ
            book_id (str): 書籍ID

        Returns:
            str: 解凍したHTMLファイルのパス

        Raises:
            GutenbergProcessingError: 解凍中にエラーが発生した場合
        """
        try:
            # 出力ディレクトリの設定と作成
            html_dir = TranslationPaths.get_raw_html_dir(book_id)
            DirectoryUtil.create_directory_with_permissions(html_dir)

            # ZIPファイルの解凍とHTMLファイルの抽出
            try:
                html_files = FileUtil.extract_zip(
                    zip_content, html_dir, FILES["HTML_EXTENSIONS"]
                )
                return TranslationPaths.get_raw_html_file_path(book_id, html_files[0])
            except ValueError as e:
                raise GutenbergProcessingError(str(e))

        except Exception as e:
            error_msg = f"書籍ID {book_id} の解凍中にエラー発生: {str(e)}"
            logger.exception(error_msg)
            raise GutenbergProcessingError(error_msg)
