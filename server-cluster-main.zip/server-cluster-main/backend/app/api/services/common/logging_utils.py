"""ログ関連のユーティリティを提供するモジュール"""

import logging
import os
import threading
import time
import uuid
from functools import wraps
from typing import Any, Callable, Dict, Optional

import psutil

# スレッドローカルストレージでトレースIDを管理
_thread_local = threading.local()


def get_trace_id() -> str:
    """現在のトレースIDを取得する。存在しない場合は新規生成する。

    Returns:
        str: トレースID
    """
    if not hasattr(_thread_local, "trace_id"):
        _thread_local.trace_id = str(uuid.uuid4())
    return _thread_local.trace_id


def set_trace_id(trace_id: Optional[str] = None) -> None:
    """トレースIDを設定する

    Args:
        trace_id: 設定するトレースID（Noneの場合は新規生成）
    """
    _thread_local.trace_id = trace_id or str(uuid.uuid4())


class PerformanceMonitor:
    """パフォーマンスモニタリングを提供するクラス"""

    @staticmethod
    def measure_time(func: Callable) -> Callable:
        """関数の実行時間を計測するデコレータ

        Args:
            func: 計測対象の関数

        Returns:
            Callable: ラップされた関数
        """

        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            result = func(*args, **kwargs)
            end_time = time.time()

            logger = logging.getLogger(func.__module__)
            execution_time = end_time - start_time
            logger.debug(
                f"Performance: Function '{func.__name__}' took {execution_time:.3f} seconds"
            )
            return result

        return wrapper

    @staticmethod
    def log_memory_usage(logger: logging.Logger) -> None:
        """現在のメモリ使用量をログに記録する

        Args:
            logger: ロガーインスタンス
        """
        process = psutil.Process(os.getpid())
        memory_info = process.memory_info()
        logger.info(
            f"Memory Usage - RSS: {memory_info.rss / 1024 / 1024:.2f}MB, "
            f"VMS: {memory_info.vms / 1024 / 1024:.2f}MB"
        )


def log_with_context(
    logger: logging.Logger,
    level: int,
    message: str,
    context: Optional[Dict[str, Any]] = None,
    error: Optional[Exception] = None,
) -> None:
    """コンテキスト情報付きでログを出力する

    Args:
        logger: ロガーインスタンス
        level: ログレベル
        message: ログメッセージ
        context: 追加のコンテキスト情報
        error: エラーオブジェクト
    """
    context = context or {}
    log_message = message

    # book_idがある場合は追加
    if context and "book_id" in context:
        log_message = f"[Book ID: {context['book_id']}] {log_message}"

    # エラーがある場合はエラーメッセージを追加
    if error:
        log_message = f"{log_message} - {str(error)}"

    logger.log(level, log_message)


def log_info(
    logger: logging.Logger, message: str, context: Optional[Dict[str, Any]] = None
) -> None:
    """INFOログを出力する

    Args:
        logger: ロガーインスタンス
        message: ログメッセージ
        context: コンテキスト情報（オプション）
    """
    log_with_context(logger, logging.INFO, message, context)


def log_error(
    logger: logging.Logger,
    message: str,
    error: Optional[Exception] = None,
    context: Optional[Dict[str, Any]] = None,
) -> None:
    """エラーログを出力する

    Args:
        logger: ロガーインスタンス
        message: ログメッセージ
        error: エラーオブジェクト（オプション）
        context: コンテキスト情報（オプション）
    """
    log_with_context(logger, logging.ERROR, message, context, error)


def log_warning(
    logger: logging.Logger,
    message: str,
    error: Optional[Exception] = None,
    context: Optional[Dict[str, Any]] = None,
) -> None:
    """警告ログを出力する

    Args:
        logger: ロガーインスタンス
        message: ログメッセージ
        error: エラーオブジェクト（オプション）
        context: コンテキスト情報（オプション）
    """
    log_with_context(logger, logging.WARNING, message, context, error)


def log_info_with_book_id(book_id: str, message: str) -> None:
    """書籍IDを含むINFOログを出力する

    Args:
        book_id: 書籍ID
        message: ログメッセージ
    """
    logger = logging.getLogger(__name__)
    context = {"book_id": book_id}
    log_with_context(logger, logging.INFO, message, context)


def log_error_with_book_id(
    book_id: str, message: str, error: Optional[Exception] = None
) -> None:
    """書籍IDを含むエラーログを出力する

    Args:
        book_id: 書籍ID
        message: ログメッセージ
        error: エラーオブジェクト（オプション）
    """
    logger = logging.getLogger(__name__)
    context = {"book_id": book_id}
    log_with_context(logger, logging.ERROR, message, context, error)


def log_warning_with_book_id(
    book_id: str, message: str, error: Optional[Exception] = None
) -> None:
    """書籍IDを含むエラーログを出力する

    Args:
        book_id: 書籍ID
        message: ログメッセージ
        error: エラーオブジェクト（オプション）
    """
    logger = logging.getLogger(__name__)
    context = {"book_id": book_id}
    log_with_context(logger, logging.WARNING, message, context, error)


def log_debug_with_book_id(book_id: str, message: str) -> None:
    """書籍IDを含むDEBUGログを出力する

    Args:
        book_id: 書籍ID
        message: ログメッセージ
    """
    logger = logging.getLogger(__name__)
    context = {"book_id": book_id}
    log_with_context(logger, logging.DEBUG, message, context)


# パフォーマンスモニタリングのデコレータのエイリアス
measure_performance = PerformanceMonitor.measure_time
