from typing import Optional, Union

from api.constants.constants import BASE_DIR, BOOK_BASE_PATH, DIRS, FILES, TRANSLATION
from api.utils.file.file_util import FileUtil


class TranslationPaths:
    """翻訳関連のファイルパスを管理するクラス"""

    @staticmethod
    def _get_book_base_path(book_id: str, sub_dir: Optional[str] = None) -> str:
        """書籍関連のベースパスを生成する

        Args:
            book_id: 書籍ID (形式: provider_id_book_id_model_language)
            sub_dir: サブディレクトリ名（オプション）

        Returns:
            str: 生成されたパス
        """
        book_id_str = book_id.replace("/", "__")
        base = FileUtil.join_paths(BASE_DIR, BOOK_BASE_PATH, book_id_str)
        return FileUtil.join_paths(base, sub_dir) if sub_dir else base

    @staticmethod
    def _create_book_filename(book_id: str, suffix: str, prefix: str = "pg") -> str:
        """書籍関連のファイル名を生成する

        Args:
            book_id: 書籍ID
            suffix: ファイル名の接尾辞
            prefix: ファイル名の接頭辞（デフォルト: "pg"）

        Returns:
            str: 生成されたファイル名
        """
        book_id_str = book_id.replace("/", "__")
        return f"{prefix}{book_id_str}{suffix}"

    @staticmethod
    def get_book_dir(book_id: str) -> str:
        """書籍のベースディレクトリを取得

        Args:
            book_id: 書籍ID

        Returns:
            str: 書籍のベースディレクトリパス
        """
        return TranslationPaths._get_book_base_path(book_id)

    @staticmethod
    def get_raw_html_dir(book_id: str) -> str:
        """生のHTMLファイルのディレクトリを取得

        Args:
            book_id: 書籍ID

        Returns:
            str: 生のHTMLファイルのディレクトリパス
        """
        return TranslationPaths._get_book_base_path(book_id, DIRS["RAW"])

    @staticmethod
    def get_final_output_dir(book_id: str) -> str:
        """最終出力ディレクトリを取得

        Args:
            book_id: 書籍ID

        Returns:
            str: 最終出力ディレクトリパス
        """
        return TranslationPaths._get_book_base_path(book_id, DIRS["FINAL_OUTPUT"])

    @staticmethod
    def get_cover_image_path(book_id: str) -> str:
        """カバー画像のパスを取得

        Args:
            book_id: 書籍ID

        Returns:
            str: カバー画像のパス
        """
        final_output_dir = TranslationPaths.get_final_output_dir(book_id)
        return FileUtil.join_paths(
            final_output_dir, DIRS["IMAGES"], FILES["COVER_IMAGE"]
        )

    @staticmethod
    def get_formatted_html_dir(book_id: str) -> str:
        """整形済みHTMLファイルのディレクトリパスを取得

        Args:
            book_id: 書籍ID

        Returns:
            str: 整形済みHTMLファイルのディレクトリパス

        Note:
            ディレクトリ名はDIRS["FORMATTED"]から取得
        """
        return TranslationPaths._get_book_base_path(book_id, DIRS["FORMATTED"])

    @staticmethod
    def get_tag_replace_dir(book_id: str) -> str:
        """タグ置換用ディレクトリパスを取得

        Args:
            book_id: 書籍ID

        Returns:
            str: タグ置換用ディレクトリパス

        Note:
            ディレクトリ名はDIRS["TAG_REPLACE"]から取得
        """
        return TranslationPaths._get_book_base_path(book_id, DIRS["TAG_REPLACE"])

    @staticmethod
    def get_translated_dir(book_id: Union[str, int]) -> str:
        """翻訳済みファイルのディレクトリパスを取得

        Args:
            book_id: 書籍ID

        Returns:
            str: 翻訳済みファイルのディレクトリパス

        Note:
            ディレクトリ名はDIRS["TRANSLATED"]から取得
        """
        return TranslationPaths._get_book_base_path(book_id, DIRS["TRANSLATED"])

    @staticmethod
    def get_inside_html_path(book_id: str, dir_type: str) -> str:
        """内部HTMLファイルのパスを取得

        Args:
            book_id: 書籍ID
            dir_type: ディレクトリタイプ (DIRS["FORMATTED"] または DIRS["TAG_REPLACE"])

        Returns:
            str: 内部HTMLファイルのパス

        Raises:
            ValueError: 無効なディレクトリタイプが指定された場合

        Note:
            ファイル名はFILES["INSIDE_HTML_SUFFIX"]から取得
        """
        if dir_type == DIRS["FORMATTED"]:
            dir_path = TranslationPaths.get_formatted_html_dir(book_id)
        elif dir_type == DIRS["TAG_REPLACE"]:
            dir_path = TranslationPaths.get_tag_replace_dir(book_id)
        else:
            raise ValueError(f"Invalid directory type: {dir_type}")

        filename = TranslationPaths._create_book_filename(
            book_id, FILES["INSIDE_HTML_SUFFIX"]
        )
        return FileUtil.join_paths(dir_path, filename)

    @staticmethod
    def get_outside_html_path(book_id: str) -> str:
        """外部HTMLファイルのパスを取得

        Args:
            book_id: 書籍ID

        Returns:
            str: 外部HTMLファイルのパス

        Note:
            ファイル名はFILES["OUTSIDE_HTML_SUFFIX"]から取得
        """
        formatted_dir = TranslationPaths.get_formatted_html_dir(book_id)
        filename = TranslationPaths._create_book_filename(
            book_id, FILES["OUTSIDE_HTML_SUFFIX"]
        )
        return FileUtil.join_paths(formatted_dir, filename)

    @staticmethod
    def get_tag_json_path(book_id: str) -> str:
        """タグ情報JSONファイルのパスを取得

        Args:
            book_id: 書籍ID

        Returns:
            str: タグ情報JSONファイルのパス

        Note:
            ファイル名はFILES["TAG_JSON"]から取得
        """
        tag_replace_dir = TranslationPaths.get_tag_replace_dir(book_id)
        return FileUtil.join_paths(tag_replace_dir, FILES["TAG_JSON"])

    @staticmethod
    def get_translated_html_path(book_id: str, version: Optional[int] = None) -> str:
        """翻訳済みHTMLファイルのパスを取得

        Args:
            book_id: 書籍ID
            version: バージョン番号（オプション）

        Returns:
            str: 翻訳済みHTMLファイルのパス

        Note:
            ファイル名はFILES["TRANSLATED_HTML_SUFFIX"]から取得
            バージョンが指定された場合は、ファイル名にバージョン番号を付加
        """
        translated_dir = TranslationPaths.get_translated_dir(book_id)
        suffix = (
            f"_v{version}{FILES['TRANSLATED_HTML_SUFFIX']}"
            if version
            else FILES["TRANSLATED_HTML_SUFFIX"]
        )
        filename = TranslationPaths._create_book_filename(book_id, suffix)
        return FileUtil.join_paths(translated_dir, filename)

    @staticmethod
    def get_translation_json_path(
        book_id: Union[str, int], version: Optional[int] = None
    ) -> str:
        """翻訳JSONファイルのパスを取得

        Args:
            book_id: 書籍ID
            version: バージョン番号（オプション）

        Returns:
            str: 翻訳JSONファイルのパス

        Note:
            バージョン番号が指定された場合はそのバージョンのJSONファイルパスを返す
            指定されない場合は空文字列を使用
        """
        translated_dir = TranslationPaths.get_translated_dir(book_id)
        version_str = str(version) if version is not None else ""
        return FileUtil.join_paths(
            translated_dir, TRANSLATION["AI_TRANSLATION_JSON"].format(version_str)
        )

    @staticmethod
    def get_tag_replace_file_path(book_id: str) -> str:
        """タグ置換ファイルのパスを取得

        Args:
            book_id: 書籍ID

        Returns:
            str: タグ置換ファイルのパス
        """
        return TranslationPaths.get_inside_html_path(book_id, DIRS["TAG_REPLACE"])

    @staticmethod
    def get_restored_html_path(book_id: str, version: Optional[int] = None) -> str:
        """復元済みHTMLファイルのパスを取得

        Args:
            book_id: 書籍ID
            version: バージョン番号（オプション）

        Returns:
            str: 復元済みHTMLファイルのパス

        Note:
            ファイル名はTRANSLATION["IMAGES_RESTORED_SUFFIX"]から取得
            バージョンが指定された場合は、ファイル名にバージョン番号を付加
        """
        translated_dir = TranslationPaths.get_translated_dir(book_id)
        suffix = (
            f"_v{version}{TRANSLATION['IMAGES_RESTORED_SUFFIX']}"
            if version
            else TRANSLATION["IMAGES_RESTORED_SUFFIX"]
        )
        filename = TranslationPaths._create_book_filename(book_id, suffix)
        return FileUtil.join_paths(translated_dir, filename)

    @staticmethod
    def get_final_output_html_path(book_id: str, version: Optional[int] = None) -> str:
        """最終出力HTMLファイルのパスを取得

        Args:
            book_id: 書籍ID
            version: バージョン番号（オプション）

        Returns:
            str: 最終出力HTMLファイルのパス

        Note:
            ディレクトリ名はDIRS["FINAL_OUTPUT"]から取得
            バージョンが指定された場合は、ファイル名にバージョン番号を付加
        """
        final_output_dir = TranslationPaths.get_raw_html_dir(book_id).replace(
            DIRS["RAW"], DIRS["FINAL_OUTPUT"]
        )
        suffix = f"_v{version}-images.html" if version else "-images.html"
        filename = TranslationPaths._create_book_filename(book_id, suffix)
        return FileUtil.join_paths(final_output_dir, filename)

    @staticmethod
    def get_epub_output_path(book_id: str, version: Optional[int] = None) -> str:
        """EPUB出力ファイルのパスを取得

        Args:
            book_id: 書籍ID
            version: バージョン番号（オプション）

        Returns:
            str: EPUB出力ファイルのパス

        Note:
            ファイル名は"pg{book_id}_v{version}.epub"の形式
            バージョンが指定されない場合は"pg{book_id}.epub"
        """
        final_output_dir = TranslationPaths.get_final_output_dir(book_id)
        filename = f"pg{book_id}_v{version}.epub" if version else f"pg{book_id}.epub"
        return FileUtil.join_paths(final_output_dir, filename)

    @staticmethod
    def get_raw_html_file_path(book_id: str, filename: str) -> str:
        """生のHTMLファイルのパスを取得

        Args:
            book_id: 書籍ID
            filename: HTMLファイル名

        Returns:
            str: 生のHTMLファイルのパス

        Note:
            ZIPファイルから解凍したHTMLファイルのパスを生成
        """
        html_dir = TranslationPaths.get_raw_html_dir(book_id)
        return FileUtil.join_paths(html_dir, filename)

    @staticmethod
    def get_source_file_path(book_id: str) -> str:
        """ソースファイルのパスを取得

        Args:
            book_id: 書籍ID

        Returns:
            str: ソースファイルのパス

        Note:
            - ディレクトリ名はDIRS["TAG_REPLACE"]から取得
            - ファイル名はFILES["INSIDE_HTML_SUFFIX"]から取得
        """
        tag_replace_dir = TranslationPaths.get_tag_replace_dir(book_id)
        filename = TranslationPaths._create_book_filename(
            book_id, FILES["INSIDE_HTML_SUFFIX"]
        )
        return FileUtil.join_paths(tag_replace_dir, filename)
