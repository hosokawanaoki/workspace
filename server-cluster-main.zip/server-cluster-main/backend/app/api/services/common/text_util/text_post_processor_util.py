"""テキスト後処理ユーティリティ"""

import json
import logging
from typing import Dict, List, Literal, Optional, TextIO, Tuple

from api.constants.constants import FILES, HTML_TAGS, SYSTEM
from api.services.common.exceptions.translation_exceptions import AfterTranslateError
from api.services.common.file_path_util.translation_paths import TranslationPaths
from api.services.common.text_util.tag_replacer_util import TagReplacerUtil
from api.services.common.text_util.tag_validator_util import TagValidatorUtil
from api.services.models.translation_target import TranslationTarget
from api.utils.file.directory_util import DirectoryUtil
from api.utils.file.epub_util import EPUBConfig, EPUBHandler, EPUBMetadata
from api.utils.file.file_util import FileUtil
from api.utils.file.file_writer_util import FileWriterUtil
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)


class TextPostProcessorUtil:
    """テキスト後処理を実行するユーティリティクラス

    翻訳されたテキストの後処理を行い、最終的なEPUBファイルを生成します。
    主な処理：
    1. プレースホルダーをHTMLタグに復元
    2. 外部HTMLと内部HTMLの結合
    3. 補助ファイルのコピー
    4. EPUB形式への変換
    """

    @staticmethod
    def process(target: TranslationTarget) -> List[str]:
        """翻訳後の処理を実行する

        Args:
            target: 翻訳対象

        Returns:
            List[str]: 見つからなかったプレースホルダーのリスト

        Raises:
            AfterTranslateError: 処理中にエラーが発生した場合
        """
        try:
            book_id = target.book_id
            version = target.batch.translation_version.version if target.batch else None
            logger.info(f"書籍ID {book_id} バージョン {version} の後処理を開始")
            final_output_dir = TranslationPaths.get_final_output_dir(book_id)

            TextPostProcessorUtil._prepare_output_directory(final_output_dir)
            not_found_placeholders = TextPostProcessorUtil._process_html_content(
                book_id, version, target
            )
            TextPostProcessorUtil._process_auxiliary_files(book_id, target, version)
            TextPostProcessorUtil._update_permissions(book_id)

            # EPUBファイルの生成確認
            epub_output = TranslationPaths.get_epub_output_path(book_id, version)
            if not FileWriterUtil.check_path_exists(epub_output):
                raise AfterTranslateError(
                    f"EPUBファイルが生成されていません: {epub_output}"
                )

            logger.info(f"書籍ID {book_id} バージョン {version} の後処理が完了しました")
            return not_found_placeholders

        except AfterTranslateError:
            raise
        except Exception as e:
            error_msg = f"書籍ID {book_id} の後処理でエラー: {str(e)}"
            logger.exception(error_msg)
            raise AfterTranslateError(error_msg) from e

    @staticmethod
    def _prepare_output_directory(output_dir: str) -> None:
        """出力ディレクトリを準備する

        Args:
            output_dir: 出力ディレクトリパス

        Raises:
            AfterTranslateError: ディレクトリ作成に失敗した場合
        """
        try:
            DirectoryUtil.create_directory_with_permissions(output_dir)
            logger.info(f"出力ディレクトリを作成: {output_dir}")
        except Exception as e:
            raise AfterTranslateError(f"出力ディレクトリの作成に失敗: {str(e)}") from e

    @staticmethod
    def _process_html_content(
        book_id: str, version: Optional[int], target: TranslationTarget
    ) -> List[str]:
        """HTMLコンテンツを処理する

        Args:
            book_id: 書籍ID
            version: バージョン番号
            target: 翻訳対象

        Returns:
            List[str]: 見つからなかったプレースホルダーのリスト

        Raises:
            AfterTranslateError: HTML処理に失敗した場合
        """
        try:
            translated_html_path = TranslationPaths.get_translated_html_path(
                book_id, version
            )
            html_content = FileUtil.read_file(translated_html_path)
            logger.info(f"翻訳済みHTMLを読み込み: {translated_html_path}")

            json_file = TranslationPaths.get_tag_json_path(book_id)
            restored_html = TranslationPaths.get_restored_html_path(book_id, version)
            not_found_placeholders = (
                TextPostProcessorUtil._restore_html_from_placeholders(
                    json_file, html_content, restored_html
                )
            )

            outside_html = TranslationPaths.get_outside_html_path(book_id)
            final_output_html = TranslationPaths.get_final_output_html_path(
                book_id, version
            )
            TextPostProcessorUtil._combine_html_files(
                outside_html, restored_html, final_output_html
            )
            return not_found_placeholders

        except Exception as e:
            raise AfterTranslateError(f"HTML処理に失敗: {str(e)}") from e

    @staticmethod
    def _process_auxiliary_files(
        book_id: str, target: TranslationTarget, version: Optional[int]
    ) -> None:
        """補助ファイルを処理する

        Args:
            book_id: 書籍ID
            target: 翻訳対象
            version: バージョン番号

        Raises:
            AfterTranslateError: 補助ファイル処理に失敗した場合
        """
        try:
            raw_dir = TranslationPaths.get_raw_html_dir(book_id)
            final_output_dir = TranslationPaths.get_final_output_dir(book_id)
            FileUtil.copy_files_exclude(
                raw_dir, final_output_dir, FILES["HTML_EXTENSIONS"]
            )
            logger.info("補助ファイルをコピー")

            # EPUBファイルの生成
            config = EPUBConfig(language="ja")
            title = (
                f"{target.book_id}_{target.book.title_jp}"
                if target.book.title_jp
                else target.book_id
            )
            metadata = EPUBMetadata(
                title=title, author=target.book.author, language="ja"
            )
            logger.info(
                f"EPUBメタデータを設定: title={title}, author={target.book.author}"
            )

            final_output_html = TranslationPaths.get_final_output_html_path(
                book_id, version
            )
            epub_output = TranslationPaths.get_epub_output_path(book_id, version)
            cover_image = TranslationPaths.get_cover_image_path(book_id)

            EPUBHandler.convert_to_epub(
                input_path=final_output_html,
                output_path=epub_output,
                cover_image_path=cover_image,
                metadata=metadata,
                config=config,
            )
            logger.info(f"EPUBファイルを生成: {epub_output}")

        except Exception as e:
            raise AfterTranslateError(f"補助ファイル処理に失敗: {str(e)}") from e

    @staticmethod
    def _restore_html_from_placeholders(
        json_file_path: str, html_content: str, output_file_path: str
    ) -> List[str]:
        """プレースホルダーを元のタグに復元する

        Args:
            json_file_path: JSONファイルパス
            html_content: HTMLコンテンツ
            output_file_path: 出力ファイルパス

        Returns:
            List[str]: 見つからなかったプレースホルダーのリスト

        Raises:
            AfterTranslateError: タグ復元に失敗した場合
        """
        try:
            content = FileUtil.read_file(json_file_path)
            tag_info_list = json.loads(content)

            html_content = TagReplacerUtil.html_tag_recovery(html_content)
            errors = TagValidatorUtil.check_placeholders_existence(
                html_content, tag_info_list
            )
            restored_html = TagReplacerUtil.replace_placeholders_with_tags(
                html_content, tag_info_list
            )

            FileWriterUtil.save_file_with_permission(output_file_path, restored_html)

            if errors:
                logger.warning(f"プレースホルダー {len(errors)}件が未検出")
            logger.info(f"タグを復元: {output_file_path}")

            return errors

        except Exception as e:
            raise AfterTranslateError(f"タグ復元に失敗: {str(e)}") from e

    @staticmethod
    def _combine_html_files(
        outside_html_path: str, restored_html_path: str, final_output_path: str
    ) -> None:
        """HTMLファイルを結合する

        Args:
            outside_html_path: 外部HTMLパス
            restored_html_path: 復元HTMLパス
            final_output_path: 最終出力パス

        Raises:
            AfterTranslateError: HTML結合に失敗した場合
        """
        try:
            outside_html = FileUtil.read_file(outside_html_path)
            restored_html = FileUtil.read_file(restored_html_path)

            combined_html = outside_html.replace(
                HTML_TAGS["INSIDE_TAG_PLACEHOLDER"], restored_html
            )

            FileWriterUtil.save_file_with_permission(final_output_path, combined_html)
            logger.info(f"HTMLファイルを結合: {final_output_path}")

        except Exception as e:
            raise AfterTranslateError(f"HTML結合に失敗: {str(e)}") from e

    @staticmethod
    def _update_permissions(book_id: str) -> None:
        """ファイル権限を更新する

        Args:
            book_id: 書籍ID
        """
        try:
            book_dir = TranslationPaths.get_book_dir(book_id)
            DirectoryUtil.change_permissions_recursively(book_dir)
            logger.info(f"ファイル権限を更新: {book_dir}")
        except Exception as e:
            logger.warning(f"権限更新に失敗しましたが、処理は継続します: {str(e)}")

    @staticmethod
    def replace_tags_with_placeholders(html_path: str) -> Tuple[str, List[Dict]]:
        """HTMLファイル内のタグをプレースホルダーに置き換える

        Args:
            html_path (str): HTMLファイルのパス

        Returns:
            Tuple[str, List[Dict]]: 処理済みHTMLと置換情報のリスト

        Raises:
            GutenbergProcessingError: タグ置換処理中にエラーが発生した場合
        """
        try:
            # HTMLファイルの読み込み
            mode: Literal["r"] = "r"
            file: TextIO
            with open(
                html_path,
                mode=mode,
                encoding=SYSTEM["DEFAULT_ENCODING"],
            ) as file:
                html_content = file.read()

            soup = BeautifulSoup(html_content, "html.parser")
            tag_info_list = []
            tag_counter = 1

            # HTMLタグをプレースホルダーに置換
            for element in soup.find_all(True):
                placeholder = f"tag{tag_counter}"
                tag_info = {
                    "placeholder": placeholder,
                    "tag_name": element.name,
                    "attributes": dict(element.attrs),
                    "self_close": element.is_empty_element,
                }

                # 開始タグの挿入
                start_tag = soup.new_string(
                    HTML_TAGS["TAG_START_FORMAT"].format("tag" + str(tag_counter))
                )
                element.insert_before(start_tag)

                # 終了タグの挿入（自己終了タグでない場合）
                if not element.is_empty_element:
                    end_tag = soup.new_string(
                        HTML_TAGS["TAG_END_FORMAT"].format("tag" + str(tag_counter))
                    )
                    element.insert_after(end_tag)

                tag_info_list.append(tag_info)

                # 子要素を保持しながら元のタグを削除
                for child in list(element.children):
                    element.insert_before(child)
                element.decompose()

                tag_counter += 1

            return str(soup), tag_info_list

        except Exception as e:
            error_msg = f"タグ置換処理中にエラー発生: {str(e)}"
            logger.exception(error_msg)
