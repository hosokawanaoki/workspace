"""タグ検証ユーティリティ"""

import re
from typing import Dict, List, Tuple

from api.constants.constants import HTML_TAGS
from api.services.types.translator import Translations, TranslationStatus


class TagValidatorUtil:
    """タグの検証を行うユーティリティクラス"""

    @staticmethod
    def compare_tags(
        source_text: str, translated_text: str
    ) -> Tuple[List[str], List[str], List[str], List[str], List[str]]:
        """原文と訳文のタグを比較する

        Args:
            source_text: 原文テキスト
            translated_text: 翻訳済みテキスト

        Returns:
            Tuple[List[str], List[str], List[str], List[str], List[str]]:
                - source_tags: 原文のタグのリスト
                - translated_tags: 訳文のタグのリスト
                - missing_tags: 欠損しているタグのリスト
                - extra_tags: 余分なタグのリスト
                - duplicate_tags: 重複しているタグのリスト
        """
        # タグの抽出
        source_tags = re.findall(r"\[/?tag\d+\]", source_text) if source_text else []
        translated_tags = (
            re.findall(r"\[/?tag\d+\]", translated_text) if translated_text else []
        )

        # 欠損タグを検出
        missing_tags = [tag for tag in source_tags if tag not in translated_tags]
        # 余分なタグを検出
        extra_tags = [tag for tag in translated_tags if tag not in source_tags]
        # 重複化されたタグを検出
        tag_counts = {}
        for tag in translated_tags:
            tag_counts[tag] = tag_counts.get(tag, 0) + 1
        duplicate_tags = [tag for tag, count in tag_counts.items() if count > 1]

        return source_tags, translated_tags, missing_tags, extra_tags, duplicate_tags

    @staticmethod
    def check_placeholders_existence(text: str, tag_info_list: List[Dict]) -> List[str]:
        """プレースホルダーの存在チェックを行い、問題があればリストにして返す

        Args:
            text: チェック対象のテキスト
            tag_info_list: タグ情報のリスト

        Returns:
            List[str]: 見つからなかったプレースホルダーのリスト
        """
        not_found_placeholders = []

        for tag_info in tag_info_list:
            placeholder = tag_info["placeholder"]
            placeholder_start = HTML_TAGS["TAG_START_FORMAT"].format(placeholder)
            placeholder_end = HTML_TAGS["TAG_END_FORMAT"].format(placeholder)

            # 開始タグの検証
            start_count = text.count(placeholder_start)
            if start_count == 0:
                not_found_placeholders.append(placeholder_start)
            elif start_count > 1:
                not_found_placeholders.append(f"{placeholder_start}（重複）")

            # 終了タグの検証（self_close でない場合のみ）
            if not tag_info.get("self_close", False):
                end_count = text.count(placeholder_end)
                if end_count == 0:
                    not_found_placeholders.append(placeholder_end)
                elif end_count > 1:
                    not_found_placeholders.append(f"{placeholder_end}（重複）")

        return not_found_placeholders

    @staticmethod
    def count_tag_errors(translations: List[Dict]) -> int:
        """翻訳データのタグエラー数を計算する

        Args:
            translations: 翻訳データのリスト

        Returns:
            int: タグエラーの総数
        """
        return sum(
            1
            for chunk in translations
            if chunk.get("translated_text") is not None
            and (
                (chunk.get("missing_tags", []) and len(chunk["missing_tags"]) > 0)
                or (chunk.get("extra_tags", []) and len(chunk["extra_tags"]) > 0)
                or (
                    chunk.get("duplicate_tags", []) and len(chunk["duplicate_tags"]) > 0
                )
            )
        )

    @staticmethod
    def evaluate_tag_state(translation: Translations) -> int:
        """タグの状態を評価する

        Args:
            translation: 評価対象の翻訳データ

        Returns:
            int: タグの問題数（少ないほど良い）
        """
        return (
            len(translation.missing_tags or [])
            + len(translation.extra_tags or [])
            + len(translation.duplicate_tags or [])
        )

    @staticmethod
    def validate_translation_tags(translation: Translations) -> bool:
        """翻訳のタグを検証し、状態を更新する

        Args:
            translation: 検証対象の翻訳データ

        Returns:
            bool: タグの不一致がない場合はTrue
        """
        # タグ修復後のテキストが存在する場合は、そのテキストでタグを検証
        # 存在しない場合は、オリジナルの翻訳テキストで検証
        target_text = translation.tag_recoveried or translation.translated_text
        if target_text is None:
            return False

        source_tags, translated_tags, missing_tags, extra_tags, duplicate_tags = (
            TagValidatorUtil.compare_tags(translation.source_text, target_text)
        )

        # タグの不一致情報を更新
        translation.source_tags = source_tags
        translation.translated_tags = translated_tags
        translation.missing_tags = missing_tags
        translation.extra_tags = extra_tags
        translation.duplicate_tags = duplicate_tags

        # タグエラー数を記録
        if translation.status == TranslationStatus.PROCESSED:
            # 翻訳直後の状態を記録
            translation.tag_error_count[TranslationStatus.PROCESSED] = (
                TagValidatorUtil.evaluate_tag_state(translation)
            )
        elif translation.status == TranslationStatus.TAG_RECOVERED:
            # タグ修復後の状態を記録
            if TranslationStatus.PROCESSED in translation.tag_error_count:
                translation.tag_error_count[TranslationStatus.TAG_RECOVERED] = (
                    TagValidatorUtil.evaluate_tag_state(translation)
                )

        return not (missing_tags or extra_tags or duplicate_tags)
