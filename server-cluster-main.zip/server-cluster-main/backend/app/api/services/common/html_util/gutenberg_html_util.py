import logging

from api.constants.constants import DIRS, GUTENBERG, HTML_TAGS
from api.services.common.file_path_util.translation_paths import TranslationPaths
from api.services.common.html_util.html_formatter_util import HtmlFormatterUtil
from api.services.scraping.exceptions.scraping_exceptions import (
    GutenbergProcessingError,
)
from api.utils.file.directory_util import DirectoryUtil
from api.utils.file.file_writer_util import FileWriterUtil
from api.utils.file.html_file_util import HTMLFileUtil

logger = logging.getLogger(__name__)


class GutenbergHtmlUtil:
    """Project Gutenberg用のHTMLユーティリティ

    Project Gutenberg固有のHTML整形処理を提供するユーティリティクラスです。
    """

    @staticmethod
    def process_html_content(html_file_path: str, book_id: str) -> str:
        """HTMLファイルを処理し、不要な要素を削除して整形する

        Args:
            html_file_path (str): HTMLファイルのパス
            book_id (str): 書籍ID

        Returns:
            str: 処理済みHTMLファイルのパス

        Raises:
            GutenbergProcessingError: HTML処理中にエラーが発生した場合
        """
        try:
            # 出力ディレクトリの作成
            output_dir = TranslationPaths.get_formatted_html_dir(book_id)
            DirectoryUtil.create_directory_with_permissions(output_dir)

            # HTMLファイルの読み込みとパース
            soup = HTMLFileUtil.parse_html(html_file_path)

            # bodyタグの取得と検証
            body_content = HtmlFormatterUtil.get_body_content(soup)
            if not body_content:
                raise GutenbergProcessingError(
                    "HTMLファイル内にbodyタグが見つかりません"
                )

            # Project Gutenberg固有の要素を削除
            HtmlFormatterUtil.remove_elements_by_class(
                body_content, HTML_TAGS["PG_BOILERPLATE_CLASS"]
            )
            HtmlFormatterUtil.remove_elements_by_class(body_content, "pagenum")

            # タイトルプレフィックスの削除
            HtmlFormatterUtil.replace_text_in_nodes(
                body_content, GUTENBERG["TITLE_PREFIX"], ""
            )

            # 段落タグ内のテキストを整形
            for p_tag in body_content.find_all("p"):
                formatted_tag = HtmlFormatterUtil.format_paragraph_text(p_tag)
                p_tag.replace_with(formatted_tag)

            # 本文コンテンツの保存
            inside_html_path = TranslationPaths.get_inside_html_path(
                book_id, DIRS["FORMATTED"]
            )
            FileWriterUtil.save_html_file(inside_html_path, str(body_content))

            # 外部HTMLの保存
            HtmlFormatterUtil.replace_body_with_placeholder(
                soup, body_content, HTML_TAGS["BODY_PLACEHOLDER"]
            )
            outside_html_path = TranslationPaths.get_outside_html_path(book_id)
            FileWriterUtil.save_html_file(outside_html_path, str(soup))

            return inside_html_path

        except Exception as e:
            error_msg = f"HTML処理中にエラー発生: {str(e)}"
            logger.exception(error_msg)
            raise GutenbergProcessingError(error_msg)
