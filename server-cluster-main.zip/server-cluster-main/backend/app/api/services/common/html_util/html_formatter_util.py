"""HTML整形ユーティリティ"""

import logging
from typing import Optional

from bs4 import BeautifulSoup, Tag

logger = logging.getLogger(__name__)


class HtmlFormatterUtil:
    """HTMLコンテンツを整形するユーティリティクラス"""

    @staticmethod
    def format_paragraph_text(p_tag: Tag) -> Tag:
        """段落タグ内のテキストを整形する

        Args:
            p_tag: 段落タグ要素

        Returns:
            Tag: 整形後の段落タグ要素
        """
        original_html = str(p_tag)
        cleaned_text = " ".join(original_html.replace("\n", " ").split())
        return BeautifulSoup(cleaned_text, "html.parser")

    @staticmethod
    def remove_elements_by_class(soup: BeautifulSoup, class_name: str) -> None:
        """指定したクラス名を持つ要素を削除する

        Args:
            soup: BeautifulSoupオブジェクト
            class_name: 削除対象のクラス名
        """
        for element in soup.find_all(class_=class_name):
            element.decompose()

    @staticmethod
    def replace_text_in_nodes(
        soup: BeautifulSoup, old_text: str, new_text: str
    ) -> None:
        """テキストノード内の特定のテキストを置換する

        Args:
            soup: BeautifulSoupオブジェクト
            old_text: 置換対象のテキスト
            new_text: 置換後のテキスト
        """
        for text_node in soup.find_all(string=True):
            if old_text in text_node:
                text_node.replace_with(text_node.replace(old_text, new_text))

    @staticmethod
    def get_body_content(soup: BeautifulSoup) -> Optional[Tag]:
        """bodyタグの内容を取得する

        Args:
            soup: BeautifulSoupオブジェクト

        Returns:
            Optional[Tag]: bodyタグの内容。bodyタグが存在しない場合はNone
        """
        return soup.body

    @staticmethod
    def replace_body_with_placeholder(
        soup: BeautifulSoup, body_content: Tag, placeholder_html: str
    ) -> None:
        """bodyの内容をプレースホルダーで置き換える

        Args:
            soup: BeautifulSoupオブジェクト
            body_content: 置き換え対象のbody内容
            placeholder_html: プレースホルダーのHTML
        """
        placeholder = BeautifulSoup(placeholder_html, "html.parser")
        body_content.replace_with(placeholder)
