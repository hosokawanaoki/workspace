import logging

from api.models.translation import Translation
from api.models.translation_batch import TranslationBatch
from api.models.translation_version import TranslationVersion
from api.services.common.file_path_util.translation_paths import TranslationPaths
from api.utils.file.file_util import FileUtil

logger = logging.getLogger(__name__)


class TranslationService:
    """Translationの操作を提供するサービス"""

    @staticmethod
    def delete_by_version(version: TranslationVersion) -> None:
        """翻訳バージョンとそれに関連するすべてのデータを削除する

        以下のデータを削除します：
        - 翻訳データ (Translation)
        - 翻訳バッチ (TranslationBatch)
        - 関連ファイル (JSON, HTML, タグ置換ファイル)
        - 翻訳バージョン (TranslationVersion)

        Args:
            version (TranslationVersion): 翻訳バージョン
        """
        try:
            book_id = version.book.book_id
            version_id = version.version

            # 翻訳データの削除
            Translation.filter(translation_version=version).delete()
            logger.info(
                f"書籍 {book_id} のバージョン {version_id} の翻訳データを削除しました"
            )

            # バッチの削除
            TranslationBatch.objects.filter(
                translation_version=version, book_id=version.book.id
            ).delete()
            logger.info(f"書籍 {book_id} のバッチを削除しました")

            # バージョン固有の翻訳ファイルの削除
            translation_json_path = TranslationPaths.get_translation_json_path(
                book_id, version_id
            )
            FileUtil.remove_file(translation_json_path)
            logger.info(f"翻訳JSONファイルを削除しました: {translation_json_path}")

            # バージョンの削除
            version.delete()
            logger.info(f"書籍 {book_id} のバージョン {version_id} を削除しました")

        except Exception as e:
            logger.error(
                f"バージョン関連データの削除中にエラーが発生しました: {str(e)}"
            )
            raise
