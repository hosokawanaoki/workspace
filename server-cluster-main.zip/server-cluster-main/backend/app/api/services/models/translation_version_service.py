from typing import List, Optional

from api.models.book import Book
from api.models.translation_version import TranslationVersion
from django.db.models import Max


class TranslationVersionService:
    """TranslationVersionの操作を提供するサービス"""

    @staticmethod
    def get_next_version_number(book: Book) -> int:
        """書籍の次のバージョン番号を取得する

        Args:
            book (Book): 書籍オブジェクト

        Returns:
            int: 次のバージョン番号
        """
        max_version = TranslationVersion.objects.filter(book=book).aggregate(
            Max("version")
        )["version__max"]
        return (max_version or 0) + 1

    @staticmethod
    def get_versions_for_book(book: Book) -> List[TranslationVersion]:
        """書籍に関連する翻訳バージョンを取得する

        Args:
            book (Book): 書籍オブジェクト

        Returns:
            List[TranslationVersion]: 翻訳バージョンのリスト
        """
        return list(TranslationVersion.filter(book=book))

    @staticmethod
    def get_version_by_book_id(
        book_id: str, version_number: int = 1
    ) -> Optional[TranslationVersion]:
        """書籍IDとバージョン番号から翻訳バージョンを取得する

        Args:
            book_id (str): 書籍ID
            version_number (int, optional): バージョン番号. デフォルトは1.

        Returns:
            Optional[TranslationVersion]: 翻訳バージョン、存在しない場合はNone
        """
        try:
            # まずBookモデルから対象の書籍を取得
            book = Book.objects.get(book_id=book_id)
            # 書籍とバージョン番号で翻訳バージョンを取得
            return TranslationVersion.get(book=book, version=version_number)
        except (Book.DoesNotExist, TranslationVersion.DoesNotExist):
            return None

    @staticmethod
    def get_latest_version_by_book_id(book_id: str) -> Optional[TranslationVersion]:
        """書籍IDから最新の翻訳バージョンを取得する

        Args:
            book_id (str): 書籍ID

        Returns:
            Optional[TranslationVersion]: 最新の翻訳バージョン、存在しない場合はNone
        """
        try:
            # まずBookモデルから対象の書籍を取得
            book = Book.objects.get(book_id=book_id)
            # 書籍に紐づく最新のバージョンを取得
            return TranslationVersion.filter(book=book).order_by("-version").first()
        except Book.DoesNotExist:
            return None
