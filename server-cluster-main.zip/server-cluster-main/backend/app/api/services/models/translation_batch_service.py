import logging
from typing import Optional

from api.models.book import Book
from api.models.translation_batch import TranslationBatch
from api.models.translation_version import TranslationVersion

logger = logging.getLogger(__name__)


class TranslationBatchService:
    """TranslationBatchの操作を提供するサービス"""

    @staticmethod
    def create_batch(book: Book, version_number: int = 1, **kwargs) -> TranslationBatch:
        """新しいバッチを作成する

        Args:
            book (Book): 対象の書籍
            version_number (int, optional): バージョン番号. デフォルトは1.
            **kwargs: その他のフィールド値

        Returns:
            TranslationBatch: 作成されたバッチインスタンス
        """
        # TranslationVersionを取得または作成
        version = TranslationVersion.get_or_create_version(book, version_number)

        data = {
            "book": book,
            "status": "pending",
            "translation_version": version,
            **kwargs,
        }
        return TranslationBatch.objects.create(**data)

    @staticmethod
    def get_latest_for_book(book: Book) -> Optional[TranslationBatch]:
        """書籍の最新の翻訳バッチを取得する

        Args:
            book (Book): 対象の書籍

        Returns:
            Optional[TranslationBatch]: 最新の翻訳バッチ、存在しない場合はNone
        """
        return TranslationBatch.filter(book=book).order_by("-batch_time").first()

    @staticmethod
    def find_oldest_batch_book(
        books: list[Book],
    ) -> tuple[Optional[Book], Optional[TranslationBatch]]:
        """書籍リストから最も古いバッチを持つ書籍とバッチを取得する

        Args:
            books (list[Book]): 書籍のリスト

        Returns:
            tuple[Optional[Book], Optional[TranslationBatch]]:
                最も古いバッチを持つ書籍とバッチのタプル、該当するものがない場合は(None, None)
        """
        logger.info(f"処理対象の書籍数: {len(books)}")

        try:
            # 書籍IDのリストを取得
            book_ids = [book.id for book in books]

            # 各書籍の最新バージョンと最古のバッチを1回のクエリで取得
            oldest_batch = (
                TranslationBatch.objects.filter(book_id__in=book_ids, status="pending")
                .select_related("book", "translation_setting", "translation_version")
                .order_by("book_id", "-translation_version__version", "batch_time")
                .first()
            )

            if oldest_batch:
                logger.info(
                    f"最も古いバッチが見つかりました: 書籍ID {oldest_batch.book.book_id}, "
                    f"バッチ時刻 {oldest_batch.batch_time}"
                )
                return oldest_batch.book, oldest_batch
            else:
                logger.info("処理可能な書籍が見つかりませんでした")
                return None, None

        except Exception as e:
            logger.error(f"バッチ検索中にエラーが発生: {str(e)}")
            return None, None
