import os
from datetime import datetime

from api.models.book import Book
from api.models.translation_batch import TranslationBatch
from api.models.translation_version import TranslationVersion
from api.services.common.logging_utils import log_info_with_book_id
from api.services.translation.models.translator_config import TranslatorConfig
from django.utils import timezone


class TranslationTarget:
    """翻訳対象を表すクラス

    bookとbatchの組み合わせを管理し、関連する操作を提供します。
    将来的な拡張性を考慮し、翻訳処理に必要な情報や操作をカプセル化します。

    Attributes:
        book (Book): 翻訳対象の書籍
        batch (TranslationBatch): 関連する翻訳バッチ
        config (TranslatorConfig): 翻訳設定。プロンプトの生成に使用。
    """

    def __init__(
        self,
        book: Book,
        batch: TranslationBatch,
        config: TranslatorConfig,
    ):
        """TranslationTargetを初期化する

        Args:
            book (Book): 翻訳対象の書籍
            batch (TranslationBatch): 関連する翻訳バッチ
            config (TranslatorConfig): 翻訳設定
        """
        self.book = book
        self.batch = batch
        self.config = config

    def mark_as_error(self) -> None:
        """ターゲットをエラー状態にマークする"""
        self.book.set_status(Book.get_status_type("error"))
        self.batch.set_status("failed")

    def start_translation(self) -> None:
        """翻訳処理を開始する"""
        self.book.set_status(Book.get_status_type("ai-execution"))
        self.batch.batch_time = datetime.now()
        self.batch.save(update_fields=["batch_time"])

    def update_retry_count(self) -> None:
        """リトライ回数を更新する"""
        self.batch.retry_count += 1
        self.batch.last_retry_time = timezone.now()
        self.batch.set_status("pending")
        self.batch.save(update_fields=["retry_count", "last_retry_time"])
        self.book.set_status(Book.get_status_type("waiting"))

    def has_reached_max_retries(self) -> bool:
        """最大リトライ回数に達したかどうかを確認する

        Returns:
            bool: 最大リトライ回数に達している場合はTrue
        """
        return self.batch.has_reached_max_retries()

    @property
    def book_id(self) -> str:
        """書籍IDを取得する

        Returns:
            str: 書籍ID
        """
        return self.book.book_id

    @property
    def needs_info_update(self) -> bool:
        """書籍情報の更新が必要かどうかを確認する

        Returns:
            bool: タイトルまたは著者が未設定の場合はTrue
        """
        return not self.book.title or not self.book.author

    @property
    def is_waiting(self) -> bool:
        """待機状態かどうかを確認する

        Returns:
            bool: 待機状態の場合はTrue
        """
        return self.book.is_waiting()

    @property
    def is_cancelled(self) -> bool:
        """キャンセル状態かどうかを確認する

        Returns:
            bool: キャンセル状態の場合はTrue
        """
        return self.book.is_cancelled()

    @property
    def model(self) -> str:
        """使用するモデルを取得する

        Returns:
            str: モデル名
        """
        return self.batch.get_model

    @property
    def translation_version(self) -> "TranslationVersion":
        """翻訳バージョンを取得する

        Returns:
            TranslationVersion: 翻訳バージョンオブジェクト
        """
        return self.batch.translation_version

    def refresh_book(self) -> None:
        """bookを再取得する

        Note:
            - DBから最新のbook情報を取得して更新する
            - キャンセル状態の変更を検知するために使用
        """
        self.book.refresh_book()

    def handle_cancellation(
        self, message: str = "キャンセルにより処理を終了しました"
    ) -> bool:
        """キャンセル状態を処理する

        Args:
            message (str): キャンセル時のメッセージ

        Returns:
            bool: キャンセル状態の場合はTrue

        Note:
            - キャンセル状態をチェックし、必要な後処理を実行
            - 翻訳処理の中断判断に使用
            - キャンセル時はバッチを停止状態に更新
        """
        # DBから最新の状態を取得
        self.refresh_book()

        if self.is_cancelled:
            # バッチを停止状態に更新
            self.batch.status_message = message
            self.batch.set_status("stopped")
            self.batch.save(update_fields=["status_message", "status"])

            # ログ出力して即座に終了
            log_info_with_book_id(self.book_id, message)
            os._exit(0)  # 即座にプロセスを終了
        return False

    def update_translation_progress(self, current_index: int, chunks: list) -> None:
        """翻訳の進捗状況を更新する

        Args:
            current_index (int): 現在の翻訳インデックス
            chunks (list): 翻訳チャンクのリスト

        Note:
            - 進捗状況を「current_index/total_chunks」の形式で表示
            - タグエラーの数もカウントして表示
        """
        self.batch.update_translation_progress(current_index, len(chunks))
