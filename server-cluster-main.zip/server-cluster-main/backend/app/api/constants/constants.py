"""
アプリケーション全体で使用する定数を定義するモジュール
"""

# ベースディレクトリとパス関連
BASE_DIR = "/data"
BOOK_BASE_PATH = "書籍一式"

# ディレクトリ構造
DIRS = {
    "RAW": "原文",
    "FORMATTED": "成形済",
    "TAG_REPLACE": "タグ置換",
    "TRANSLATED": "翻訳済",
    "FINAL_OUTPUT": "最終出力",
    "IMAGES": "images",
}

# ファイル関連
FILES = {
    "HTML_EXTENSIONS": (".html", ".htm"),
    "INSIDE_HTML_SUFFIX": "-images_inside.html",
    "OUTSIDE_HTML_SUFFIX": "-images_outside.html",
    "TRANSLATED_HTML_SUFFIX": "-翻訳済.html",
    "TAG_JSON": "タグ置換.json",
    "COVER_IMAGE": "cover.jpg",
    "CATALOG_EXCEL": "gutenberg_catalog.xlsx",
}

# Project Gutenberg関連
GUTENBERG = {
    "ZIP_URL": "https://www.gutenberg.org/cache/epub/{}/pg{}-h.zip",
    "TITLE_PREFIX": "The Project Gutenberg eBook of ",
}

# HTMLタグ関連
HTML_TAGS = {
    "BODY_PLACEHOLDER": "[tag_inside_pjgtj]",
    "TAG_START_FORMAT": "[{}]",
    "TAG_END_FORMAT": "[/{}]",
    "INSIDE_TAG_PLACEHOLDER": "[tag_inside_pjgtj]",
    "PG_BOILERPLATE_CLASS": "pg-boilerplate",
}

# システム設定
SYSTEM = {"DEFAULT_PERMISSION": 0o777, "DEFAULT_ENCODING": "utf-8"}

STALL_THRESHOLD_MINUTES = 5  # 停止判定の閾値（分）
# 翻訳関連
TRANSLATION = {
    "MODEL_NAME": "claude3-gemini",  # 内部キーを使用（model_nameではない）
    "MAX_LENGTH": 1000,
    "MAX_ATTEMPTS": 3,
    "AI_TRANSLATION_JSON": "AI翻訳{}.json",
    "IMAGES_RESTORED_SUFFIX": "-images_restored.html",
    "UPDATE_INTERVAL": 10,  # 状態更新間隔（回数）
    "EXCLUDED_ABBREVIATIONS": [
        "Mr",
        "Mrs",
        "Dr",
        "Ms",
        "Prof",
        "Rev",
        "Sr",
        "Jr",
        "Ph.D",
    ],  # 文分割時に除外する略語
}


# 書籍ステータス
BOOK_STATUS = {
    "NOT_FOUND": "notfound",
    "TRANSLATED": "translated",
    "RAW": "raw",
}
