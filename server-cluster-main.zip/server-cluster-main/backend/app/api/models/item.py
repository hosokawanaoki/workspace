from api.models.base import BaseModel
from django.db import models


class Item(BaseModel):
    name = models.CharField(max_length=100)
    description = models.TextField()
