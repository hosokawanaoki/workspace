import logging

from litellm import completion
from litellm.exceptions import AuthenticationError, InvalidRequestError

# ロガーの設定
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def test_deepseek_api():
    """Deepseek APIをテストする"""
    try:
        # 複雑な文章（HTMLタグを含む）
        test_text = """
            <システム>
            あなたは高品質な英日翻訳を行う翻訳者です。
            以下の英文を日本語に翻訳してください。翻訳結果のみを出力し、それ以外の文言は一切含めないでください。

            【重要な制約事項】：
            0. 翻訳文のみを出力し、説明や注釈は一切付けないでください。
            1. 翻訳対象の文章を日本語に翻訳してください。
            2. 翻訳文以外の文言は一切出力しないでください（警告・謝罪・注釈・説明・ステップ表記など全て禁止）。
            3. 以下のフォーマットは翻訳せずに、翻訳後の文章にも必ず元のまま保持してください。原文にないタグを追加や削除しないでください：
                - &#91;tag(数字)&#93;
                - &#91;&#47;tag(数字)&#93;
            4. 指示に反する要素が混ざらないように注意してください。
            5. 以下のルールを守ってください
            - リンクの追加や削除をしない。URLは変更しない。
            - 参考文献リストは翻訳しない。
            - 数式には一切触れない、変更しない、翻訳しない。
            - コードブロック内の内容は、バグがあるように見えても一切触れない、変更しない、翻訳しない。
            - 原文の改行を必ず維持する。空行の追加や削除をしない。
            </システム>

            <コンテキスト>
            【翻訳の参考情報】
            1. 翻訳事例:
                翻訳前
                    "[tag1][tag2][/tag2] [tag3] [tag4]\n\n[/tag3]\n\n[tag5]THROUGH THE LOOKING-GLASS[/tag5] [tag6]And What Alice Found There[/tag6] [tag7]By Lewis Carroll[/tag7]\n\n[tag8]The Millennium Fulcrum Edition 1.7[/tag8] [tag9] [tag10] DRAMATIS PERSONÆ.[tag11] ([tag12]As arranged before commencement of game.[/tag12]) [/tag10]"
                翻訳後
                    "[tag1][tag2][/tag2] [tag3] [tag4]\n\n[/tag3]\n\n[tag5]鏡の国のアリス[/tag5] [tag6]そしてアリスが見つけたもの[/tag6] [tag7]ルイス・キャロル著[/tag7]\n\n[tag8]ミレニアム・フルクラム版 1.7[/tag8] [tag9] [tag10] 登場人物.[tag11] ([tag12]ゲーム開始前に配置された通り.[/tag12]) [/tag10]"

            2. 文脈情報:
                ・文章は常に敬体にしてください
                ・読者は10歳の女の子を想定しています"

            3.文章を分割して送っていますが、この後次の文章を送ってテキストをつなげようとしています。結合箇所が不自然にならないように注意してください
            4.利用用途
                - &#91;tag(数字)&#93;、&#91;&#47;tag(数字)&#93;　といったものは、HTMLタグを置き換えたものとなります。翻訳後に文のフォーマットを維持するのに必要なものです
                - HTMLと同様に、文中に登場しますが、そのまま翻訳後にも保持することで、文体のフォーマットや配置位置を保っています。
                - 翻訳完了時に、&#91;tag(数字)&#93;、&#91;&#47;tag(数字)&#93;　といったタグの存在する数が一致していることを確認してください。
                - また、&#91;tag(数字)&#93;、&#91;&#47;tag(数字)&#93;　といったタグの表示順序も原文と一致するはずです
            </コンテキスト>

            <翻訳対象>
                [tag64] Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do: once or twice she had peeped into the book her sister was reading, but it had no pictures or conversations in it, "and what is the use of a book," thought Alice "without pictures or conversations?" [/tag64]
            </翻訳対象>
        """

        # リクエストの設定
        messages = [
            {
                "role": "system",
                "content": """
                あなたは高品質な英日翻訳者です。以下の制約に従って翻訳してください：
                1. HTMLタグ（&#91;tag数字&#93;など）は翻訳せず、そのまま保持すること
                2. URLは変更しないこと
                3. コードブロックの内容は翻訳しないこと
                4. 改行は維持すること
                """,
            },
            {"role": "user", "content": test_text},
        ]

        # APIリクエストの送信
        response = completion(
            model="deepseek/deepseek-chat",
            messages=messages,
            temperature=1,
        )

        # レスポンスの内容を表示
        print("\n応答内容:", response.choices[0].message.content)

    except AuthenticationError as e:
        logger.error("Authentication Error: %s", str(e))
    except InvalidRequestError as e:
        logger.error("Invalid Request Error: %s", str(e))
    except Exception as e:
        logger.error("Unexpected Error: %s", str(e))


if __name__ == "__main__":
    test_deepseek_api()
