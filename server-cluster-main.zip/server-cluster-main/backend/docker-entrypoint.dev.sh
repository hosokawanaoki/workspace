#!/bin/bash

python manage.py makemigrations
python manage.py migrate
# Django サーバーを明示的に停止
echo "Django サーバーの起動を停止します"
python manage.py runserver 0.0.0.0:8000
