# 書籍翻訳システム

## 概要
このシステムは、書籍の自動翻訳を管理・実行するDjangoベースのアプリケーションです。

## 主要コンポーネント

### API (app/api/)
- **Models**: 書籍データとその翻訳状態を管理
- **Services**: 
  - **Book**: 書籍データの永続化と取得
  - **Translation**: 翻訳処理の実行と管理
  - **Scheduler**: 定期的な翻訳処理の実行
  - **Scraping**: 書籍データの収集
  - **Common**: 共通ユーティリティと基盤機能

### 翻訳処理フロー
1. 書籍データの取得と保存
2. 翻訳待ち状態の書籍を定期的にチェック
3. テキスト前処理（分割、タグ処理）
4. 翻訳処理の実行
5. テキスト後処理（タグ復元、整形）
6. 結果の保存と状態の更新

## ディレクトリ構造

### プロジェクト全体の構造

```
app/
├── api/
│   ├── services/
│   │   ├── book/          # 書籍データ管理
│   │   ├── translation/   # 翻訳処理
│   │   ├── scheduler/     # 定期実行
│   │   ├── scraping/      # データ収集
│   │   └── common/        # 共通機能
│   ├── models/            # データモデル
│   ├── views/             # APIエンドポイント
│   └── utils/             # ユーティリティ
```

### サービスモジュールの実際の構造

各サービスモジュールは以下の構造に従って実装されています：

```
service_name/                      # 例: translation/
├── interfaces/                    # インターフェース定義
│   ├── translation_service.py     # 主要サービスのインターフェース
│   ├── translation_processor_service.py
│   └── text_processing/          # テキスト処理関連インターフェース
│       └── text_processor.py
│
├── implementations/              # インターフェースの実装
│   ├── translation_service_impl.py
│   ├── translation_processor_service_impl.py
│   └── text_processing/         # テキスト処理実装
│       ├── text_pre_processor_impl.py
│       ├── text_post_processor_impl.py
│       └── tag_recovery_service_impl.py
│
├── processors/                   # 処理ロジック
│   ├── chunk_creator.py         # テキスト分割処理
│   ├── chunk_translator.py      # 分割単位の翻訳処理
│   └── line_processor.py        # 行単位の処理
│
├── models/                      # ドメインモデル
│   ├── translation_state.py     # 翻訳状態管理
│   ├── translator_config.py     # 設定管理
│   └── translation_factory.py   # ファクトリークラス
│
├── exceptions/                  # カスタム例外
│   └── translation_exceptions.py
│
└── utils/                      # ユーティリティ
    ├── file_path_manager.py    # ファイルパス管理
    └── text_chunk_splitter.py  # テキスト分割ユーティリティ
```

この構造の利点：

1. **関心の分離**
   - インターフェースと実装の明確な分離
   - テキスト処理と翻訳処理の分離
   - 状態管理とビジネスロジックの分離

2. **拡張性**
   - 新しい翻訳サービスの追加が容易
   - テキスト処理方式の変更が容易
   - モジュール単位での機能追加が可能

3. **テスト容易性**
   - インターフェースベースのモック作成が容易
   - 処理単位での独立したテストが可能
   - 状態管理の分離によるテストの簡素化

## 主要機能

### スケジューラー (scheduler)
- 定期的に翻訳待ち書籍をチェック
- 翻訳処理の実行を管理
- エラーハンドリングとステータス管理
- 停止したバッチの検出と管理

### 翻訳サービス (translation)
- テキスト前処理（分割、タグ抽出）
- 翻訳実行（LLMベース）
- 後処理（タグ復元、テキスト整形）
- バッチ処理管理

### 書籍管理 (book)
- 書籍データのCRUD操作
- ステータス管理
- バッチ処理の管理
- 進捗管理

### 共通機能 (common)
- ファイルシステム操作
- HTTPクライアント
- パス管理ユーティリティ
- タグ処理ユーティリティ

## 開発環境のセットアップ

```bash
# 依存関係のインストール
pip install -r requirements.txt

# データベースのマイグレーション
python manage.py migrate

# 開発サーバーの起動
python manage.py runserver
```

## 設定

環境変数:
- `OPENAI_API_KEY`: OpenAI APIキー
- `ANTHROPIC_API_KEY`: Anthropic APIキー
- `DEEPSEEK_API_KEY`: DEEPSEEK APIキー

## 翻訳処理の状態管理

### 書籍の状態遷移

書籍は以下の状態を持ち、翻訳処理の進行に応じて遷移します：

- raw: 翻訳前の初期状態
- waiting: 翻訳待ち（翻訳バッチ作成時）
- ai-execution: AI翻訳実行中（翻訳処理開始時）
- translating: 翻訳途中（一部翻訳完了時）
- translated: 翻訳済み（全文翻訳完了かつタグ修復成功時）
- tag-error: タグエラーあり（翻訳完了後のタグ修復失敗時）
- error: その他エラー（処理中の予期せぬエラー発生時）
- complete: 完了（最終確認完了時）
- notfound: ファイルが存在しない（ファイル不在時）

### 翻訳バッチの状態遷移

翻訳バッチは以下の状態を持ちます：

- pending: 待機中（バッチ作成直後）
- processing: 処理中（翻訳処理開始時）
- completed: 完了（翻訳とタグ修復が成功時）
- failed: 失敗（エラー発生時またはタグ修復失敗時）
- stopped: 強制停止（ユーザーによる停止時）

### 翻訳実行方式

システムは2つの翻訳実行方式をサポートしています：

1. バッチ処理による実行
   - 翻訳バッチを作成し、スケジューラーが順次処理
   - 一度に1つの翻訳のみ実行
   - 30分以上更新がない場合はエラー状態に
   - 強制停止機能あり

2. 直接実行（LLM翻訳）
   - APIを通じて即時実行
   - 既存の翻訳がある場合は続きから実行
   - 翻訳済み部分はスキップし、未翻訳部分のみ処理

### 状態遷移のタイミング

1. バッチ処理による翻訳開始時
   - 翻訳バッチ作成 → 書籍が waiting 状態に
   - 翻訳処理開始 → 書籍が ai-execution 状態に

2. 直接実行による翻訳開始時
   - エラー状態の場合：新規から翻訳開始
   - 翻訳中状態の場合：
     - 翻訳済み部分をスキップ
     - 未翻訳部分から再開

3. 翻訳とタグ修復の処理
   - 翻訳処理中：
     - 一部翻訳完了 → 書籍が translating 状態に
     - 各翻訳完了時にタグの整合性チェックと修復を実施
   - 全文翻訳完了時：
     - すべてのタグが正しく修復 → 書籍が translated 状態に
     - タグの不一致が残る → 書籍が tag-error 状態に

4. エラー発生時
   - 予期せぬエラー → 書籍が error 状態に
   - 30分以上更新なし → 書籍が error 状態に
   - 強制停止 → バッチが stopped 状態に

### 翻訳データの管理

翻訳データはJSONファイルで管理され、以下の形式で保存されます：
```json
{
  "translations": [
    {
      "id": "行番号",
      "source_text": "原文",
      "translated_text": "翻訳済みテキスト（nullの場合は未翻訳）",
      "line_number": "行番号",
      "chunk_count": "分割番号",
      "chunk_max": "分割総数"
    }
  ]
}
```

- translated_text が null の行から翻訳を開始
- 既に翻訳済み（null以外）の部分はスキップ
- タグの整合性チェックは全行に対して実施

注意: バッチ処理の場合、一度に処理できる翻訳は1件のみです。新しい翻訳を開始する前に、実行中の翻訳がないことを確認します。

## コーディング規約

### 命名規則

#### ファイル名
- Pythonファイル: スネークケース（例: `book_processing.py`）
- インターフェース: `interface`ディレクトリに配置し、機能名を付ける（例: `processor.py`）
- 実装クラス: `implementations`ディレクトリに配置し、`*_impl.py`の形式（例: `book_processor_impl.py`）

#### クラス名
- パスカルケース（例: `BookProcessor`）
- インターフェース: 機能を表す名前（例: `Processor`）
- 実装クラス: インターフェース名 + `Impl`（例: `BookProcessorImpl`）

#### メソッド名
- スネークケース（例: `process_books`）
- プライベートメソッド: アンダースコアプレフィックス（例: `_validate_input`）

#### 変数名
- スネークケース（例: `book_repository`）
- 定数: 大文字のスネークケース（例: `MAX_RETRY_COUNT`）

### コード構造

#### クラス構造
```python
class ExampleClass:
    """クラスの説明をドックストリングで記述

    このクラスが何を行うのかの詳細な説明。
    複数行に渡る場合は適切に改行する。

    Attributes:
        属性名 (型): 説明
    """

    def __init__(self, param1: Type1, param2: Type2):
        """コンストラクタの説明

        Args:
            param1 (Type1): 説明
            param2 (Type2): 説明
        """
        self.param1 = param1
        self.param2 = param2

    def method_name(self) -> ReturnType:
        """メソッドの説明

        Returns:
            ReturnType: 戻り値の説明

        Raises:
            ExceptionType: 例外が発生する条件の説明
        """
        pass
```

### コードスタイル

1. **インポート順序**
   - 標準ライブラリ
   - サードパーティライブラリ
   - ローカルアプリケーション
   - 各グループ内はアルファベット順

2. **型ヒント**
   - 引数と戻り値に型ヒントを付ける
   ```python
   def process_book(self, book: Book) -> None:
   ```

3. **ドキュメンテーション**
   - クラスとパブリックメソッドにはドックストリングを書く
   - 複雑なロジックには適切なコメントを付ける

4. **エラーハンドリング**
   - 具体的な例外をキャッチする
   - カスタム例外を適切に定義・使用する

5. **依存性注入**
   - 外部依存はコンストラクタで注入する
   - インターフェースに依存し、具体的な実装には依存しない

6. **テスト**
   - ユニットテストはテスト対象のファイルと同じ構造で配置
   - テストクラス名は対象クラス名 + `Test`
   - テストメソッド名は`test_` + テスト内容

