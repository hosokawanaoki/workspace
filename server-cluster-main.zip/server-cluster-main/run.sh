#!/bin/bash

# 引数のチェック
if [ "$1" == "dev" ]; then
  # 開発環境用の設定
  echo "開発環境を起動します..."
  docker compose -f docker-compose.yml -f docker-compose.dev.yml up
  echo "バックエンドサーバーを起動します..."
elif [ "$1" == "down" ]; then
  # コンテナ停止
  echo "コンテナを停止します..."
  docker compose down
elif [ "$1" == "logs" ]; then
  # ログ表示
  echo "ログを表示します..."
  docker compose logs -f
elif [ "$1" == "reload" ]; then
  # 開発サーバーのリロード
  echo "開発サーバーをリロードします..."
  docker compose exec backend bash -c "pkill -f 'python app/manage.py runserver' && uv run python app/manage.py runserver 0.0.0.0:8000"
elif [ "$1" == "rebuild" ]; then
  # コンテナの再ビルドと再起動
  if [ "$2" == "prod" ]; then
    echo "本番環境のコンテナを再ビルドします..."
    docker compose -f docker-compose.yml -f docker-compose.prod.yml down
    docker compose -f docker-compose.yml -f docker-compose.prod.yml build
    docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d
  else
    echo "開発環境のコンテナを再ビルドします..."
    docker compose -f docker-compose.yml -f docker-compose.dev.yml down
    docker compose -f docker-compose.yml -f docker-compose.dev.yml build
    docker compose -f docker-compose.yml -f docker-compose.dev.yml up
    echo "バックエンドサーバーを起動します..."
    docker-compose exec backend uv run python app/manage.py runserver 0.0.0.0:8000
  fi
else
  # 本番環境用の設定
  echo "本番環境を起動します..."
  docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d
fi
